/**
 * Rutas para la administración de eventos y cultos de la congregación (RF-04).
 */
const { Router } = require('express');
const {
  listarEventos,
  obtenerEventoPorId,
  crearEvento,
  actualizarEvento,
  cancelarEvento
} = require('../controllers/eventosController');
const { autenticarToken, autorizarRoles } = require('../middleware/authMiddleware');

const router = Router();

router.use(autenticarToken);

router.get('/', listarEventos);
router.get('/:id', obtenerEventoPorId);

// Creación, edición y cancelación de eventos
router.post('/', autorizarRoles('Administrador', 'Pastor', 'Secretario', 'Coordinador'), crearEvento);
router.put('/:id', autorizarRoles('Administrador', 'Pastor', 'Secretario', 'Coordinador'), actualizarEvento);
router.patch('/:id/cancelar', autorizarRoles('Administrador', 'Pastor', 'Secretario', 'Coordinador'), cancelarEvento);

module.exports = router;
