/**
 * Vista de Recuperación de Contraseña Pastoral y Eclesiástica (RF-01).
 * Soporta integración con la API de Google Gmail para envío de códigos.
 * Predominante: #fffdf5, Contorno: #7a4e2a, Blanco, Beige (#faf4ea, #f5ede1) y Amarillo Pálido #fef9c3.
 * Tipografía: Day Roman Regular (sin iconos, letras más grandes y legibles).
 */
import React, { useState } from 'react';
import { authService } from '../services/api';

export default function RecuperarPasswordView({ onVolverLogin }) {
  const [paso, setPaso] = useState(1);
  const [email, setEmail] = useState('');
  const [codigo, setCodigo] = useState('');
  const [nuevoPassword, setNuevoPassword] = useState('');
  const [confirmarPassword, setConfirmarPassword] = useState('');
  const [codigoSimulado, setCodigoSimulado] = useState('');

  const [cargando, setCargando] = useState(false);
  const [mensaje, setMensaje] = useState('');
  const [error, setError] = useState('');

  async function handleSolicitarCodigo(e) {
    e.preventDefault();
    setError('');
    setMensaje('');
    setCargando(true);

    try {
      const res = await authService.recuperarPassword(email);
      setMensaje(res.mensaje);
      if (res.codigoRecuperacionSimulado) {
        setCodigoSimulado(res.codigoRecuperacionSimulado);
        setCodigo(res.codigoRecuperacionSimulado);
      }
      setPaso(2);
    } catch (err) {
      setError(err.message || 'Error al procesar la solicitud.');
    } finally {
      setCargando(false);
    }
  }

  async function handleRestablecer(e) {
    e.preventDefault();
    setError('');
    setMensaje('');

    if (nuevoPassword !== confirmarPassword) {
      setError('Las contraseñas no coinciden.');
      return;
    }

    setCargando(true);
    try {
      const res = await authService.restablecerPassword({
        email,
        codigo,
        nuevoPassword,
      });
      setMensaje(res.mensaje);
      setTimeout(() => {
        onVolverLogin();
      }, 2000);
    } catch (err) {
      setError(err.message || 'Error al restablecer la contraseña.');
    } finally {
      setCargando(false);
    }
  }

  return (
    <div className="min-h-screen bg-[#fffdf5] flex items-center justify-center p-4 sm:p-6 text-[#2b190a] font-serif">
      <div className="w-full max-w-lg bg-[#fffdf5] rounded-3xl shadow-xl p-6 sm:p-9 border-2 border-[#7a4e2a]">
        <button
          onClick={onVolverLogin}
          className="text-sm text-[#7a4e2a] hover:underline mb-6 block font-bold"
        >
          « Volver al inicio de sesión
        </button>

        <div className="text-center space-y-1.5 mb-8">
          <div className="w-14 h-14 mx-auto rounded-full bg-[#fef9c3] border-2 border-[#7a4e2a] flex items-center justify-center text-[#7a4e2a] font-bold text-2xl mb-3 shadow-xs">
            R
          </div>
          <h2 className="text-3xl text-[#7a4e2a] font-normal">
            Recuperar Contraseña
          </h2>
          <p className="text-sm text-[#58351a]">
            {paso === 1
              ? 'Ingrese su correo electrónico para recibir el código mediante Google Gmail.'
              : 'Introduzca el código de seguridad recibido y establezca su nueva contraseña.'}
          </p>
        </div>

        {error && (
          <div className="mb-5 p-4 rounded-xl bg-[#fff2f0] border-2 border-[#7a4e2a] text-[#783636] text-sm">
            {error}
          </div>
        )}

        {mensaje && (
          <div className="mb-5 p-4 rounded-xl bg-[#f5ede1] border-2 border-[#7a4e2a] text-[#7a4e2a] text-sm font-bold">
            {mensaje}
          </div>
        )}

        {paso === 1 ? (
          <form onSubmit={handleSolicitarCodigo} className="space-y-5">
            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1.5">
                Correo Electrónico Registrado
              </label>
              <input
                type="email"
                required
                placeholder="pastoral@iglesia.org"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
              />
              <p className="text-xs text-[#7a4e2a] mt-1.5 font-medium">
                Se enviará una notificación con el código de 6 dígitos a través de Google Gmail.
              </p>
            </div>

            <button
              type="submit"
              disabled={cargando}
              className="w-full py-3.5 bg-[#7a4e2a] hover:bg-[#684122] text-[#fffdf5] rounded-xl font-bold text-base shadow-sm border-2 border-[#7a4e2a] transition-all disabled:opacity-50"
            >
              {cargando ? 'Generando código...' : 'Solicitar Código de Seguridad'}
            </button>
          </form>
        ) : (
          <form onSubmit={handleRestablecer} className="space-y-4">
            {codigoSimulado && (
              <div className="p-4 bg-[#faf4ea] border-2 border-[#7a4e2a] rounded-xl text-sm text-[#7a4e2a]">
                <p className="font-bold text-center">Código de verificación para desarrollo y pruebas:</p>
                <p className="text-2xl font-mono font-bold tracking-widest text-center my-1.5 text-[#7a4e2a]">{codigoSimulado}</p>
                <p className="text-xs text-[#58351a] text-center">Ha sido cargado automáticamente en el formulario.</p>
              </div>
            )}

            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Código de 6 dígitos</label>
              <input
                type="text"
                required
                maxLength={6}
                value={codigo}
                onChange={(e) => setCodigo(e.target.value)}
                className="w-full text-center tracking-widest font-mono text-2xl py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl focus:outline-none focus:bg-[#fef9c3]/30"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Nueva Contraseña</label>
              <input
                type="password"
                required
                minLength={6}
                placeholder="Mínimo 6 caracteres"
                value={nuevoPassword}
                onChange={(e) => setNuevoPassword(e.target.value)}
                className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Confirmar Nueva Contraseña</label>
              <input
                type="password"
                required
                minLength={6}
                placeholder="Repita la nueva contraseña"
                value={confirmarPassword}
                onChange={(e) => setConfirmarPassword(e.target.value)}
                className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
              />
            </div>

            <button
              type="submit"
              disabled={cargando}
              className="w-full py-3.5 bg-[#7a4e2a] hover:bg-[#684122] text-[#fffdf5] rounded-xl font-bold text-base shadow-sm border-2 border-[#7a4e2a] transition-all disabled:opacity-50"
            >
              {cargando ? 'Actualizando clave...' : 'Restablecer Contraseña'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
