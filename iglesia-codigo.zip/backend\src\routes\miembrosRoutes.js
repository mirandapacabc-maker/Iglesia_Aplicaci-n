/**
 * Definición de rutas para el directorio y gestión de miembros (RF-02).
 */
const { Router } = require('express');
const {
  listarMiembros,
  obtenerMiembroPorId,
  crearMiembro,
  actualizarMiembro,
  alternarEstadoMiembro
} = require('../controllers/miembrosController');
const { autenticarToken, autorizarRoles } = require('../middleware/authMiddleware');

const router = Router();

router.use(autenticarToken);

// Consulta disponible para todos los roles con acceso al sistema
router.get('/', listarMiembros);
router.get('/:id', obtenerMiembroPorId);

// Modificaciones restringidas a roles administrativos, pastorales o secretaría
router.post('/', autorizarRoles('Administrador', 'Pastor', 'Secretario'), crearMiembro);
router.put('/:id', autorizarRoles('Administrador', 'Pastor', 'Secretario'), actualizarMiembro);
router.patch('/:id/estado', autorizarRoles('Administrador', 'Pastor', 'Secretario'), alternarEstadoMiembro);

module.exports = router;
