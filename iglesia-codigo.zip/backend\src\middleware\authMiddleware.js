/**
 * Middlewares de autenticación mediante JWT y autorización basada en los 5 roles del sistema:
 * 'Administrador', 'Pastor', 'Secretario', 'Tesorero', 'Coordinador'.
 */
const jwt = require('jsonwebtoken');
const db = require('../config/database');

const JWT_SECRET = process.env.JWT_SECRET || 'super_secreto_clave_segura_iglesia_2026_jwt_token';

/**
 * Valida el token JWT en el encabezado Authorization y adjunta el usuario a la solicitud.
 */
function autenticarToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ mensaje: 'Acceso no autorizado: Token no proporcionado.' });
  }

  try {
    const payload = jwt.verify(token, JWT_SECRET);
    
    // Verificar que el usuario continúe existiendo y activo en la base de datos
    const usuario = db.prepare(`
      SELECT id, nombre, email, rol, telefono, activo 
      FROM usuarios 
      WHERE id = ? AND activo = 1
    `).get(payload.id);

    if (!usuario) {
      return res.status(401).json({ mensaje: 'Sesión inválida o usuario inactivo.' });
    }

    req.usuario = usuario;
    next();
  } catch (error) {
    return res.status(403).json({ mensaje: 'Token inválido o expirado. Inicia sesión nuevamente.' });
  }
}

/**
 * Middleware para restringir endpoints a una lista específica de roles permitidos.
 * @param  {...string} rolesPermitidos - Ej: 'Administrador', 'Pastor', 'Tesorero'
 */
function autorizarRoles(...rolesPermitidos) {
  return (req, res, next) => {
    if (!req.usuario) {
      return res.status(401).json({ mensaje: 'No autenticado.' });
    }

    if (!rolesPermitidos.includes(req.usuario.rol)) {
      return res.status(403).json({
        mensaje: `Acceso restringido: El rol '${req.usuario.rol}' no tiene permisos para esta sección.`
      });
    }

    next();
  };
}

module.exports = {
  autenticarToken,
  autorizarRoles,
  JWT_SECRET
};
