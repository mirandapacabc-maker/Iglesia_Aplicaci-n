/**
 * Capa de Servicios de Comunicación con la API REST (Frontend).
 * Encapsula las llamadas HTTP, adjunta automáticamente el token JWT y procesa respuestas y errores.
 */

const API_BASE = '/api';

/**
 * Cliente HTTP base para realizar peticiones autenticadas.
 */
async function fetchCliente(endpoint, opciones = {}) {
  const token = localStorage.getItem('iglesia_token');

  const headers = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...opciones.headers,
  };

  const config = {
    ...opciones,
    headers,
  };

  try {
    const respuesta = await fetch(`${API_BASE}${endpoint}`, config);

    // Si el token expiró o es inválido, cerrar sesión local
    if (respuesta.status === 401 && !endpoint.includes('/auth/login')) {
      localStorage.removeItem('iglesia_token');
      localStorage.removeItem('iglesia_usuario');
      window.location.href = '/login';
      throw new Error('Tu sesión ha expirado. Por favor ingresa nuevamente.');
    }

    let data = {};
    const esJson = respuesta.headers.get('content-type')?.includes('application/json');
    if (esJson) {
      data = await respuesta.json().catch(() => ({}));
    } else {
      const texto = await respuesta.text().catch(() => '');
      if (respuesta.status >= 500) {
        throw new Error('No se pudo establecer conexión con el servidor backend (puerto 4000). Asegúrate de que el backend esté iniciado.');
      }
      data = { mensaje: texto };
    }

    if (!respuesta.ok) {
      throw new Error(data.mensaje || `Error en la solicitud HTTP (${respuesta.status}): ${respuesta.statusText || 'Error del servidor'}`);
    }

    return data;
  } catch (error) {
    if (error.message?.includes('Failed to fetch') || error.message?.includes('NetworkError')) {
      throw new Error('Error de conexión de red: No se pudo contactar a la API en http://localhost:4000. Verifica que el servidor backend esté corriendo.');
    }
    throw error;
  }
}

// RF-01: Autenticación y Usuarios
export const authService = {
  login: (credenciales) => fetchCliente('/auth/login', { method: 'POST', body: JSON.stringify(credenciales) }),
  registro: (datos) => fetchCliente('/auth/registro', { method: 'POST', body: JSON.stringify(datos) }),
  perfil: () => fetchCliente('/auth/me'),
  recuperarPassword: (email) => fetchCliente('/auth/recuperar-password', { method: 'POST', body: JSON.stringify({ email }) }),
  restablecerPassword: (datos) => fetchCliente('/auth/restablecer-password', { method: 'POST', body: JSON.stringify(datos) }),
  listarUsuarios: () => fetchCliente('/auth/usuarios'),
  cambiarEstadoUsuario: (id, activo) => fetchCliente(`/auth/usuarios/${id}/estado`, { method: 'PATCH', body: JSON.stringify({ activo }) }),
};

// RF-02: Gestión de Miembros
export const miembrosService = {
  listar: (filtros = {}) => {
    const params = new URLSearchParams(filtros).toString();
    return fetchCliente(`/miembros?${params}`);
  },
  obtenerPorId: (id) => fetchCliente(`/miembros/${id}`),
  crear: (datos) => fetchCliente('/miembros', { method: 'POST', body: JSON.stringify(datos) }),
  actualizar: (id, datos) => fetchCliente(`/miembros/${id}`, { method: 'PUT', body: JSON.stringify(datos) }),
  alternarEstado: (id, activo) => fetchCliente(`/miembros/${id}/estado`, { method: 'PATCH', body: JSON.stringify({ activo }) }),
};

// RF-04: Gestión de Eventos
export const eventosService = {
  listar: (filtros = {}) => {
    const params = new URLSearchParams(filtros).toString();
    return fetchCliente(`/eventos?${params}`);
  },
  obtenerPorId: (id) => fetchCliente(`/eventos/${id}`),
  crear: (datos) => fetchCliente('/eventos', { method: 'POST', body: JSON.stringify(datos) }),
  actualizar: (id, datos) => fetchCliente(`/eventos/${id}`, { method: 'PUT', body: JSON.stringify(datos) }),
  cancelar: (id, motivo) => fetchCliente(`/eventos/${id}/cancelar`, { method: 'PATCH', body: JSON.stringify({ motivo }) }),
};

// RF-03: Control de Asistencia
export const asistenciaService = {
  obtenerHoja: (eventoId, fecha) => fetchCliente(`/asistencia/hoja?eventoId=${eventoId}&fecha=${fecha || ''}`),
  guardarLote: (datos) => fetchCliente('/asistencia/lote', { method: 'POST', body: JSON.stringify(datos) }),
  historialMiembro: (miembroId) => fetchCliente(`/asistencia/miembro/${miembroId}`),
  reportePeriodo: (filtros = {}) => {
    const params = new URLSearchParams(filtros).toString();
    return fetchCliente(`/asistencia/reporte?${params}`);
  },
};

// RF-05: Administración de Ministerios
export const ministeriosService = {
  listar: () => fetchCliente('/ministerios'),
  obtenerPorId: (id) => fetchCliente(`/ministerios/${id}`),
  crear: (datos) => fetchCliente('/ministerios', { method: 'POST', body: JSON.stringify(datos) }),
  actualizar: (id, datos) => fetchCliente(`/ministerios/${id}`, { method: 'PUT', body: JSON.stringify(datos) }),
  vincularMiembro: (id, datos) => fetchCliente(`/ministerios/${id}/miembros`, { method: 'POST', body: JSON.stringify(datos) }),
  desvincularMiembro: (id, miembroId) => fetchCliente(`/ministerios/${id}/miembros/${miembroId}`, { method: 'DELETE' }),
  crearActividad: (id, datos) => fetchCliente(`/ministerios/${id}/actividades`, { method: 'POST', body: JSON.stringify(datos) }),
};

// RF-06: Gestión de Donaciones y Aportaciones
export const donacionesService = {
  listar: (filtros = {}) => {
    const params = new URLSearchParams(filtros).toString();
    return fetchCliente(`/donaciones?${params}`);
  },
  registrar: (datos) => fetchCliente('/donaciones', { method: 'POST', body: JSON.stringify(datos) }),
  resumenMensual: (anio) => fetchCliente(`/donaciones/resumen-mensual?anio=${anio || ''}`),
  eliminar: (id) => fetchCliente(`/donaciones/${id}`, { method: 'DELETE' }),
};

// RF-07: Comunicados y Anuncios
export const anunciosService = {
  listar: (filtros = {}) => {
    const params = new URLSearchParams(filtros).toString();
    return fetchCliente(`/anuncios?${params}`);
  },
  crear: (datos) => fetchCliente('/anuncios', { method: 'POST', body: JSON.stringify(datos) }),
  actualizar: (id, datos) => fetchCliente(`/anuncios/${id}`, { method: 'PUT', body: JSON.stringify(datos) }),
  eliminar: (id) => fetchCliente(`/anuncios/${id}`, { method: 'DELETE' }),
};

// RF-08: Panel Principal (Dashboard)
export const dashboardService = {
  obtenerMetricas: () => fetchCliente('/dashboard/metricas'),
};

// RF-09: Reportes
export const reportesService = {
  miembros: (filtros = {}) => {
    const params = new URLSearchParams(filtros).toString();
    return fetchCliente(`/reportes/miembros?${params}`);
  },
  asistencia: (filtros = {}) => {
    const params = new URLSearchParams(filtros).toString();
    return fetchCliente(`/reportes/asistencia?${params}`);
  },
  ministerios: (filtros = {}) => {
    const params = new URLSearchParams(filtros).toString();
    return fetchCliente(`/reportes/ministerios?${params}`);
  },
  ingresos: (filtros = {}) => {
    const params = new URLSearchParams(filtros).toString();
    return fetchCliente(`/reportes/ingresos?${params}`);
  },
};

// RF-10: Configuración de la Iglesia
export const configuracionService = {
  obtener: () => fetchCliente('/configuracion'),
  actualizar: (datos) => fetchCliente('/configuracion', { method: 'PUT', body: JSON.stringify(datos) }),
};
