/**
 * Rutas de la API para el control de asistencia (RF-03).
 */
const { Router } = require('express');
const {
  obtenerHojaAsistencia,
  registrarAsistenciaLote,
  historialPorMiembro,
  reporteAsistenciaPeriodo
} = require('../controllers/asistenciaController');
const { autenticarToken, autorizarRoles } = require('../middleware/authMiddleware');

const router = Router();

router.use(autenticarToken);

router.get('/hoja', obtenerHojaAsistencia);
router.get('/miembro/:miembroId', historialPorMiembro);
router.get('/reporte', reporteAsistenciaPeriodo);

// Registro de asistencia (Admin, Pastor, Secretario, Coordinador)
router.post('/lote', autorizarRoles('Administrador', 'Pastor', 'Secretario', 'Coordinador'), registrarAsistenciaLote);

module.exports = router;
