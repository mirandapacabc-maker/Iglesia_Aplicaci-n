/**
 * Rutas de la API para la gestión de ministerios y grupos (RF-05).
 */
const { Router } = require('express');
const {
  listarMinisterios,
  obtenerMinisterioPorId,
  crearMinisterio,
  actualizarMinisterio,
  vincularMiembro,
  desvincularMiembro,
  crearActividad
} = require('../controllers/ministeriosController');
const { autenticarToken, autorizarRoles } = require('../middleware/authMiddleware');

const router = Router();

router.use(autenticarToken);

router.get('/', listarMinisterios);
router.get('/:id', obtenerMinisterioPorId);

// Gestión de ministerios
router.post('/', autorizarRoles('Administrador', 'Pastor', 'Coordinador'), crearMinisterio);
router.put('/:id', autorizarRoles('Administrador', 'Pastor', 'Coordinador'), actualizarMinisterio);

// Integración y retiro de miembros
router.post('/:id/miembros', autorizarRoles('Administrador', 'Pastor', 'Coordinador'), vincularMiembro);
router.delete('/:id/miembros/:miembroId', autorizarRoles('Administrador', 'Pastor', 'Coordinador'), desvincularMiembro);

// Actividades por ministerio
router.post('/:id/actividades', autorizarRoles('Administrador', 'Pastor', 'Coordinador'), crearActividad);

module.exports = router;
