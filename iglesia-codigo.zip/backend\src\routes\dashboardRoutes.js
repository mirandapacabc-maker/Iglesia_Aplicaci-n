/**
 * Rutas de la API para el panel principal (Dashboard) (RF-08).
 */
const { Router } = require('express');
const { obtenerMetricasDashboard } = require('../controllers/dashboardController');
const { autenticarToken } = require('../middleware/authMiddleware');

const router = Router();

router.use(autenticarToken);

router.get('/metricas', obtenerMetricasDashboard);

module.exports = router;
