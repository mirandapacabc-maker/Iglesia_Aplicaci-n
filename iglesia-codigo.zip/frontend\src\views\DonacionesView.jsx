/**
 * Vista de Gestión de Donaciones y Aportaciones (RF-06).
 * Predominante: #fffdf5, Contorno: #7a4e2a, Blanco, Beige (#faf4ea, #f5ede1) y Amarillo Pálido #fef9c3.
 * Tipografía: Day Roman Regular (sin iconos, letras más grandes y legibles).
 */
import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { donacionesService, miembrosService } from '../services/api';
import Modal from '../components/Modal';

export default function DonacionesView() {
  const { puedeVerFinanzas, esAdmin, esTesorero } = useAuth();

  const [donaciones, setDonaciones] = useState([]);
  const [resumen, setResumen] = useState(null);
  const [resumenMensual, setResumenMensual] = useState(null);
  const [miembros, setMiembros] = useState([]);

  // Filtros por periodo y concepto
  const [fechaInicio, setFechaInicio] = useState('');
  const [fechaFin, setFechaFin] = useState('');
  const [filtroConcepto, setFiltroConcepto] = useState('');

  const [cargando, setCargando] = useState(false);
  const [mensaje, setMensaje] = useState('');
  const [error, setError] = useState('');

  // Modal de registro (RF-06)
  const [modalAbierto, setModalAbierto] = useState(false);
  const [guardando, setGuardando] = useState(false);
  const [formDonacion, setFormDonacion] = useState({
    fecha: new Date().toISOString().split('T')[0],
    monto: '',
    concepto: 'Diezmo',
    metodo_pago: 'Efectivo',
    miembro_id: '',
    es_anonimo: false,
    notas: '',
  });

  useEffect(() => {
    if (puedeVerFinanzas) {
      cargarDonaciones();
      cargarResumenMensual();
      cargarMiembros();
    }
  }, [fechaInicio, fechaFin, filtroConcepto]);

  if (!puedeVerFinanzas) {
    return (
      <div className="bg-[#fffdf5] p-12 rounded-3xl border-2 border-[#7a4e2a] text-center max-w-lg mx-auto space-y-3 font-serif">
        <h3 className="text-2xl font-bold text-[#783636]">Información Reservada</h3>
        <p className="text-sm text-[#58351a]">
          La información financiera y de mayordomía está restringida únicamente a personal autorizado (Administrador, Pastor y Tesorero).
        </p>
      </div>
    );
  }

  async function cargarDonaciones() {
    setCargando(true);
    setError('');
    try {
      const res = await donacionesService.listar({
        fecha_inicio: fechaInicio,
        fecha_fin: fechaFin,
        concepto: filtroConcepto,
      });
      setDonaciones(res.donaciones);
      setResumen(res.resumen);
    } catch (err) {
      setError(err.message || 'Error al consultar libros contables.');
    } finally {
      setCargando(false);
    }
  }

  async function cargarResumenMensual() {
    try {
      const res = await donacionesService.resumenMensual();
      setResumenMensual(res);
    } catch (err) {
      console.error(err);
    }
  }

  async function cargarMiembros() {
    try {
      const res = await miembrosService.listar({ estado: 'activos', limite: 500 });
      setMiembros(res.miembros);
    } catch (err) {
      console.error(err);
    }
  }

  function abrirModalNuevo() {
    setFormDonacion({
      fecha: new Date().toISOString().split('T')[0],
      monto: '',
      concepto: 'Diezmo',
      metodo_pago: 'Efectivo',
      miembro_id: '',
      es_anonimo: false,
      notas: '',
    });
    setModalAbierto(true);
  }

  async function handleGuardarDonacion(e) {
    e.preventDefault();
    if (!formDonacion.monto || Number(formDonacion.monto) <= 0) {
      setError('Ingrese un monto válido mayor a 0.');
      return;
    }

    setGuardando(true);
    setError('');
    setMensaje('');

    try {
      const datosAEnviar = {
        ...formDonacion,
        miembro_id: formDonacion.es_anonimo ? null : formDonacion.miembro_id || null,
      };

      await donacionesService.crear(datosAEnviar);
      setMensaje('Aportación económica asentada con éxito.');
      setModalAbierto(false);
      cargarDonaciones();
      cargarResumenMensual();
    } catch (err) {
      setError(err.message || 'Error al registrar la aportación.');
    } finally {
      setGuardando(false);
    }
  }

  async function handleEliminarDonacion(id) {
    if (!window.confirm('¿Desea anular este registro de aportación?')) return;
    try {
      await donacionesService.eliminar(id);
      setMensaje('Registro contable anulado correctamente.');
      cargarDonaciones();
      cargarResumenMensual();
    } catch (err) {
      setError(err.message || 'Error al eliminar la aportación.');
    }
  }

  return (
    <div className="space-y-7 text-[#2b190a] font-serif">
      {/* Cabecera */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-3xl sm:text-4xl font-normal text-[#7a4e2a]">
            Donaciones y Aportaciones
          </h2>
          <p className="text-sm text-[#58351a] mt-1 font-medium">
            Registro de aportaciones económicas, diezmos y ofrendas (RF-06 - Personal Autorizado)
          </p>
        </div>

        <button
          onClick={abrirModalNuevo}
          className="px-5 py-3 bg-[#fef9c3] hover:bg-[#ebd8c3] text-[#7a4e2a] border-2 border-[#7a4e2a] rounded-xl text-sm font-bold shadow-xs transition-all self-start sm:self-auto"
        >
          Registrar Aportación
        </button>
      </div>

      {/* Alertas */}
      {mensaje && (
        <div className="p-4 bg-[#faf4ea] border-2 border-[#7a4e2a] rounded-xl text-[#7a4e2a] text-sm font-bold">
          {mensaje}
        </div>
      )}

      {error && (
        <div className="p-4 bg-[#fff2f0] border-2 border-[#7a4e2a] rounded-xl text-[#783636] text-sm">
          {error}
        </div>
      )}

      {/* Tarjeta de Resumen Financiero Mensual y del Periodo */}
      {resumen && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4.5">
          <div className="bg-[#fffdf5] p-6 rounded-2xl border-2 border-[#7a4e2a] shadow-xs space-y-1.5">
            <span className="text-xs uppercase tracking-wider text-[#7a4e2a] font-bold">
              Total del Periodo Consultado
            </span>
            <p className="text-3xl sm:text-4xl font-bold text-[#7a4e2a]">
              ${Number(resumen.totalRecaudado || 0).toLocaleString('es-MX', { minimumFractionDigits: 2 })}
            </p>
            <p className="text-sm text-[#58351a]">{resumen.totalRegistros} aportaciones en este rango</p>
          </div>

          <div className="bg-[#fffdf5] p-6 rounded-2xl border-2 border-[#7a4e2a] shadow-xs space-y-1.5">
            <span className="text-xs uppercase tracking-wider text-[#7a4e2a] font-bold">
              Total Acumulado del Año
            </span>
            <p className="text-3xl sm:text-4xl font-bold text-[#7a4e2a]">
              ${Number(resumenMensual?.granTotal || 0).toLocaleString('es-MX', { minimumFractionDigits: 2 })}
            </p>
            <p className="text-sm text-[#58351a]">Ejercicio anual {resumenMensual?.anio}</p>
          </div>

          <div className="bg-[#fffdf5] p-6 rounded-2xl border-2 border-[#7a4e2a] shadow-xs space-y-1.5">
            <span className="text-xs uppercase tracking-wider text-[#7a4e2a] font-bold">
              Rubro Principal
            </span>
            <p className="text-2xl font-bold text-[#7a4e2a] truncate">
              {resumenMensual?.porConcepto?.[0]?.concepto || 'N/A'}
            </p>
            <p className="text-sm text-[#58351a]">
              ${Number(resumenMensual?.porConcepto?.[0]?.total_monto || 0).toLocaleString('es-MX', { minimumFractionDigits: 2 })}
            </p>
          </div>
        </div>
      )}

      {/* Barra de Filtros por Periodo */}
      <div className="bg-[#fffdf5] p-6 rounded-2xl border-2 border-[#7a4e2a] shadow-xs grid grid-cols-1 sm:grid-cols-3 gap-4.5">
        <div>
          <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Fecha Inicial</label>
          <input
            type="date"
            value={fechaInicio}
            onChange={(e) => setFechaInicio(e.target.value)}
            className="w-full px-4 py-2 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-sm focus:outline-none focus:bg-[#fef9c3]/30"
          />
        </div>

        <div>
          <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Fecha Final</label>
          <input
            type="date"
            value={fechaFin}
            onChange={(e) => setFechaFin(e.target.value)}
            className="w-full px-4 py-2 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-sm focus:outline-none focus:bg-[#fef9c3]/30"
          />
        </div>

        <div>
          <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Filtrar por Concepto</label>
          <select
            value={filtroConcepto}
            onChange={(e) => setFiltroConcepto(e.target.value)}
            className="w-full px-4 py-2 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-sm focus:outline-none focus:bg-[#fef9c3]/30"
          >
            <option value="">-- Todos los conceptos --</option>
            <option value="Diezmo">Diezmo</option>
            <option value="Ofrenda General">Ofrenda General</option>
            <option value="Ofrenda Misionera">Ofrenda Misionera</option>
            <option value="Pro-Templo">Pro-Templo</option>
            <option value="Evento Especial">Evento Especial</option>
          </select>
        </div>
      </div>

      {/* Tabla de Donaciones */}
      <div className="bg-[#fffdf5] rounded-3xl border-2 border-[#7a4e2a] shadow-xs overflow-hidden">
        {cargando ? (
          <div className="p-12 text-center text-sm text-[#7a4e2a] flex flex-col items-center justify-center space-y-3">
            <div className="animate-spin rounded-full h-8 w-8 border-3 border-[#7a4e2a] border-t-[#fef9c3]"></div>
            <span>Consultando registros de aportaciones...</span>
          </div>
        ) : donaciones.length === 0 ? (
          <div className="p-12 text-center text-sm text-[#7a4e2a]">
            No se encontraron aportaciones registradas en este periodo.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[#faf4ea] border-b-2 border-[#7a4e2a] text-xs font-bold text-[#7a4e2a] uppercase tracking-wider">
                  <th className="py-4 px-4 sm:px-6">Aportante</th>
                  <th className="py-4 px-4">Concepto</th>
                  <th className="py-4 px-4">Método de Pago</th>
                  <th className="py-4 px-4">Fecha</th>
                  <th className="py-4 px-4 text-right">Monto</th>
                  {(esAdmin || esTesorero) && <th className="py-4 px-4 sm:px-6 text-right">Acción</th>}
                </tr>
              </thead>
              <tbody className="divide-y border-t border-[#7a4e2a]/30 text-sm">
                {donaciones.map((d) => (
                  <tr key={d.id} className="hover:bg-[#faf4ea]/60 transition-colors">
                    <td className="py-3.5 px-4 sm:px-6">
                      <div className="flex items-center space-x-3">
                        <div
                          className={`w-8 h-8 rounded-full text-xs font-bold flex items-center justify-center shrink-0 border-2 ${
                            d.es_anonimo
                              ? 'bg-[#faf4ea] text-[#7a4e2a] border-[#7a4e2a]/50'
                              : 'bg-[#fef9c3] text-[#7a4e2a] border-[#7a4e2a]'
                          }`}
                        >
                          {d.es_anonimo ? '—' : d.aportante_nombre?.substring(0, 2).toUpperCase()}
                        </div>
                        <div>
                          <p className="font-bold text-base text-[#7a4e2a]">{d.aportante_nombre}</p>
                          {d.notas && <p className="text-xs text-[#58351a]">{d.notas}</p>}
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <span className="inline-block px-3 py-1 rounded-full text-xs font-bold bg-[#fef9c3] text-[#7a4e2a] border border-[#7a4e2a]">
                        {d.concepto}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-sm text-[#58351a]">{d.metodo_pago}</td>

                    <td className="py-3.5 px-4 text-sm text-[#58351a]">{d.fecha}</td>

                    <td className="py-3.5 px-4 text-right font-bold text-base text-[#7a4e2a]">
                      ${Number(d.monto).toLocaleString('es-MX', { minimumFractionDigits: 2 })}
                    </td>

                    {(esAdmin || esTesorero) && (
                      <td className="py-3.5 px-4 sm:px-6 text-right">
                        <button
                          onClick={() => handleEliminarDonacion(d.id)}
                          className="text-[#7a4e2a] hover:text-[#783636] font-medium underline text-sm"
                        >
                          Anular
                        </button>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modal Nueva Aportación (RF-06: fecha, monto, concepto, método de recepción, anónimo o asociado) */}
      <Modal
        isOpen={modalAbierto}
        onClose={() => setModalAbierto(false)}
        titulo="Registrar Nueva Aportación Económica"
      >
        <form onSubmit={handleGuardarDonacion} className="space-y-4 text-[#2b190a]">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1">
                Monto ($) *
              </label>
              <input
                type="number"
                step="0.01"
                min="0.01"
                required
                placeholder="0.00"
                value={formDonacion.monto}
                onChange={(e) => setFormDonacion({ ...formDonacion, monto: e.target.value })}
                className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base font-bold focus:outline-none focus:bg-[#fef9c3]/30"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1">
                Fecha de Recepción *
              </label>
              <input
                type="date"
                required
                value={formDonacion.fecha}
                onChange={(e) => setFormDonacion({ ...formDonacion, fecha: e.target.value })}
                className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Concepto *</label>
              <select
                value={formDonacion.concepto}
                onChange={(e) => setFormDonacion({ ...formDonacion, concepto: e.target.value })}
                className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
              >
                <option value="Diezmo">Diezmo</option>
                <option value="Ofrenda General">Ofrenda General</option>
                <option value="Ofrenda Misionera">Ofrenda Misionera</option>
                <option value="Pro-Templo">Pro-Templo</option>
                <option value="Evento Especial">Evento Especial</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Método de Recepción *</label>
              <select
                value={formDonacion.metodo_pago}
                onChange={(e) => setFormDonacion({ ...formDonacion, metodo_pago: e.target.value })}
                className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
              >
                <option value="Efectivo">Efectivo</option>
                <option value="Transferencia">Transferencia Bancaria</option>
                <option value="Tarjeta">Tarjeta Débito/Crédito</option>
                <option value="Cheque">Cheque</option>
                <option value="Otro">Otro</option>
              </select>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-sm font-bold text-[#7a4e2a]">Miembro Aportante</label>
              <label className="flex items-center space-x-2 text-sm text-[#58351a] cursor-pointer">
                <input
                  type="checkbox"
                  checked={formDonacion.es_anonimo}
                  onChange={(e) => setFormDonacion({ ...formDonacion, es_anonimo: e.target.checked })}
                  className="rounded border-[#7a4e2a] text-[#7a4e2a] focus:ring-0"
                />
                <span className="font-semibold">Aportación Anónima / Colecta General</span>
              </label>
            </div>

            {!formDonacion.es_anonimo ? (
              <select
                value={formDonacion.miembro_id}
                onChange={(e) => setFormDonacion({ ...formDonacion, miembro_id: e.target.value })}
                className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
              >
                <option value="">-- Seleccionar miembro de la lista --</option>
                {miembros.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.nombre}
                  </option>
                ))}
              </select>
            ) : (
              <div className="p-3 bg-[#faf4ea] border-2 border-[#7a4e2a] rounded-xl text-sm text-[#58351a]">
                La aportación se registrará como aporte anónimo de la congregación sin asociarse a una persona obligatoriamente.
              </div>
            )}
          </div>

          <div>
            <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Notas Contables</label>
            <input
              type="text"
              placeholder="Referencia de recibo, folio o notas..."
              value={formDonacion.notas}
              onChange={(e) => setFormDonacion({ ...formDonacion, notas: e.target.value })}
              className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
            />
          </div>

          <div className="flex justify-end space-x-3 pt-4 border-t-2 border-[#7a4e2a]">
            <button
              type="button"
              onClick={() => setModalAbierto(false)}
              className="px-5 py-2.5 border-2 border-[#7a4e2a] rounded-xl text-sm text-[#7a4e2a] hover:bg-[#faf4ea] font-bold"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={guardando}
              className="px-6 py-2.5 bg-[#fef9c3] hover:bg-[#ebd8c3] text-[#7a4e2a] border-2 border-[#7a4e2a] rounded-xl text-sm font-bold transition-all disabled:opacity-50"
            >
              {guardando ? 'Guardando...' : 'Asentar Aportación'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
