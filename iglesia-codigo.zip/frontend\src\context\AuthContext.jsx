/**
 * Contexto de Autenticación y Autorización Global (RF-01).
 * Administra el estado de la sesión, persistencia de credenciales en localStorage
 * y utilidades de verificación de los 5 roles del sistema.
 */
import React, { createContext, useContext, useState, useEffect } from 'react';
import { authService } from '../services/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [usuario, setUsuario] = useState(() => {
    const guardado = localStorage.getItem('iglesia_usuario');
    return guardado ? JSON.parse(guardado) : null;
  });
  const [token, setToken] = useState(() => localStorage.getItem('iglesia_token'));
  const [cargando, setCargando] = useState(true);

  // Validar sesión al cargar la app
  useEffect(() => {
    async function verificarSesion() {
      if (token) {
        try {
          const res = await authService.perfil();
          setUsuario(res.usuario);
          localStorage.setItem('iglesia_usuario', JSON.stringify(res.usuario));
        } catch (error) {
          logout();
        }
      }
      setCargando(false);
    }
    verificarSesion();
  }, [token]);

  /**
   * Iniciar sesión con email y contraseña
   */
  async function login(email, password) {
    const res = await authService.login({ email, password });
    setToken(res.token);
    setUsuario(res.usuario);
    localStorage.setItem('iglesia_token', res.token);
    localStorage.setItem('iglesia_usuario', JSON.stringify(res.usuario));
    return res.usuario;
  }

  /**
   * Registro de un nuevo usuario
   */
  async function registro(datos) {
    return await authService.registro(datos);
  }

  /**
   * Cerrar sesión y limpiar almacenamiento local
   */
  function logout() {
    setToken(null);
    setUsuario(null);
    localStorage.removeItem('iglesia_token');
    localStorage.removeItem('iglesia_usuario');
  }

  // Verificadores de roles y capacidades de negocio
  const esAdmin = usuario?.rol === 'Administrador';
  const esPastor = usuario?.rol === 'Pastor';
  const esTesorero = usuario?.rol === 'Tesorero';
  const esSecretario = usuario?.rol === 'Secretario';
  const esCoordinador = usuario?.rol === 'Coordinador';

  // RF-06: Restricción de información financiera exclusiva
  const puedeVerFinanzas = ['Administrador', 'Pastor', 'Tesorero'].includes(usuario?.rol);
  const puedeGestionarMiembros = ['Administrador', 'Pastor', 'Secretario'].includes(usuario?.rol);
  const puedeGestionarEventos = ['Administrador', 'Pastor', 'Secretario', 'Coordinador'].includes(usuario?.rol);
  const puedeGestionarConfiguracion = ['Administrador', 'Pastor'].includes(usuario?.rol);

  return (
    <AuthContext.Provider
      value={{
        usuario,
        token,
        cargando,
        estaAutenticado: !!usuario && !!token,
        login,
        registro,
        logout,
        esAdmin,
        esPastor,
        esTesorero,
        esSecretario,
        esCoordinador,
        puedeVerFinanzas,
        puedeGestionarMiembros,
        puedeGestionarEventos,
        puedeGestionarConfiguracion,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth debe ser utilizado dentro de un AuthProvider');
  }
  return context;
}
