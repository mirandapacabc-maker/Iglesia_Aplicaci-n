/**
 * Vista de Panel Principal (Dashboard) Eclesiástico (RF-08).
 * Predominante: #fffdf5, Contorno: #7a4e2a, Blanco, Beige (#faf4ea, #f5ede1) y Amarillo Pálido #fef9c3.
 * Tipografía: Day Roman Regular (sin iconos, letras más grandes y legibles).
 */
import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { dashboardService } from '../services/api';
import StatCard from '../components/StatCard';

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from 'chart.js';
import { Bar, Doughnut } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

export default function DashboardView({ onNavegar }) {
  const { usuario, puedeVerFinanzas } = useAuth();
  const [datos, setDatos] = useState(null);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    async function cargarMetricas() {
      try {
        setCargando(true);
        const res = await dashboardService.obtenerMetricas();
        setDatos(res);
      } catch (err) {
        setError(err.message || 'Error al cargar las métricas pastorales.');
      } finally {
        setCargando(false);
      }
    }
    cargarMetricas();
  }, []);

  if (cargando) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] space-y-3 font-serif">
        <div className="animate-spin rounded-full h-9 w-9 border-3 border-[#7a4e2a] border-t-[#fef9c3]"></div>
        <p className="text-sm text-[#7a4e2a]">Cargando información congregacional...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-5 bg-[#fff2f0] border-2 border-[#7a4e2a] rounded-2xl text-[#783636] text-sm font-serif">
        {error}
      </div>
    );
  }

  const { metricas, eventosProximos, asistenciasRecientes, anunciosDestacados, finanzas } = datos || {};

  // Configuración de gráfica de asistencia por evento
  const labelsAsistencia = (asistenciasRecientes || []).map((a) => a.fecha.substring(5));
  const dataPresentes = (asistenciasRecientes || []).map((a) => a.presentes);
  const dataAusentes = (asistenciasRecientes || []).map((a) => a.ausentes);

  const chartAsistenciaData = {
    labels: labelsAsistencia.reverse(),
    datasets: [
      {
        label: 'Presentes',
        data: dataPresentes.reverse(),
        backgroundColor: '#7a4e2a',
        borderRadius: 4,
      },
      {
        label: 'Ausentes',
        data: dataAusentes.reverse(),
        backgroundColor: '#f5ede1',
        borderColor: '#7a4e2a',
        borderWidth: 1,
        borderRadius: 4,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
        labels: { boxWidth: 14, font: { family: 'Day Roman', size: 13, weight: 'bold' } },
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: { stepSize: 2, font: { family: 'Day Roman', size: 12 } },
        grid: { color: '#ebd8c3' },
      },
      x: {
        ticks: { font: { family: 'Day Roman', size: 12 } },
        grid: { display: false },
      },
    },
  };

  // Configuración de gráfica de donaciones por concepto (solo roles financieros)
  const conceptosLabels = finanzas?.porConcepto?.map((c) => c.concepto) || [];
  const conceptosValores = finanzas?.porConcepto?.map((c) => c.total) || [];

  const chartFinanzasData = {
    labels: conceptosLabels,
    datasets: [
      {
        data: conceptosValores,
        backgroundColor: ['#7a4e2a', '#fef08a', '#ad7e54', '#ebd8c3', '#58351a'],
        borderColor: '#7a4e2a',
        borderWidth: 1,
      },
    ],
  };

  return (
    <div className="space-y-7 text-[#2b190a] font-serif">
      {/* Saludo y bienvenida pastoral sobrio y humano */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-[#fffdf5] border-2 border-[#7a4e2a] p-7 rounded-3xl shadow-xs">
        <div>
          <span className="text-xs uppercase tracking-wider text-[#7a4e2a] font-bold">
            Panel de Administración de la Iglesia
          </span>
          <h1 className="text-3xl sm:text-4xl text-[#7a4e2a] mt-1 font-normal">
            Paz y gracia, {usuario?.nombre?.split(' ')[0]}
          </h1>
          <p className="text-sm text-[#58351a] mt-1.5 max-w-xl">
            Resumen general de las actividades y vida congregacional. Responsabilidad actual: <span className="font-bold text-[#7a4e2a]">{usuario?.rol}</span>.
          </p>
        </div>

        {/* Acciones directas sobrias */}
        <div className="flex flex-wrap gap-2.5">
          <button
            onClick={() => onNavegar('asistencia')}
            className="px-5 py-2.5 bg-[#fef9c3] hover:bg-[#ebd8c3] border-2 border-[#7a4e2a] rounded-xl text-sm font-bold text-[#7a4e2a] transition-colors shadow-xs"
          >
            Pasar Lista
          </button>
          <button
            onClick={() => onNavegar('eventos')}
            className="px-5 py-2.5 bg-[#f5ede1] hover:bg-[#fffdf5] border-2 border-[#7a4e2a] text-[#7a4e2a] rounded-xl text-sm font-bold transition-colors"
          >
            Ver Calendario
          </button>
        </div>
      </div>

      {/* TARJETAS MÉTRICAS PASTORALES (RF-08) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4.5">
        <StatCard
          titulo="Miembros Activos"
          valor={metricas?.totalMiembrosActivos ?? 0}
          subtitulo={`${metricas?.totalMiembrosInactivos || 0} hermanos inactivos`}
        />

        <StatCard
          titulo="Eventos Próximos"
          valor={metricas?.totalEventosProximos ?? 0}
          subtitulo="Programados en agenda"
        />

        <StatCard
          titulo="Asistencias Registradas"
          valor={metricas?.totalAsistenciasUltimoMes ?? 0}
          subtitulo="En los últimos 30 días"
        />

        <StatCard
          titulo="Ministerios Activos"
          valor={metricas?.totalMinisteriosActivos ?? 0}
          subtitulo="Grupos de trabajo en servicio"
        />
      </div>

      {/* TARJETA FINANCIERA PROTEGIDA (RF-08: únicamente roles autorizados) */}
      {puedeVerFinanzas && finanzas && (
        <div className="bg-[#faf4ea] rounded-3xl p-7 border-2 border-[#7a4e2a] text-[#2b190a] shadow-xs">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div>
              <span className="text-xs uppercase tracking-wider text-[#7a4e2a] font-bold">
                Resumen de Ingresos del Mes (Acceso Autorizado)
              </span>
              <div className="mt-2 flex items-baseline space-x-3.5">
                <span className="text-3xl sm:text-4xl font-bold text-[#7a4e2a] tracking-tight">
                  ${Number(finanzas.totalMes).toLocaleString('es-MX', { minimumFractionDigits: 2 })}
                </span>
                <span className="text-sm text-[#58351a]">
                  ({finanzas.totalTransacciones} aportaciones registradas este mes)
                </span>
              </div>
              <p className="text-xs text-[#7a4e2a] mt-1.5 font-medium">
                Información confidencial reservada para Administración, Pastoral y Tesorería.
              </p>
            </div>

            <button
              onClick={() => onNavegar('donaciones')}
              className="px-5 py-2.5 bg-[#fef9c3] hover:bg-[#ebd8c3] text-[#7a4e2a] border-2 border-[#7a4e2a] rounded-xl text-sm font-bold transition-all shadow-xs shrink-0"
            >
              Consultar Aportaciones
            </button>
          </div>
        </div>
      )}

      {/* GRÁFICAS ESTADÍSTICAS */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Gráfica de Asistencia Reciente */}
        <div className={`bg-[#fffdf5] p-6 rounded-3xl border-2 border-[#7a4e2a] shadow-xs ${puedeVerFinanzas ? 'lg:col-span-2' : 'lg:col-span-3'}`}>
          <div className="flex items-center justify-between mb-4 pb-3 border-b-2 border-[#7a4e2a]/30">
            <div>
              <h3 className="text-lg font-bold text-[#7a4e2a]">Asistencia por Evento Reciente</h3>
              <p className="text-xs text-[#58351a]">Registro de presencia y ausencia de hermanos</p>
            </div>
            <button
              onClick={() => onNavegar('asistencia')}
              className="text-sm text-[#7a4e2a] hover:text-[#2b190a] hover:underline font-bold"
            >
              Ver registro completo
            </button>
          </div>
          <div className="h-64">
            {asistenciasRecientes && asistenciasRecientes.length > 0 ? (
              <Bar data={chartAsistenciaData} options={chartOptions} />
            ) : (
              <div className="h-full flex items-center justify-center text-sm text-[#7a4e2a]">
                No hay registros de asistencia recientes.
              </div>
            )}
          </div>
        </div>

        {/* Gráfica de Conceptos de Donación */}
        {puedeVerFinanzas && finanzas && (
          <div className="bg-[#fffdf5] p-6 rounded-3xl border-2 border-[#7a4e2a] shadow-xs">
            <h3 className="text-lg font-bold text-[#7a4e2a]">Distribución de Ingresos</h3>
            <p className="text-xs text-[#58351a] mb-4 pb-3 border-b-2 border-[#7a4e2a]/30">
              Conceptos de aportación del mes
            </p>
            <div className="h-56 flex items-center justify-center">
              {conceptosLabels.length > 0 ? (
                <Doughnut
                  data={chartFinanzasData}
                  options={{
                    maintainAspectRatio: false,
                    plugins: { legend: { position: 'bottom', labels: { boxWidth: 12, font: { family: 'Day Roman', size: 12 } } } },
                  }}
                />
              ) : (
                <p className="text-sm text-[#7a4e2a]">Sin aportaciones este mes.</p>
              )}
            </div>
          </div>
        )}
      </div>

      {/* PRÓXIMOS EVENTOS Y COMUNICADOS DESTACADOS */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Próximos Cultos y Eventos */}
        <div className="bg-[#fffdf5] p-6 rounded-3xl border-2 border-[#7a4e2a] shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b-2 border-[#7a4e2a]/30">
            <div>
              <h3 className="text-lg font-bold text-[#7a4e2a]">Próximos Eventos y Cultos</h3>
              <p className="text-xs text-[#58351a]">Actividades en el calendario</p>
            </div>
            <button
              onClick={() => onNavegar('eventos')}
              className="text-sm text-[#7a4e2a] hover:text-[#2b190a] hover:underline font-bold"
            >
              Ver calendario
            </button>
          </div>

          <div className="space-y-3">
            {eventosProximos && eventosProximos.length > 0 ? (
              eventosProximos.map((ev) => (
                <div
                  key={ev.id}
                  className="p-4 rounded-xl bg-[#faf4ea] border border-[#7a4e2a] hover:bg-[#fef9c3]/50 transition-colors flex items-center justify-between"
                >
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2.5">
                      <span className="text-sm font-bold text-[#7a4e2a]">{ev.titulo}</span>
                      <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#fef9c3] text-[#7a4e2a] border border-[#7a4e2a] font-bold">
                        {ev.tipo}
                      </span>
                    </div>
                    <div className="flex items-center space-x-4 text-xs text-[#58351a]">
                      <span>{ev.fecha} • {ev.hora} hrs</span>
                      <span>Lugar: {ev.lugar}</span>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-sm text-[#7a4e2a] py-4 text-center">
                No hay actividades próximas programadas.
              </p>
            )}
          </div>
        </div>

        {/* Avisos de la Comunidad */}
        <div className="bg-[#fffdf5] p-6 rounded-3xl border-2 border-[#7a4e2a] shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b-2 border-[#7a4e2a]/30">
            <div>
              <h3 className="text-lg font-bold text-[#7a4e2a]">Avisos y Comunicados</h3>
              <p className="text-xs text-[#58351a]">Publicaciones para la congregación</p>
            </div>
            <button
              onClick={() => onNavegar('anuncios')}
              className="text-sm text-[#7a4e2a] hover:text-[#2b190a] hover:underline font-bold"
            >
              Ver todos
            </button>
          </div>

          <div className="space-y-3">
            {anunciosDestacados && anunciosDestacados.length > 0 ? (
              anunciosDestacados.map((an) => (
                <div key={an.id} className="p-4 rounded-xl bg-[#faf4ea] border border-[#7a4e2a] space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-bold text-[#7a4e2a]">{an.titulo}</span>
                    <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#fef9c3] text-[#7a4e2a] border border-[#7a4e2a] font-bold">
                      {an.categoria}
                    </span>
                  </div>
                  <p className="text-xs text-[#58351a] line-clamp-2">{an.contenido}</p>
                </div>
              ))
            ) : (
              <p className="text-sm text-[#7a4e2a] py-4 text-center">
                No hay comunicados destacados en este momento.
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
