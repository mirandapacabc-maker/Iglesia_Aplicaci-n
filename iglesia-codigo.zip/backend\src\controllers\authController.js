/**
 * Controlador de Autenticación y Gestión de Usuarios (RF-01).
 * Implementa registro, inicio de sesión, recuperación de contraseña y perfiles con los 5 roles.
 */
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const db = require('../config/database');
const { JWT_SECRET } = require('../middleware/authMiddleware');
const emailService = require('../services/emailService');

const ROLES_VALIDOS = ['Administrador', 'Pastor', 'Secretario', 'Tesorero', 'Coordinador'];

/**
 * Registro de un nuevo usuario en el sistema.
 */
function registrar(req, res, next) {
  try {
    const { nombre, email, password, rol, telefono } = req.body;

    if (!nombre || !email || !password || !rol) {
      return res.status(400).json({ mensaje: 'Todos los campos obligatorios deben ser completados.' });
    }

    if (!ROLES_VALIDOS.includes(rol)) {
      return res.status(400).json({ mensaje: `El rol '${rol}' no es válido. Roles válidos: ${ROLES_VALIDOS.join(', ')}` });
    }

    // Comprobar existencia previa de email
    const usuarioExistente = db.prepare('SELECT id FROM usuarios WHERE email = ?').get(email.toLowerCase().trim());
    if (usuarioExistente) {
      return res.status(409).json({ mensaje: 'Ya existe una cuenta registrada con este correo electrónico.' });
    }

    const passwordHash = bcrypt.hashSync(password, 10);
    const result = db.prepare(`
      INSERT INTO usuarios (nombre, email, password_hash, rol, telefono, activo)
      VALUES (?, ?, ?, ?, ?, 1)
    `).run(nombre.trim(), email.toLowerCase().trim(), passwordHash, rol, telefono ? telefono.trim() : null);

    const nuevoUsuario = db.prepare('SELECT id, nombre, email, rol, telefono, activo, creado_en FROM usuarios WHERE id = ?').get(result.lastInsertRowid);

    // Si el usuario no existe en el directorio de miembros, crearlo automáticamente
    const miembroExistente = db.prepare('SELECT id FROM miembros WHERE email = ?').get(email.toLowerCase().trim());
    if (!miembroExistente) {
      db.prepare(`
        INSERT INTO miembros (nombre, telefono, email, fecha_ingreso, activo, notas)
        VALUES (?, ?, ?, date('now', 'localtime'), 1, ?)
      `).run(nombre.trim(), telefono ? telefono.trim() : null, email.toLowerCase().trim(), `Usuario del sistema con rol: ${rol}`);
    }

    // Generar token JWT inmediatamente para permitir inicio de sesión automático opcional
    const token = jwt.sign(
      { id: nuevoUsuario.id, email: nuevoUsuario.email, rol: nuevoUsuario.rol },
      JWT_SECRET,
      { expiresIn: '8h' }
    );

    return res.status(201).json({
      mensaje: 'Usuario registrado exitosamente.',
      token,
      usuario: {
        id: nuevoUsuario.id,
        nombre: nuevoUsuario.nombre,
        email: nuevoUsuario.email,
        rol: nuevoUsuario.rol,
        telefono: nuevoUsuario.telefono
      }
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Inicio de sesión con correo y contraseña. Genera JWT con 8 horas de vigencia.
 */
function login(req, res, next) {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ mensaje: 'Por favor ingresa correo y contraseña.' });
    }

    const usuario = db.prepare(`
      SELECT id, nombre, email, password_hash, rol, telefono, activo 
      FROM usuarios 
      WHERE email = ?
    `).get(email.toLowerCase().trim());

    if (!usuario) {
      return res.status(401).json({ mensaje: 'Credenciales inválidas. Verifica tu correo o contraseña.' });
    }

    if (!usuario.activo) {
      return res.status(403).json({ mensaje: 'Tu cuenta ha sido desactivada por un administrador.' });
    }

    const passwordValido = bcrypt.compareSync(password, usuario.password_hash);
    if (!passwordValido) {
      return res.status(401).json({ mensaje: 'Credenciales inválidas. Verifica tu correo o contraseña.' });
    }

    const token = jwt.sign(
      { id: usuario.id, email: usuario.email, rol: usuario.rol },
      JWT_SECRET,
      { expiresIn: '8h' }
    );

    return res.json({
      mensaje: 'Inicio de sesión exitoso.',
      token,
      usuario: {
        id: usuario.id,
        nombre: usuario.nombre,
        email: usuario.email,
        rol: usuario.rol,
        telefono: usuario.telefono
      }
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Obtiene la información del usuario autenticado actual.
 */
function perfilActual(req, res) {
  return res.json({
    usuario: req.usuario
  });
}

/**
 * Solicitud de restablecimiento de contraseña (RF-01).
 * Genera un token/código temporal de recuperación.
 */
async function solicitarRecuperacion(req, res, next) {
  try {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ mensaje: 'Debes proporcionar un correo electrónico válido.' });
    }

    const usuario = db.prepare('SELECT id, email, nombre FROM usuarios WHERE email = ? AND activo = 1').get(email.toLowerCase().trim());

    if (!usuario) {
      // Por seguridad evitamos enumerar correos
      return res.json({
        mensaje: 'Si el correo existe en nuestro sistema, se han generado las instrucciones de recuperación.'
      });
    }

    // Generar código de 6 dígitos numéricos para fácil introducción móvil y web
    const resetToken = Math.floor(100000 + Math.random() * 900000).toString();
    const expira = new Date(Date.now() + 60 * 60 * 1000).toISOString(); // 1 hora de vigencia

    db.prepare('UPDATE usuarios SET reset_token = ?, reset_token_expira = ? WHERE id = ?').run(resetToken, expira, usuario.id);

    // Enviar correo a través de Google Gmail API / SMTP
    const resultadoEnvio = await emailService.enviarCodigoRecuperacion(usuario.email, resetToken, usuario.nombre);

    const respuesta = {
      mensaje: resultadoEnvio.enviado 
        ? 'Se ha enviado un correo con el código de recuperación a tu dirección Gmail.' 
        : 'Código de recuperación generado correctamente.',
      servicioGmail: resultadoEnvio.enviado ? 'correo_enviado' : 'simulado'
    };

    // Para facilitar pruebas en desarrollo si no hay credenciales Gmail activas:
    if (process.env.NODE_ENV !== 'production' || !resultadoEnvio.enviado) {
      respuesta.codigoRecuperacionSimulado = resetToken;
    }

    return res.json(respuesta);
  } catch (error) {
    next(error);
  }
}

/**
 * Restablece la contraseña utilizando el código de recuperación.
 */
function restablecerPassword(req, res, next) {
  try {
    const { email, codigo, nuevoPassword } = req.body;

    if (!email || !codigo || !nuevoPassword) {
      return res.status(400).json({ mensaje: 'Todos los campos son requeridos.' });
    }

    if (nuevoPassword.length < 6) {
      return res.status(400).json({ mensaje: 'La nueva contraseña debe tener al menos 6 caracteres.' });
    }

    const usuario = db.prepare(`
      SELECT id, reset_token, reset_token_expira 
      FROM usuarios 
      WHERE email = ? AND reset_token = ?
    `).get(email.toLowerCase().trim(), String(codigo).trim());

    if (!usuario) {
      return res.status(400).json({ mensaje: 'Código de recuperación inválido o inexistente.' });
    }

    const ahora = new Date().toISOString();
    if (usuario.reset_token_expira < ahora) {
      return res.status(400).json({ mensaje: 'El código de recuperación ha expirado. Solicita uno nuevo.' });
    }

    const nuevoHash = bcrypt.hashSync(nuevoPassword, 10);
    db.prepare(`
      UPDATE usuarios 
      SET password_hash = ?, reset_token = NULL, reset_token_expira = NULL 
      WHERE id = ?
    `).run(nuevoHash, usuario.id);

    return res.json({ mensaje: 'Contraseña restablecida con éxito. Ya puedes iniciar sesión con tu nueva clave.' });
  } catch (error) {
    next(error);
  }
}

/**
 * Listado de usuarios del sistema (solo accesible por Administrador).
 */
function listarUsuarios(req, res, next) {
  try {
    const usuarios = db.prepare(`
      SELECT id, nombre, email, rol, telefono, activo, creado_en 
      FROM usuarios 
      ORDER BY nombre ASC
    `).all();

    return res.json({ usuarios });
  } catch (error) {
    next(error);
  }
}

/**
 * Cambio de estado activo/inactivo de un usuario (solo Administrador).
 */
function cambiarEstadoUsuario(req, res, next) {
  try {
    const { id } = req.params;
    const { activo } = req.body;

    if (Number(id) === req.usuario.id) {
      return res.status(400).json({ mensaje: 'No puedes desactivar tu propia cuenta de administrador.' });
    }

    db.prepare('UPDATE usuarios SET activo = ? WHERE id = ?').run(activo ? 1 : 0, id);
    return res.json({ mensaje: `Usuario ${activo ? 'activado' : 'desactivado'} correctamente.` });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  registrar,
  login,
  perfilActual,
  solicitarRecuperacion,
  restablecerPassword,
  listarUsuarios,
  cambiarEstadoUsuario
};
