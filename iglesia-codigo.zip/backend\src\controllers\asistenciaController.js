/**
 * Controlador de Control de Asistencia a Cultos y Actividades (RF-03).
 * Soporta registro en lote para listas dinámicas, consulta por evento y por miembro, y métricas periódicas.
 */
const db = require('../config/database');

/**
 * Obtener la plantilla de miembros para pasar lista en un evento y fecha determinados.
 * Si ya se registraron asistencias previamente, retorna los estados guardados.
 */
function obtenerHojaAsistencia(req, res, next) {
  try {
    const { eventoId, fecha } = req.query;

    if (!eventoId) {
      return res.status(400).json({ mensaje: 'El ID del evento es obligatorio.' });
    }

    const evento = db.prepare('SELECT id, titulo, fecha, hora FROM eventos WHERE id = ?').get(eventoId);
    if (!evento) {
      return res.status(404).json({ mensaje: 'Evento no encontrado.' });
    }

    const fechaAsistencia = fecha || evento.fecha;

    // Obtener todos los miembros activos junto con su estado de asistencia previo (si existe)
    const registros = db.prepare(`
      SELECT 
        m.id AS miembro_id,
        m.nombre,
        m.telefono,
        COALESCE(a.estado, 'Ausente') AS estado,
        a.observaciones,
        a.id AS asistencia_id
      FROM miembros m
      LEFT JOIN asistencias a ON a.miembro_id = m.id AND a.evento_id = ? AND a.fecha = ?
      WHERE m.activo = 1
      ORDER BY m.nombre ASC
    `).all(eventoId, fechaAsistencia);

    return res.json({
      evento,
      fecha: fechaAsistencia,
      registros
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Guardar o actualizar la lista completa de asistencia para un evento y fecha (registro dinámico rápido).
 */
function registrarAsistenciaLote(req, res, next) {
  try {
    const { eventoId, fecha, asistencias } = req.body;

    if (!eventoId || !fecha || !Array.isArray(asistencias)) {
      return res.status(400).json({ mensaje: 'Datos incompletos. Se requiere eventoId, fecha y lista de asistencias.' });
    }

    // Usar transacción para guardar de manera atómica
    const upsertStmt = db.prepare(`
      INSERT INTO asistencias (evento_id, miembro_id, fecha, estado, observaciones)
      VALUES (?, ?, ?, ?, ?)
      ON CONFLICT(evento_id, miembro_id, fecha) DO UPDATE SET
        estado = excluded.estado,
        observaciones = excluded.observaciones,
        registrado_en = CURRENT_TIMESTAMP
    `);

    db.exec('BEGIN TRANSACTION');
    try {
      for (const item of asistencias) {
        upsertStmt.run(
          eventoId,
          item.miembro_id,
          fecha,
          item.estado || 'Ausente',
          item.observaciones || null
        );
      }
      db.exec('COMMIT');
    } catch (err) {
      db.exec('ROLLBACK');
      throw err;
    }

    return res.json({
      mensaje: `Asistencia guardada exitosamente (${asistencias.length} miembros procesados).`
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Consulta del historial de asistencia de un miembro individual.
 */
function historialPorMiembro(req, res, next) {
  try {
    const { miembroId } = req.params;

    const miembro = db.prepare('SELECT id, nombre FROM miembros WHERE id = ?').get(miembroId);
    if (!miembro) {
      return res.status(404).json({ mensaje: 'Miembro no encontrado.' });
    }

    const historial = db.prepare(`
      SELECT 
        a.id, a.fecha, a.estado, a.observaciones, a.registrado_en,
        e.id AS evento_id, e.titulo AS evento_titulo, e.tipo AS evento_tipo
      FROM asistencias a
      JOIN eventos e ON a.evento_id = e.id
      WHERE a.miembro_id = ?
      ORDER BY a.fecha DESC
    `).all(miembroId);

    // Resumen de estadísticas individuales
    const totalPresentes = historial.filter((h) => h.estado === 'Presente').length;
    const totalAusentes = historial.filter((h) => h.estado === 'Ausente').length;
    const porcentaje = historial.length > 0 ? Math.round((totalPresentes / historial.length) * 100) : 0;

    return res.json({
      miembro,
      estadisticas: {
        totalRegistros: historial.length,
        totalPresentes,
        totalAusentes,
        porcentajeAsistencia: porcentaje
      },
      historial
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Reporte consolidado de asistencia semanal o mensual con totales.
 */
function reporteAsistenciaPeriodo(req, res, next) {
  try {
    const { tipo = 'mensual', fechaInicio, fechaFin } = req.query;

    let condicionFecha = '';
    let parametros = [];

    if (fechaInicio && fechaFin) {
      condicionFecha = 'WHERE a.fecha BETWEEN ? AND ?';
      parametros = [fechaInicio, fechaFin];
    } else {
      // Por defecto últimos 30 días
      condicionFecha = "WHERE a.fecha >= date('now', '-30 days')";
    }

    const query = `
      SELECT 
        e.id AS evento_id,
        e.titulo AS evento_titulo,
        e.tipo AS evento_tipo,
        a.fecha,
        SUM(CASE WHEN a.estado = 'Presente' THEN 1 ELSE 0 END) AS presentes,
        SUM(CASE WHEN a.estado = 'Ausente' THEN 1 ELSE 0 END) AS ausentes,
        COUNT(a.id) AS total_convocados
      FROM asistencias a
      JOIN eventos e ON a.evento_id = e.id
      ${condicionFecha}
      GROUP BY a.evento_id, a.fecha
      ORDER BY a.fecha DESC
    `;

    const resumen = db.prepare(query).all(...parametros);

    return res.json({ resumen });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  obtenerHojaAsistencia,
  registrarAsistenciaLote,
  historialPorMiembro,
  reporteAsistenciaPeriodo
};
