/**
 * Controlador de Gestión de Donaciones y Aportaciones Financieras (RF-06).
 * Incorpora reglas de seguridad financiera estricta: solo accesible por Administrador, Pastor y Tesorero.
 * Soporta aportaciones anónimas o vinculadas a miembros, filtros periódicos y resúmenes mensuales.
 */
const db = require('../config/database');

const METODOS_PAGO_VALIDOS = ['Efectivo', 'Transferencia', 'Tarjeta', 'Cheque', 'Otro'];

/**
 * Listado de donaciones con filtros por rango de fechas, concepto o miembro.
 */
function listarDonaciones(req, res, next) {
  try {
    const { fechaInicio, fechaFin, concepto, esAnonimo, pagina = 1, limite = 15 } = req.query;

    const limitNum = Math.max(1, parseInt(limite, 10));
    const offset = (Math.max(1, parseInt(pagina, 10)) - 1) * limitNum;

    let condiciones = [];
    let parametros = [];

    if (fechaInicio) {
      condiciones.push('d.fecha >= ?');
      parametros.push(fechaInicio);
    }
    if (fechaFin) {
      condiciones.push('d.fecha <= ?');
      parametros.push(fechaFin);
    }
    if (concepto) {
      condiciones.push('d.concepto = ?');
      parametros.push(concepto);
    }
    if (esAnonimo !== undefined && esAnonimo !== '') {
      condiciones.push('d.es_anonimo = ?');
      parametros.push(esAnonimo === 'true' || esAnonimo === '1' ? 1 : 0);
    }

    const whereClause = condiciones.length > 0 ? `WHERE ${condiciones.join(' AND ')}` : '';

    // Cálculo del gran total del filtro actual
    const totalesQuery = `
      SELECT COUNT(*) as total_registros, COALESCE(SUM(monto), 0) as total_monto
      FROM donaciones d
      ${whereClause}
    `;
    const totales = db.prepare(totalesQuery).get(...parametros);

    // Consulta de registros paginados
    const query = `
      SELECT 
        d.id, d.fecha, d.monto, d.concepto, d.metodo_pago, d.es_anonimo, d.notas, d.creado_en,
        d.miembro_id,
        CASE WHEN d.es_anonimo = 1 THEN 'Anónimo' ELSE m.nombre END AS aportante_nombre,
        u.nombre AS registrado_por_nombre
      FROM donaciones d
      LEFT JOIN miembros m ON d.miembro_id = m.id
      LEFT JOIN usuarios u ON d.registrado_por = u.id
      ${whereClause}
      ORDER BY d.fecha DESC, d.id DESC
      LIMIT ? OFFSET ?
    `;

    const donaciones = db.prepare(query).all(...parametros, limitNum, offset);

    return res.json({
      donaciones,
      resumen: {
        totalRegistros: totales.total_registros,
        totalRecaudado: totales.total_monto,
        pagina: parseInt(pagina, 10),
        limite: limitNum,
        totalPaginas: Math.ceil(totales.total_registros / limitNum)
      }
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Registro de una nueva aportación económica (con soporte anónimo).
 */
function registrarDonacion(req, res, next) {
  try {
    const { fecha, monto, concepto, metodo_pago, miembro_id, es_anonimo, notas } = req.body;

    if (!fecha || !monto || !concepto || !metodo_pago) {
      return res.status(400).json({ mensaje: 'Fecha, monto, concepto y método de pago son obligatorios.' });
    }

    const montoNum = parseFloat(monto);
    if (isNaN(montoNum) || montoNum <= 0) {
      return res.status(400).json({ mensaje: 'El monto debe ser una cifra numérica mayor a cero.' });
    }

    if (!METODOS_PAGO_VALIDOS.includes(metodo_pago)) {
      return res.status(400).json({ mensaje: `Método de pago no válido. Opciones: ${METODOS_PAGO_VALIDOS.join(', ')}` });
    }

    const flagAnonimo = es_anonimo || !miembro_id ? 1 : 0;
    const miembroFinalId = flagAnonimo ? null : miembro_id;

    const resultado = db.prepare(`
      INSERT INTO donaciones (fecha, monto, concepto, metodo_pago, miembro_id, es_anonimo, notas, registrado_por)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      fecha,
      montoNum,
      concepto.trim(),
      metodo_pago,
      miembroFinalId,
      flagAnonimo,
      notas ? notas.trim() : null,
      req.usuario.id
    );

    const nuevaDonacion = db.prepare(`
      SELECT d.*, CASE WHEN d.es_anonimo = 1 THEN 'Anónimo' ELSE m.nombre END AS aportante_nombre
      FROM donaciones d
      LEFT JOIN miembros m ON d.miembro_id = m.id
      WHERE d.id = ?
    `).get(resultado.lastInsertRowid);

    return res.status(201).json({
      mensaje: 'Aportación registrada con éxito.',
      donacion: nuevaDonacion
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Resumen consolidado mensual de ingresos para métricas y gráficos estadísticos.
 */
function resumenMensualIngresos(req, res, next) {
  try {
    const { anio = new Date().getFullYear() } = req.query;

    // Agrupación mensual
    const mensual = db.prepare(`
      SELECT 
        strftime('%m', fecha) AS mes,
        COUNT(id) AS total_aportaciones,
        SUM(monto) AS total_ingresos
      FROM donaciones
      WHERE strftime('%Y', fecha) = ?
      GROUP BY strftime('%m', fecha)
      ORDER BY mes ASC
    `).all(String(anio));

    // Agrupación por conceptos (Diezmo, Ofrenda, Pro-templo, etc.)
    const porConcepto = db.prepare(`
      SELECT 
        concepto,
        COUNT(id) AS total_transacciones,
        SUM(monto) AS total_monto
      FROM donaciones
      WHERE strftime('%Y', fecha) = ?
      GROUP BY concepto
      ORDER BY total_monto DESC
    `).all(String(anio));

    // Agrupación por método de pago
    const porMetodo = db.prepare(`
      SELECT 
        metodo_pago,
        COUNT(id) AS transacciones,
        SUM(monto) AS total_monto
      FROM donaciones
      WHERE strftime('%Y', fecha) = ?
      GROUP BY metodo_pago
      ORDER BY total_monto DESC
    `).all(String(anio));

    const granTotal = mensual.reduce((sum, item) => sum + (item.total_ingresos || 0), 0);

    return res.json({
      anio: parseInt(anio, 10),
      granTotal,
      mensual,
      porConcepto,
      porMetodo
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Eliminar registro de donación (solo Administrador o Tesorero).
 */
function eliminarDonacion(req, res, next) {
  try {
    const { id } = req.params;

    const donacion = db.prepare('SELECT id FROM donaciones WHERE id = ?').get(id);
    if (!donacion) {
      return res.status(404).json({ mensaje: 'Registro de aportación no encontrado.' });
    }

    db.prepare('DELETE FROM donaciones WHERE id = ?').run(id);

    return res.json({ mensaje: 'Registro de donación eliminado.' });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  listarDonaciones,
  registrarDonacion,
  resumenMensualIngresos,
  eliminarDonacion
};
