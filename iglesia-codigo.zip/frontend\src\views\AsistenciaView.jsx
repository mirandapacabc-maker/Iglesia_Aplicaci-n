/**
 * Vista de Control de Asistencia a Cultos y Actividades (RF-03).
 * Predominante: #fffdf5, Contorno: #7a4e2a, Blanco, Beige (#faf4ea, #f5ede1) y Amarillo Pálido #fef9c3.
 * Tipografía: Day Roman Regular (sin iconos, letras más grandes y legibles).
 */
import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { asistenciaService, eventosService, miembrosService } from '../services/api';
import Modal from '../components/Modal';

export default function AsistenciaView() {
  const { puedeGestionarEventos } = useAuth();

  const [eventos, setEventos] = useState([]);
  const [eventoSeleccionado, setEventoSeleccionado] = useState('');
  const [fechaAsistencia, setFechaAsistencia] = useState(new Date().toISOString().split('T')[0]);

  const [registros, setRegistros] = useState([]);
  const [cargandoHoja, setCargandoHoja] = useState(false);
  const [guardando, setGuardando] = useState(false);
  const [mensaje, setMensaje] = useState('');
  const [error, setError] = useState('');

  const [modalHistorialAbierto, setModalHistorialAbierto] = useState(false);
  const [miembroHistorial, setMiembroHistorial] = useState(null);
  const [historialDatos, setHistorialDatos] = useState(null);
  const [cargandoHistorial, setCargandoHistorial] = useState(false);

  useEffect(() => {
    async function cargarEventos() {
      try {
        const res = await eventosService.listar();
        setEventos(res.eventos);
        if (res.eventos && res.eventos.length > 0) {
          setEventoSeleccionado(res.eventos[0].id);
          setFechaAsistencia(res.eventos[0].fecha);
        }
      } catch (err) {
        setError('Error al consultar lista de eventos y cultos.');
      }
    }
    cargarEventos();
  }, []);

  useEffect(() => {
    if (eventoSeleccionado && fechaAsistencia) {
      cargarHojaAsistencia();
    }
  }, [eventoSeleccionado, fechaAsistencia]);

  async function cargarHojaAsistencia() {
    setCargandoHoja(true);
    setError('');
    try {
      const resMiembros = await miembrosService.listar({ estado: 'activos', limite: 500 });
      const todosLosMiembros = resMiembros.miembros || [];

      const resAsistencia = await asistenciaService.obtenerPorEvento(eventoSeleccionado, fechaAsistencia);
      const asistenciasPrevias = resAsistencia.asistencias || [];

      const mapaPrevio = {};
      asistenciasPrevias.forEach((a) => {
        mapaPrevio[a.miembro_id] = a.estado;
      });

      const hojaConstruida = todosLosMiembros.map((m) => ({
        miembro_id: m.id,
        nombre: m.nombre,
        telefono: m.telefono,
        estado: mapaPrevio[m.id] || 'Ausente',
      }));

      setRegistros(hojaConstruida);
    } catch (err) {
      setError('Error al cargar la lista de asistencia.');
    } finally {
      setCargandoHoja(false);
    }
  }

  function cambiarEstado(miembro_id, nuevoEstado) {
    setRegistros((prev) =>
      prev.map((r) => (r.miembro_id === miembro_id ? { ...r, estado: nuevoEstado } : r))
    );
  }

  function marcarTodos(estado) {
    setRegistros((prev) => prev.map((r) => ({ ...r, estado })));
  }

  async function guardarAsistencia() {
    setGuardando(true);
    setError('');
    setMensaje('');

    try {
      const datosGuardar = {
        evento_id: Number(eventoSeleccionado),
        fecha: fechaAsistencia,
        registros: registros.map((r) => ({
          miembro_id: r.miembro_id,
          estado: r.estado,
        })),
      };

      const res = await asistenciaService.registrarMasivo(datosGuardar);
      setMensaje(res.mensaje || 'Asistencia guardada correctamente.');
    } catch (err) {
      setError(err.message || 'Error al guardar la asistencia.');
    } finally {
      setGuardando(false);
    }
  }

  async function verHistorialMiembro(miembro_id, nombre) {
    setMiembroHistorial({ id: miembro_id, nombre });
    setModalHistorialAbierto(true);
    setCargandoHistorial(true);
    try {
      const res = await asistenciaService.historialPorMiembro(miembro_id);
      setHistorialDatos(res);
    } catch {
      setError('Error al cargar el historial del miembro.');
    } finally {
      setCargandoHistorial(false);
    }
  }

  function imprimirLista() {
    window.print();
  }

  const presentesCount = registros.filter((r) => r.estado === 'Presente').length;
  const ausentesCount = registros.length - presentesCount;
  const porcentajeEnVivo = registros.length > 0 ? Math.round((presentesCount / registros.length) * 100) : 0;

  return (
    <div className="space-y-7 text-[#2b190a] font-serif">
      {/* Cabecera */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-3xl sm:text-4xl font-normal text-[#7a4e2a]">
            Control de Asistencia
          </h2>
          <p className="text-sm text-[#58351a] mt-1 font-medium">
            Registro de asistencia a cultos, reuniones y actividades de la congregación (RF-03)
          </p>
        </div>

        <div className="flex flex-wrap gap-2.5 self-start sm:self-auto">
          <button
            onClick={imprimirLista}
            className="px-4 py-3 bg-[#faf4ea] hover:bg-[#ebd8c3] text-[#7a4e2a] border-2 border-[#7a4e2a] rounded-xl text-sm font-bold shadow-xs transition-all"
          >
            Imprimir Reporte
          </button>

          {puedeGestionarEventos && (
            <button
              onClick={guardarAsistencia}
              disabled={guardando || cargandoHoja || registros.length === 0}
              className="px-5 py-3 bg-[#fef9c3] hover:bg-[#ebd8c3] text-[#7a4e2a] border-2 border-[#7a4e2a] rounded-xl text-sm font-bold shadow-xs transition-all disabled:opacity-50"
            >
              {guardando ? 'Guardando...' : 'Guardar Asistencia'}
            </button>
          )}
        </div>
      </div>

      {/* Alertas */}
      {mensaje && (
        <div className="p-4 bg-[#faf4ea] border-2 border-[#7a4e2a] rounded-xl text-[#7a4e2a] text-sm font-bold">
          {mensaje}
        </div>
      )}

      {error && (
        <div className="p-4 bg-[#fff2f0] border-2 border-[#7a4e2a] rounded-xl text-[#783636] text-sm">
          {error}
        </div>
      )}

      {/* Selector de Evento y Fecha */}
      <div className="bg-[#fffdf5] p-6 rounded-3xl border-2 border-[#7a4e2a] shadow-xs space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4.5">
          <div>
            <label className="block text-sm font-bold text-[#7a4e2a] mb-1.5">
              Evento o Culto Correspondiente
            </label>
            <select
              value={eventoSeleccionado}
              onChange={(e) => {
                const id = e.target.value;
                setEventoSeleccionado(id);
                const ev = eventos.find((x) => String(x.id) === String(id));
                if (ev) setFechaAsistencia(ev.fecha);
              }}
              className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base text-[#2b190a] focus:outline-none focus:bg-[#fef9c3]/30"
            >
              {eventos.map((ev) => (
                <option key={ev.id} value={ev.id}>
                  {ev.titulo} ({ev.fecha}) - {ev.tipo}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-bold text-[#7a4e2a] mb-1.5">
              Fecha de Asistencia
            </label>
            <input
              type="date"
              value={fechaAsistencia}
              onChange={(e) => setFechaAsistencia(e.target.value)}
              className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base text-[#2b190a] focus:outline-none focus:bg-[#fef9c3]/30"
            />
          </div>

          <div className="sm:col-span-2 lg:col-span-1 flex items-end">
            <div className="w-full p-3 bg-[#faf4ea] border-2 border-[#7a4e2a] rounded-2xl flex items-center justify-between text-sm">
              <span className="font-bold text-[#7a4e2a]">Balance:</span>
              <div className="flex items-center space-x-2.5 font-bold">
                <span className="text-[#7a4e2a]">{presentesCount} Presentes</span>
                <span className="text-[#7a4e2a]/50">/</span>
                <span className="text-[#58351a]">{ausentesCount} Ausentes</span>
                <span className="px-2.5 py-0.5 rounded-full bg-[#fef9c3] text-[#7a4e2a] border border-[#7a4e2a] text-xs">
                  {porcentajeEnVivo}%
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Acciones masivas */}
        {puedeGestionarEventos && (
          <div className="pt-3 border-t-2 border-[#7a4e2a]/30 flex flex-wrap gap-2.5 text-sm">
            <button
              onClick={() => marcarTodos('Presente')}
              className="px-4 py-2 bg-[#fef9c3] hover:bg-[#ebd8c3] text-[#7a4e2a] font-bold rounded-xl border-2 border-[#7a4e2a] transition-colors"
            >
              Marcar Todos Presentes
            </button>
            <button
              onClick={() => marcarTodos('Ausente')}
              className="px-4 py-2 bg-[#faf4ea] hover:bg-[#ebd8c3] text-[#7a4e2a] font-bold rounded-xl border-2 border-[#7a4e2a] transition-colors"
            >
              Marcar Todos Ausentes
            </button>
          </div>
        )}
      </div>

      {/* Hoja de Registro de Miembros */}
      <div className="bg-[#fffdf5] rounded-3xl border-2 border-[#7a4e2a] shadow-xs overflow-hidden">
        {cargandoHoja ? (
          <div className="p-12 text-center text-sm text-[#7a4e2a] flex flex-col items-center justify-center space-y-3">
            <div className="animate-spin rounded-full h-8 w-8 border-3 border-[#7a4e2a] border-t-[#fef9c3]"></div>
            <span>Cargando lista de miembros para pase de lista...</span>
          </div>
        ) : registros.length === 0 ? (
          <div className="p-12 text-center text-sm text-[#7a4e2a]">
            No hay miembros activos disponibles para registrar asistencia.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[#faf4ea] border-b-2 border-[#7a4e2a] text-xs font-bold text-[#7a4e2a] uppercase tracking-wider">
                  <th className="py-4 px-4 sm:px-6">Miembro</th>
                  <th className="py-4 px-4 text-center">Estado de Asistencia</th>
                  <th className="py-4 px-4 sm:px-6 text-right">Historial</th>
                </tr>
              </thead>
              <tbody className="divide-y border-t border-[#7a4e2a]/30 text-sm">
                {registros.map((reg) => {
                  const esPresente = reg.estado === 'Presente';
                  return (
                    <tr
                      key={reg.miembro_id}
                      className={`transition-colors ${
                        esPresente ? 'bg-[#faf4ea]/70' : 'hover:bg-[#faf4ea]/40'
                      }`}
                    >
                      <td className="py-3.5 px-4 sm:px-6">
                        <div className="flex items-center space-x-3.5">
                          <div
                            className={`w-9 h-9 rounded-full font-bold flex items-center justify-center text-sm shrink-0 border-2 border-[#7a4e2a] ${
                              esPresente
                                ? 'bg-[#fef9c3] text-[#7a4e2a]'
                                : 'bg-[#fffdf5] text-[#7a4e2a]'
                            }`}
                          >
                            {reg.nombre.substring(0, 2).toUpperCase()}
                          </div>
                          <div>
                            <p className="font-bold text-base text-[#7a4e2a]">{reg.nombre}</p>
                            {reg.telefono && <p className="text-xs text-[#58351a]">Tel: {reg.telefono}</p>}
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="flex items-center justify-center space-x-2.5">
                          <button
                            type="button"
                            onClick={() => cambiarEstado(reg.miembro_id, 'Presente')}
                            disabled={!puedeGestionarEventos}
                            className={`px-4 py-1.5 rounded-xl font-bold text-sm transition-all border-2 border-[#7a4e2a] ${
                              esPresente
                                ? 'bg-[#7a4e2a] text-[#fffdf5] shadow-xs'
                                : 'bg-[#fffdf5] text-[#7a4e2a] hover:bg-[#fef9c3]'
                            }`}
                          >
                            Presente
                          </button>

                          <button
                            type="button"
                            onClick={() => cambiarEstado(reg.miembro_id, 'Ausente')}
                            disabled={!puedeGestionarEventos}
                            className={`px-4 py-1.5 rounded-xl font-bold text-sm transition-all border-2 border-[#7a4e2a] ${
                              !esPresente
                                ? 'bg-[#58351a] text-[#fffdf5] shadow-xs'
                                : 'bg-[#fffdf5] text-[#7a4e2a] hover:bg-[#faf4ea]'
                            }`}
                          >
                            Ausente
                          </button>
                        </div>
                      </td>

                      <td className="py-3.5 px-4 sm:px-6 text-right">
                        <button
                          type="button"
                          onClick={() => verHistorialMiembro(reg.miembro_id, reg.nombre)}
                          className="text-sm text-[#7a4e2a] hover:text-[#2b190a] font-bold underline"
                        >
                          Ver historial
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modal Historial */}
      <Modal
        isOpen={modalHistorialAbierto}
        onClose={() => setModalHistorialAbierto(false)}
        titulo={`Historial de Asistencia: ${miembroHistorial?.nombre || ''}`}
      >
        {cargandoHistorial ? (
          <div className="p-8 text-center text-sm text-[#7a4e2a]">
            Consultando historial de asistencia...
          </div>
        ) : (
          <div className="space-y-4 text-[#2b190a]">
            {historialDatos?.estadisticas && (
              <div className="grid grid-cols-3 gap-3 p-4 bg-[#faf4ea] rounded-2xl border-2 border-[#7a4e2a] text-center text-sm">
                <div>
                  <p className="text-[#7a4e2a] font-semibold">Presentes</p>
                  <p className="text-2xl font-bold text-[#7a4e2a]">
                    {historialDatos.estadisticas.totalPresentes}
                  </p>
                </div>
                <div>
                  <p className="text-[#7a4e2a] font-semibold">Ausencias</p>
                  <p className="text-2xl font-bold text-[#58351a]">
                    {historialDatos.estadisticas.totalAusentes}
                  </p>
                </div>
                <div>
                  <p className="text-[#7a4e2a] font-semibold">Porcentaje</p>
                  <p className="text-2xl font-bold text-[#7a4e2a]">
                    {historialDatos.estadisticas.porcentajeAsistencia}%
                  </p>
                </div>
              </div>
            )}

            <div className="max-h-72 overflow-y-auto divide-y border-t border-[#7a4e2a]/30 text-sm">
              {historialDatos?.historial && historialDatos.historial.length > 0 ? (
                historialDatos.historial.map((h) => (
                  <div key={h.id} className="py-3 flex items-center justify-between">
                    <div>
                      <p className="font-bold text-[#7a4e2a]">{h.evento_titulo}</p>
                      <p className="text-xs text-[#58351a]">
                        {h.fecha} • {h.evento_tipo}
                      </p>
                    </div>
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-bold border-2 ${
                        h.estado === 'Presente'
                          ? 'bg-[#fef9c3] text-[#7a4e2a] border-[#7a4e2a]'
                          : 'bg-[#faf4ea] text-[#7a4e2a]/70 border-[#7a4e2a]/40'
                      }`}
                    >
                      {h.estado}
                    </span>
                  </div>
                ))
              ) : (
                <p className="text-center py-6 text-[#7a4e2a]">Sin registros de asistencia previos.</p>
              )}
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
