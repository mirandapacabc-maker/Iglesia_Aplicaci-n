/**
 * Rutas de la API para anuncios y comunicados institucionales (RF-07).
 */
const { Router } = require('express');
const {
  listarAnuncios,
  crearAnuncio,
  actualizarAnuncio,
  eliminarAnuncio
} = require('../controllers/anunciosController');
const { autenticarToken, autorizarRoles } = require('../middleware/authMiddleware');

const router = Router();

router.use(autenticarToken);

router.get('/', listarAnuncios);

// Creación, edición y eliminación de anuncios (Admin, Pastor, Secretario, Coordinador)
router.post('/', autorizarRoles('Administrador', 'Pastor', 'Secretario', 'Coordinador'), crearAnuncio);
router.put('/:id', autorizarRoles('Administrador', 'Pastor', 'Secretario', 'Coordinador'), actualizarAnuncio);
router.delete('/:id', autorizarRoles('Administrador', 'Pastor', 'Secretario', 'Coordinador'), eliminarAnuncio);

module.exports = router;
