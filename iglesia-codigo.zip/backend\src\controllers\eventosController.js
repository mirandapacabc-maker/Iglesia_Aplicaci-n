/**
 * Controlador de Gestión de Eventos y Cultos (RF-04).
 * Maneja altas, modificaciones, cancelaciones y consultas para vista de calendario interactiva.
 */
const db = require('../config/database');

/**
 * Listado de eventos con soporte de filtros por mes/año para el calendario y por estado.
 */
function listarEventos(req, res, next) {
  try {
    const { mes, anio, estado } = req.query;

    let condiciones = [];
    let parametros = [];

    // Filtro por fecha de calendario (ej. 2026-10)
    if (anio && mes) {
      const mesPadded = String(mes).padStart(2, '0');
      condiciones.push("strftime('%Y-%m', fecha) = ?");
      parametros.push(`${anio}-${mesPadded}`);
    } else if (anio) {
      condiciones.push("strftime('%Y', fecha) = ?");
      parametros.push(String(anio));
    }

    if (estado) {
      condiciones.push('e.estado = ?');
      parametros.push(estado);
    }

    const whereClause = condiciones.length > 0 ? `WHERE ${condiciones.join(' AND ')}` : '';

    const query = `
      SELECT 
        e.id, e.titulo, e.tipo, e.fecha, e.hora, e.lugar, e.descripcion, e.estado, e.creado_en,
        e.responsable_id,
        m.nombre AS responsable_nombre,
        (SELECT COUNT(*) FROM asistencias a WHERE a.evento_id = e.id AND a.estado = 'Presente') AS total_asistentes
      FROM eventos e
      LEFT JOIN miembros m ON e.responsable_id = m.id
      ${whereClause}
      ORDER BY e.fecha ASC, e.hora ASC
    `;

    const eventos = db.prepare(query).all(...parametros);

    return res.json({ eventos });
  } catch (error) {
    next(error);
  }
}

/**
 * Obtener detalle de un evento por ID.
 */
function obtenerEventoPorId(req, res, next) {
  try {
    const { id } = req.params;
    const evento = db.prepare(`
      SELECT 
        e.id, e.titulo, e.tipo, e.fecha, e.hora, e.lugar, e.descripcion, e.estado, e.creado_en,
        e.responsable_id,
        m.nombre AS responsable_nombre,
        m.telefono AS responsable_telefono
      FROM eventos e
      LEFT JOIN miembros m ON e.responsable_id = m.id
      WHERE e.id = ?
    `).get(id);

    if (!evento) {
      return res.status(404).json({ mensaje: 'Evento no encontrado.' });
    }

    return res.json({ evento });
  } catch (error) {
    next(error);
  }
}

/**
 * Creación de un nuevo evento.
 */
function crearEvento(req, res, next) {
  try {
    const { titulo, tipo, fecha, hora, lugar, descripcion, responsable_id } = req.body;

    if (!titulo || !fecha || !hora || !lugar) {
      return res.status(400).json({ mensaje: 'Título, fecha, hora y lugar son campos obligatorios.' });
    }

    const resultado = db.prepare(`
      INSERT INTO eventos (titulo, tipo, fecha, hora, lugar, descripcion, responsable_id, estado)
      VALUES (?, ?, ?, ?, ?, ?, ?, 'Programado')
    `).run(
      titulo.trim(),
      tipo || 'Culto',
      fecha,
      hora,
      lugar.trim(),
      descripcion ? descripcion.trim() : null,
      responsable_id || null
    );

    const nuevoEvento = db.prepare(`
      SELECT e.*, m.nombre AS responsable_nombre
      FROM eventos e
      LEFT JOIN miembros m ON e.responsable_id = m.id
      WHERE e.id = ?
    `).get(resultado.lastInsertRowid);

    return res.status(201).json({
      mensaje: 'Evento programado exitosamente.',
      evento: nuevoEvento
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Modificación de un evento existente.
 */
function actualizarEvento(req, res, next) {
  try {
    const { id } = req.params;
    const { titulo, tipo, fecha, hora, lugar, descripcion, responsable_id, estado } = req.body;

    const eventoExistente = db.prepare('SELECT id FROM eventos WHERE id = ?').get(id);
    if (!eventoExistente) {
      return res.status(404).json({ mensaje: 'El evento no existe.' });
    }

    db.prepare(`
      UPDATE eventos
      SET titulo = ?, tipo = ?, fecha = ?, hora = ?, lugar = ?, descripcion = ?, responsable_id = ?, estado = ?
      WHERE id = ?
    `).run(
      titulo.trim(),
      tipo || 'Culto',
      fecha,
      hora,
      lugar.trim(),
      descripcion ? descripcion.trim() : null,
      responsable_id || null,
      estado || 'Programado',
      id
    );

    const eventoActualizado = db.prepare(`
      SELECT e.*, m.nombre AS responsable_nombre
      FROM eventos e
      LEFT JOIN miembros m ON e.responsable_id = m.id
      WHERE e.id = ?
    `).get(id);

    return res.json({
      mensaje: 'Evento actualizado correctamente.',
      evento: eventoActualizado
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Cancelación o cambio rápido de estado de un evento.
 */
function cancelarEvento(req, res, next) {
  try {
    const { id } = req.params;
    const { motivo } = req.body;

    const evento = db.prepare('SELECT id, titulo FROM eventos WHERE id = ?').get(id);
    if (!evento) {
      return res.status(404).json({ mensaje: 'Evento no encontrado.' });
    }

    const descMotivo = motivo ? ` [CANCELADO: ${motivo}]` : ' [CANCELADO]';
    db.prepare(`
      UPDATE eventos 
      SET estado = 'Cancelado', descripcion = COALESCE(descripcion, '') || ?
      WHERE id = ?
    `).run(descMotivo, id);

    return res.json({ mensaje: 'El evento ha sido cancelado.' });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  listarEventos,
  obtenerEventoPorId,
  crearEvento,
  actualizarEvento,
  cancelarEvento
};
