/**
 * Servicio de Envío de Correos mediante la API / SMTP de Google Gmail (RF-01).
 * Permite el envío de correos institucionales para restablecimiento de contraseña
 * y notificaciones del sistema de la iglesia.
 */
const nodemailer = require('nodemailer');

function crearTransporter() {
  const user = process.env.GMAIL_USER;
  const pass = process.env.GMAIL_APP_PASSWORD || process.env.GMAIL_PASS;

  if (!user || !pass) {
    return null;
  }

  return nodemailer.createTransport({
    service: 'gmail',
    host: 'smtp.gmail.com',
    port: 465,
    secure: true,
    auth: {
      user: user,
      pass: pass
    }
  });
}

/**
 * Envía el código de verificación/recuperación de contraseña por Google Gmail.
 * @param {string} destinatario Correo electrónico del usuario
 * @param {string} codigo Código numérico de 6 dígitos
 * @param {string} nombre Nombre del usuario
 */
async function enviarCodigoRecuperacion(destinatario, codigo, nombre = 'Hermano(a)') {
  const transporter = crearTransporter();

  const asunto = 'Restablecimiento de Contraseña - Sistema de la Iglesia';
  const html = `
    <!DOCTYPE html>
    <html lang="es">
    <head>
      <meta charset="utf-8">
      <style>
        body { font-family: 'Georgia', serif; background-color: #fffdf5; color: #58351a; margin: 0; padding: 24px; }
        .contenedor { max-width: 580px; margin: 0 auto; background-color: #ffffff; border: 2px solid #7a4e2a; border-radius: 8px; padding: 32px; box-shadow: 0 4px 12px rgba(122, 78, 42, 0.08); }
        .encabezado { text-align: center; border-bottom: 1px solid #ebd8c3; padding-bottom: 20px; margin-bottom: 24px; }
        .titulo { font-size: 24px; color: #7a4e2a; margin: 0 0 8px 0; font-weight: normal; }
        .subtitulo { font-size: 14px; color: #8c6a4e; margin: 0; }
        .cuerpo { font-size: 16px; line-height: 1.6; color: #422a16; }
        .caja-codigo { background-color: #fffdf5; border: 2px dashed #7a4e2a; border-radius: 6px; padding: 18px; text-align: center; margin: 28px 0; }
        .codigo { font-size: 32px; font-weight: bold; letter-spacing: 6px; color: #7a4e2a; font-family: monospace; }
        .aviso { font-size: 13px; color: #8c6a4e; margin-top: 10px; }
        .pie { text-align: center; font-size: 12px; color: #a1836a; border-top: 1px solid #f5ede1; margin-top: 28px; padding-top: 16px; }
      </style>
    </head>
    <body>
      <div class="contenedor">
        <div class="encabezado">
          <h1 class="titulo">Comunidad de Fe y Servicio</h1>
          <p class="subtitulo">Sistema Integral de Gestión Eclesiástica</p>
        </div>
        <div class="cuerpo">
          <p>Estimado(a) <strong>${nombre}</strong>,</p>
          <p>Hemos recibido una solicitud para restablecer la contraseña de acceso a tu cuenta en el sistema de la iglesia.</p>
          <p>Para continuar con el proceso, introduce el siguiente código de seguridad en la aplicación:</p>
          
          <div class="caja-codigo">
            <div class="codigo">${codigo}</div>
            <div class="aviso">Este código tiene una vigencia de 1 hora.</div>
          </div>

          <p>Si tú no has solicitado este cambio, puedes ignorar este mensaje; tu contraseña permanecerá segura.</p>
        </div>
        <div class="pie">
          <p>Paz y bendiciones en tu labor.</p>
          <p>Este es un correo institucional automático del sistema de la iglesia.</p>
        </div>
      </div>
    </body>
    </html>
  `;

  if (!transporter) {
    console.warn(`[Gmail API / SMTP] Variables GMAIL_USER o GMAIL_APP_PASSWORD no configuradas en backend/.env.`);
    console.log(`[Gmail Simulado] Para: ${destinatario} | Código de recuperación: ${codigo}`);
    return {
      enviado: false,
      simulado: true,
      mensaje: 'Servicio Gmail pendiente de credenciales en .env; código generado localmente.'
    };
  }

  try {
    const info = await transporter.sendMail({
      from: `"Sistema Eclesiástico" <${process.env.GMAIL_USER}>`,
      to: destinatario,
      subject: asunto,
      html: html,
      text: `Estimado(a) ${nombre},\n\nTu código de recuperación es: ${codigo}\nVigencia: 1 hora.\n\nSi no realizaste esta solicitud, ignora este mensaje.`
    });

    console.log(`[Gmail API] Correo enviado exitosamente a ${destinatario} (ID: ${info.messageId})`);
    return {
      enviado: true,
      simulado: false,
      messageId: info.messageId
    };
  } catch (error) {
    console.error(`[Gmail API Error] Error al enviar correo a ${destinatario}:`, error.message);
    return {
      enviado: false,
      simulado: true,
      error: error.message,
      mensaje: 'Fallo el envío por Gmail, código conservado para el usuario.'
    };
  }
}

module.exports = {
  enviarCodigoRecuperacion
};
