/**
 * Controlador del Panel Principal (Dashboard) (RF-08).
 * Consolida métricas generales, próximos eventos, asistencias recientes, comunicados prioritarios
 * y datos financieros protegidos según el rol del usuario autenticado.
 */
const db = require('../config/database');

const ROLES_FINANCIEROS = ['Administrador', 'Pastor', 'Tesorero'];

/**
 * Obtener estadísticas consolidadas y métricas visuales para el panel principal.
 */
function obtenerMetricasDashboard(req, res, next) {
  try {
    const rolUsuario = req.usuario.rol;
    const puedeVerFinanzas = ROLES_FINANCIEROS.includes(rolUsuario);

    // 1. Métricas básicas principales
    const totalMiembrosActivos = db.prepare('SELECT COUNT(*) AS total FROM miembros WHERE activo = 1').get().total;
    const totalMiembrosInactivos = db.prepare('SELECT COUNT(*) AS total FROM miembros WHERE activo = 0').get().total;
    const totalMinisteriosActivos = db.prepare('SELECT COUNT(*) AS total FROM ministerios WHERE activo = 1').get().total;

    // 2. Próximos eventos (a partir de la fecha de hoy)
    const eventosProximos = db.prepare(`
      SELECT 
        e.id, e.titulo, e.tipo, e.fecha, e.hora, e.lugar, e.estado,
        m.nombre AS responsable_nombre
      FROM eventos e
      LEFT JOIN miembros m ON e.responsable_id = m.id
      WHERE e.fecha >= date('now', 'localtime') AND e.estado != 'Cancelado'
      ORDER BY e.fecha ASC, e.hora ASC
      LIMIT 5
    `).all();

    // 3. Resumen de asistencias recientes (últimos 5 eventos pasados)
    const asistenciasRecientes = db.prepare(`
      SELECT 
        e.id AS evento_id,
        e.titulo,
        e.tipo,
        a.fecha,
        SUM(CASE WHEN a.estado = 'Presente' THEN 1 ELSE 0 END) AS presentes,
        SUM(CASE WHEN a.estado = 'Ausente' THEN 1 ELSE 0 END) AS ausentes,
        COUNT(a.id) AS total_registros
      FROM asistencias a
      JOIN eventos e ON a.evento_id = e.id
      GROUP BY a.evento_id, a.fecha
      ORDER BY a.fecha DESC
      LIMIT 6
    `).all();

    // Promedio de asistencia reciente
    const totalAsistenciasUltimoMes = db.prepare(`
      SELECT COUNT(*) AS total 
      FROM asistencias 
      WHERE estado = 'Presente' AND fecha >= date('now', '-30 days')
    `).get().total;

    // 4. Anuncios prioritarios / destacados
    const anunciosDestacados = db.prepare(`
      SELECT id, titulo, contenido, categoria, fecha_publicacion
      FROM anuncios
      WHERE destacado = 1
      ORDER BY fecha_publicacion DESC
      LIMIT 3
    `).all();

    // 5. Datos financieros protegidos (RF-06 / RF-08)
    let finanzas = null;
    if (puedeVerFinanzas) {
      const hoy = new Date();
      const anioActual = hoy.getFullYear();
      const mesActual = String(hoy.getMonth() + 1).padStart(2, '0');

      // Total acumulado del mes en curso
      const ingresosMes = db.prepare(`
        SELECT COALESCE(SUM(monto), 0) AS total_mes, COUNT(id) AS total_transacciones
        FROM donaciones
        WHERE strftime('%Y-%m', fecha) = ?
      `).get(`${anioActual}-${mesActual}`);

      // Histórico de ingresos mensuales de los últimos 6 meses para gráfica
      const tendenciaIngresos = db.prepare(`
        SELECT 
          strftime('%Y-%m', fecha) AS periodo,
          COALESCE(SUM(monto), 0) AS monto
        FROM donaciones
        WHERE fecha >= date('now', '-6 months')
        GROUP BY strftime('%Y-%m', fecha)
        ORDER BY periodo ASC
      `).all();

      // Desglose por concepto del mes
      const porConcepto = db.prepare(`
        SELECT concepto, SUM(monto) AS total
        FROM donaciones
        WHERE strftime('%Y-%m', fecha) = ?
        GROUP BY concepto
      `).all(`${anioActual}-${mesActual}`);

      finanzas = {
        totalMes: ingresosMes.total_mes,
        totalTransacciones: ingresosMes.total_transacciones,
        tendenciaIngresos,
        porConcepto
      };
    }

    return res.json({
      metricas: {
        totalMiembrosActivos,
        totalMiembrosInactivos,
        totalMinisteriosActivos,
        totalAsistenciasUltimoMes,
        totalEventosProximos: eventosProximos.length
      },
      eventosProximos,
      asistenciasRecientes,
      anunciosDestacados,
      finanzas, // Será null para roles sin permisos financieros
      puedeVerFinanzas
    });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  obtenerMetricasDashboard
};
