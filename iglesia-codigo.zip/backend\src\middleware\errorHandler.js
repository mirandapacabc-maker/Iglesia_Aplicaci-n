/**
 * Middleware centralizado para captura y respuesta uniforme de errores en la API REST.
 */
function manejadorErrores(err, req, res, next) {
  console.error('[Error del Servidor]:', err.message || err);

  const statusCode = res.statusCode === 200 ? 500 : res.statusCode;
  res.status(statusCode).json({
    mensaje: err.message || 'Ocurrió un error inesperado en el servidor.',
    detalles: process.env.NODE_ENV === 'development' ? err.stack : undefined
  });
}

module.exports = { manejadorErrores };
