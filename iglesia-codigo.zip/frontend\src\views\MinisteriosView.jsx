/**
 * Vista de Administración de Ministerios y Grupos de Trabajo (RF-05).
 * Predominante: #fffdf5, Contorno: #7a4e2a, Blanco, Beige (#faf4ea, #f5ede1) y Amarillo Pálido #fef9c3.
 * Tipografía: Day Roman Regular (sin iconos, letras más grandes y legibles).
 */
import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { ministeriosService, miembrosService } from '../services/api';
import Modal from '../components/Modal';

export default function MinisteriosView() {
  const { puedeGestionarEventos } = useAuth();

  const [ministerios, setMinisterios] = useState([]);
  const [ministerioSeleccionado, setMinisterioSeleccionado] = useState(null);
  const [detalleMinisterio, setDetalleMinisterio] = useState(null);
  const [todosLosMiembros, setTodosLosMiembros] = useState([]);

  const [cargando, setCargando] = useState(false);
  const [cargandoDetalle, setCargandoDetalle] = useState(false);
  const [mensaje, setMensaje] = useState('');
  const [error, setError] = useState('');

  const [modalMinisterioAbierto, setModalMinisterioAbierto] = useState(false);
  const [ministerioEnEdicion, setMinisterioEnEdicion] = useState(null);
  const [formMinisterio, setFormMinisterio] = useState({ nombre: '', descripcion: '', coordinador_id: '' });

  const [modalVincularAbierto, setModalVincularAbierto] = useState(false);
  const [formVinculo, setFormVinculo] = useState({ miembro_id: '', rol_ministerio: 'Miembro' });

  const [modalActividadAbierto, setModalActividadAbierto] = useState(false);
  const [formActividad, setFormActividad] = useState({
    titulo: '',
    descripcion: '',
    fecha: new Date().toISOString().split('T')[0],
    hora: '18:00',
    lugar: 'Salón de Usos Múltiples',
  });

  const [guardando, setGuardando] = useState(false);

  useEffect(() => {
    cargarMinisterios();
    cargarMiembros();
  }, []);

  useEffect(() => {
    if (ministerioSeleccionado) {
      cargarDetalleMinisterio(ministerioSeleccionado.id);
    }
  }, [ministerioSeleccionado]);

  async function cargarMinisterios() {
    setCargando(true);
    setError('');
    try {
      const res = await ministeriosService.listar();
      setMinisterios(res.ministerios);
      if (res.ministerios.length > 0 && !ministerioSeleccionado) {
        setMinisterioSeleccionado(res.ministerios[0]);
      }
    } catch (err) {
      setError(err.message || 'Error al cargar los ministerios.');
    } finally {
      setCargando(false);
    }
  }

  async function cargarMiembros() {
    try {
      const res = await miembrosService.listar({ estado: 'activos', limite: 500 });
      setTodosLosMiembros(res.miembros);
    } catch (err) {
      console.error(err);
    }
  }

  async function cargarDetalleMinisterio(id) {
    setCargandoDetalle(true);
    try {
      const res = await ministeriosService.obtenerDetalle(id);
      setDetalleMinisterio(res);
    } catch (err) {
      setError('Error al consultar detalles del ministerio.');
    } finally {
      setCargandoDetalle(false);
    }
  }

  function abrirModalNuevoMinisterio() {
    setMinisterioEnEdicion(null);
    setFormMinisterio({ nombre: '', descripcion: '', coordinador_id: '' });
    setModalMinisterioAbierto(true);
  }

  function abrirModalEditarMinisterio(min) {
    setMinisterioEnEdicion(min);
    setFormMinisterio({
      nombre: min.nombre,
      descripcion: min.descripcion || '',
      coordinador_id: min.coordinador_id || '',
    });
    setModalMinisterioAbierto(true);
  }

  async function handleGuardarMinisterio(e) {
    e.preventDefault();
    setGuardando(true);
    setError('');
    setMensaje('');

    try {
      if (ministerioEnEdicion) {
        await ministeriosService.actualizar(ministerioEnEdicion.id, formMinisterio);
        setMensaje('Ministerio actualizado correctamente.');
      } else {
        await ministeriosService.crear(formMinisterio);
        setMensaje('Nuevo ministerio registrado con éxito.');
      }
      setModalMinisterioAbierto(false);
      cargarMinisterios();
      if (ministerioSeleccionado) {
        cargarDetalleMinisterio(ministerioSeleccionado.id);
      }
    } catch (err) {
      setError(err.message || 'Error al guardar el ministerio.');
    } finally {
      setGuardando(false);
    }
  }

  async function handleVincularMiembro(e) {
    e.preventDefault();
    if (!formVinculo.miembro_id) {
      setError('Seleccione un miembro para vincular al ministerio.');
      return;
    }
    setGuardando(true);
    setError('');
    setMensaje('');

    try {
      await ministeriosService.vincularMiembro(ministerioSeleccionado.id, formVinculo);
      setMensaje('Miembro vinculado exitosamente al ministerio.');
      setModalVincularAbierto(false);
      cargarDetalleMinisterio(ministerioSeleccionado.id);
      cargarMinisterios();
    } catch (err) {
      setError(err.message || 'Error al vincular al miembro.');
    } finally {
      setGuardando(false);
    }
  }

  async function handleDesvincularMiembro(miembro_id, nombre) {
    if (!window.confirm(`¿Desea desvincular a ${nombre} de este ministerio?`)) return;

    try {
      await ministeriosService.desvincularMiembro(ministerioSeleccionado.id, miembro_id);
      setMensaje(`${nombre} fue desvinculado del ministerio.`);
      cargarDetalleMinisterio(ministerioSeleccionado.id);
      cargarMinisterios();
    } catch (err) {
      setError(err.message || 'Error al desvincular al miembro.');
    }
  }

  async function handleGuardarActividad(e) {
    e.preventDefault();
    setGuardando(true);
    setError('');
    setMensaje('');

    try {
      await ministeriosService.crearActividad(ministerioSeleccionado.id, formActividad);
      setMensaje('Actividad programada registrada con éxito.');
      setModalActividadAbierto(false);
      cargarDetalleMinisterio(ministerioSeleccionado.id);
    } catch (err) {
      setError(err.message || 'Error al registrar la actividad.');
    } finally {
      setGuardando(false);
    }
  }

  return (
    <div className="space-y-7 text-[#2b190a] font-serif">
      {/* Cabecera */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-3xl sm:text-4xl font-normal text-[#7a4e2a]">
            Administración de Ministerios
          </h2>
          <p className="text-sm text-[#58351a] mt-1 font-medium">
            Grupos de trabajo, asignación de coordinadores, integrantes y actividades (RF-05)
          </p>
        </div>

        {puedeGestionarEventos && (
          <button
            onClick={abrirModalNuevoMinisterio}
            className="px-5 py-3 bg-[#fef9c3] hover:bg-[#ebd8c3] text-[#7a4e2a] border-2 border-[#7a4e2a] rounded-xl text-sm font-bold shadow-xs transition-all self-start sm:self-auto"
          >
            Registrar Ministerio
          </button>
        )}
      </div>

      {/* Alertas */}
      {mensaje && (
        <div className="p-4 bg-[#faf4ea] border-2 border-[#7a4e2a] rounded-xl text-[#7a4e2a] text-sm font-bold">
          {mensaje}
        </div>
      )}

      {error && (
        <div className="p-4 bg-[#fff2f0] border-2 border-[#7a4e2a] rounded-xl text-[#783636] text-sm">
          {error}
        </div>
      )}

      {/* Distribución de Ministerios */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Columna Izquierda: Listado de Ministerios */}
        <div className="space-y-3.5">
          <h3 className="text-xs font-bold text-[#7a4e2a] uppercase tracking-wider px-1">
            Ministerios Registrados ({ministerios.length})
          </h3>

          <div className="space-y-2.5">
            {ministerios.map((min) => {
              const esSeleccionado = ministerioSeleccionado?.id === min.id;
              return (
                <div
                  key={min.id}
                  onClick={() => setMinisterioSeleccionado(min)}
                  className={`p-5 rounded-2xl border-2 transition-all cursor-pointer flex items-center justify-between ${
                    esSeleccionado
                      ? 'bg-[#fef9c3] border-[#7a4e2a] shadow-xs'
                      : 'bg-[#fffdf5] border-[#7a4e2a]/40 hover:border-[#7a4e2a]'
                  }`}
                >
                  <div className="space-y-1">
                    <h4 className="text-base font-bold text-[#7a4e2a]">{min.nombre}</h4>
                    <p className="text-xs text-[#58351a]">
                      Coordinador: <span className="font-semibold">{min.coordinador_nombre || 'Sin asignar'}</span>
                    </p>
                    <p className="text-xs text-[#7a4e2a] pt-0.5 font-bold">
                      {min.total_integrantes} integrantes activos
                    </p>
                  </div>
                  {esSeleccionado && (
                    <span className="text-sm font-bold text-[#7a4e2a]">●</span>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Columna Derecha: Detalle del Ministerio */}
        <div className="lg:col-span-2 space-y-6">
          {cargandoDetalle ? (
            <div className="bg-[#fffdf5] p-12 rounded-3xl border-2 border-[#7a4e2a] text-center text-sm text-[#7a4e2a] flex flex-col items-center justify-center space-y-3">
              <div className="animate-spin rounded-full h-8 w-8 border-3 border-[#7a4e2a] border-t-[#fef9c3]"></div>
              <span>Consultando información ministerial...</span>
            </div>
          ) : detalleMinisterio ? (
            <div className="space-y-6">
              {/* Tarjeta de Información General */}
              <div className="bg-[#fffdf5] p-7 rounded-3xl border-2 border-[#7a4e2a] shadow-xs space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                  <div>
                    <span className="text-xs font-bold px-3 py-1 rounded-full bg-[#fef9c3] text-[#7a4e2a] border border-[#7a4e2a]">
                      Área de Servicio
                    </span>
                    <h3 className="text-2xl font-bold text-[#7a4e2a] mt-2">
                      {detalleMinisterio.ministerio.nombre}
                    </h3>
                    <p className="text-sm text-[#58351a] mt-1">
                      {detalleMinisterio.ministerio.descripcion || 'Sin descripción detallada.'}
                    </p>
                  </div>

                  {puedeGestionarEventos && (
                    <button
                      onClick={() => abrirModalEditarMinisterio(detalleMinisterio.ministerio)}
                      className="px-4 py-2 border-2 border-[#7a4e2a] bg-[#faf4ea] hover:bg-[#fffdf5] text-[#7a4e2a] rounded-xl text-sm font-bold transition-colors self-start"
                    >
                      Editar Ministerio
                    </button>
                  )}
                </div>

                <div className="p-4 bg-[#faf4ea] border-2 border-[#7a4e2a] rounded-2xl flex items-center justify-between text-sm">
                  <div>
                    <span className="text-xs text-[#58351a] font-medium">Coordinador(a) Asignado(a):</span>
                    <p className="font-bold text-base text-[#7a4e2a]">
                      {detalleMinisterio.ministerio.coordinador_nombre || 'No asignado'}
                    </p>
                  </div>
                  {detalleMinisterio.ministerio.coordinador_telefono && (
                    <span className="text-xs text-[#58351a]">
                      Tel: {detalleMinisterio.ministerio.coordinador_telefono}
                    </span>
                  )}
                </div>
              </div>

              {/* Integrantes del Ministerio */}
              <div className="bg-[#fffdf5] p-7 rounded-3xl border-2 border-[#7a4e2a] shadow-xs space-y-4">
                <div className="flex items-center justify-between pb-3 border-b-2 border-[#7a4e2a]/30">
                  <h4 className="text-lg font-bold text-[#7a4e2a]">
                    Miembros Vinculados ({detalleMinisterio.miembros.length})
                  </h4>

                  {puedeGestionarEventos && (
                    <button
                      onClick={() => {
                        setFormVinculo({ miembro_id: '', rol_ministerio: 'Miembro' });
                        setModalVincularAbierto(true);
                      }}
                      className="px-4 py-2 bg-[#fef9c3] hover:bg-[#ebd8c3] text-[#7a4e2a] border-2 border-[#7a4e2a] rounded-xl text-sm font-bold transition-colors"
                    >
                      Vincular Miembro
                    </button>
                  )}
                </div>

                <div className="divide-y border-t border-[#7a4e2a]/30 text-sm">
                  {detalleMinisterio.miembros.length > 0 ? (
                    detalleMinisterio.miembros.map((mb) => (
                      <div key={mb.vinculo_id} className="py-3.5 flex items-center justify-between">
                        <div className="flex items-center space-x-3.5">
                          <div className="w-9 h-9 rounded-full bg-[#fef9c3] text-[#7a4e2a] border-2 border-[#7a4e2a] font-bold flex items-center justify-center text-sm">
                            {mb.nombre.substring(0, 2).toUpperCase()}
                          </div>
                          <div>
                            <p className="font-bold text-base text-[#7a4e2a]">{mb.nombre}</p>
                            <p className="text-xs text-[#58351a]">
                              Función: <span className="font-semibold text-[#7a4e2a]">{mb.rol_ministerio}</span> • Ingreso: {mb.fecha_ingreso}
                            </p>
                          </div>
                        </div>

                        {puedeGestionarEventos && (
                          <button
                            onClick={() => handleDesvincularMiembro(mb.miembro_id, mb.nombre)}
                            className="text-[#7a4e2a] hover:text-[#783636] text-sm underline font-medium"
                          >
                            Desvincular
                          </button>
                        )}
                      </div>
                    ))
                  ) : (
                    <p className="text-center py-6 text-[#7a4e2a] text-sm">
                      Este ministerio aún no tiene miembros vinculados.
                    </p>
                  )}
                </div>
              </div>

              {/* Actividades del Ministerio */}
              <div className="bg-[#fffdf5] p-7 rounded-3xl border-2 border-[#7a4e2a] shadow-xs space-y-4">
                <div className="flex items-center justify-between pb-3 border-b-2 border-[#7a4e2a]/30">
                  <h4 className="text-lg font-bold text-[#7a4e2a]">
                    Actividades Programadas ({detalleMinisterio.actividades.length})
                  </h4>

                  {puedeGestionarEventos && (
                    <button
                      onClick={() => setModalActividadAbierto(true)}
                      className="px-4 py-2 bg-[#faf4ea] hover:bg-[#fffdf5] text-[#7a4e2a] border-2 border-[#7a4e2a] rounded-xl text-sm font-bold transition-colors"
                    >
                      Programar Actividad
                    </button>
                  )}
                </div>

                <div className="space-y-3">
                  {detalleMinisterio.actividades.length > 0 ? (
                    detalleMinisterio.actividades.map((act) => (
                      <div key={act.id} className="p-4 bg-[#faf4ea] rounded-2xl border-2 border-[#7a4e2a] space-y-1">
                        <p className="text-sm font-bold text-[#7a4e2a]">{act.titulo}</p>
                        {act.descripcion && <p className="text-xs text-[#58351a]">{act.descripcion}</p>}
                        <div className="flex items-center space-x-4 text-xs text-[#58351a] pt-1">
                          <span>{act.fecha} • {act.hora} hrs</span>
                          {act.lugar && <span>Lugar: {act.lugar}</span>}
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-center py-6 text-[#7a4e2a] text-sm">
                      No hay actividades programadas para este ministerio.
                    </p>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-[#fffdf5] p-12 rounded-3xl border-2 border-[#7a4e2a] text-center text-sm text-[#7a4e2a]">
              Seleccione un ministerio de la columna izquierda para consultar sus detalles.
            </div>
          )}
        </div>
      </div>

      {/* Modal Crear / Editar Ministerio */}
      <Modal
        isOpen={modalMinisterioAbierto}
        onClose={() => setModalMinisterioAbierto(false)}
        titulo={ministerioEnEdicion ? 'Editar Ficha del Ministerio' : 'Registrar Nuevo Ministerio'}
      >
        <form onSubmit={handleGuardarMinisterio} className="space-y-4 text-[#2b190a]">
          <div>
            <label className="block text-sm font-bold text-[#7a4e2a] mb-1">
              Nombre del Ministerio *
            </label>
            <input
              type="text"
              required
              placeholder="Ej. Música, Jóvenes, Niños, Enseñanza, Servicio..."
              value={formMinisterio.nombre}
              onChange={(e) => setFormMinisterio({ ...formMinisterio, nombre: e.target.value })}
              className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
            />
          </div>

          <div>
            <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Descripción y Objetivos</label>
            <textarea
              rows={2}
              placeholder="Objetivos formativos y de servicio..."
              value={formMinisterio.descripcion}
              onChange={(e) => setFormMinisterio({ ...formMinisterio, descripcion: e.target.value })}
              className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
            />
          </div>

          <div>
            <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Coordinador Asignado</label>
            <select
              value={formMinisterio.coordinador_id}
              onChange={(e) => setFormMinisterio({ ...formMinisterio, coordinador_id: e.target.value })}
              className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
            >
              <option value="">-- Sin coordinador asignado --</option>
              {todosLosMiembros.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.nombre}
                </option>
              ))}
            </select>
          </div>

          <div className="flex justify-end space-x-3 pt-4 border-t-2 border-[#7a4e2a]">
            <button
              type="button"
              onClick={() => setModalMinisterioAbierto(false)}
              className="px-5 py-2.5 border-2 border-[#7a4e2a] rounded-xl text-sm text-[#7a4e2a] hover:bg-[#faf4ea] font-bold"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={guardando}
              className="px-6 py-2.5 bg-[#fef9c3] hover:bg-[#ebd8c3] text-[#7a4e2a] border-2 border-[#7a4e2a] rounded-xl text-sm font-bold transition-all disabled:opacity-50"
            >
              {guardando ? 'Guardando...' : 'Guardar Ministerio'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Modal Vincular Miembro */}
      <Modal
        isOpen={modalVincularAbierto}
        onClose={() => setModalVincularAbierto(false)}
        titulo={`Vincular Miembro a ${ministerioSeleccionado?.nombre || ''}`}
      >
        <form onSubmit={handleVincularMiembro} className="space-y-4 text-[#2b190a]">
          <div>
            <label className="block text-sm font-bold text-[#7a4e2a] mb-1">
              Miembro de la Congregación *
            </label>
            <select
              required
              value={formVinculo.miembro_id}
              onChange={(e) => setFormVinculo({ ...formVinculo, miembro_id: e.target.value })}
              className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
            >
              <option value="">-- Seleccionar miembro --</option>
              {todosLosMiembros.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.nombre}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Función o Rol en el Ministerio *</label>
            <input
              type="text"
              required
              placeholder="Ej. Instrumentista, Maestro, Ujier, Servidor..."
              value={formVinculo.rol_ministerio}
              onChange={(e) => setFormVinculo({ ...formVinculo, rol_ministerio: e.target.value })}
              className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
            />
          </div>

          <div className="flex justify-end space-x-3 pt-4 border-t-2 border-[#7a4e2a]">
            <button
              type="button"
              onClick={() => setModalVincularAbierto(false)}
              className="px-5 py-2.5 border-2 border-[#7a4e2a] rounded-xl text-sm text-[#7a4e2a] hover:bg-[#faf4ea] font-bold"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={guardando}
              className="px-6 py-2.5 bg-[#fef9c3] hover:bg-[#ebd8c3] text-[#7a4e2a] border-2 border-[#7a4e2a] rounded-xl text-sm font-bold transition-all disabled:opacity-50"
            >
              {guardando ? 'Vinculando...' : 'Integrar al Ministerio'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Modal Actividad */}
      <Modal
        isOpen={modalActividadAbierto}
        onClose={() => setModalActividadAbierto(false)}
        titulo="Programar Actividad Ministerial"
      >
        <form onSubmit={handleGuardarActividad} className="space-y-4 text-[#2b190a]">
          <div>
            <label className="block text-sm font-bold text-[#7a4e2a] mb-1">
              Nombre de la Actividad *
            </label>
            <input
              type="text"
              required
              placeholder="Ej. Ensayo general, Taller de capacitación..."
              value={formActividad.titulo}
              onChange={(e) => setFormActividad({ ...formActividad, titulo: e.target.value })}
              className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Fecha *</label>
              <input
                type="date"
                required
                value={formActividad.fecha}
                onChange={(e) => setFormActividad({ ...formActividad, fecha: e.target.value })}
                className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Hora *</label>
              <input
                type="time"
                required
                value={formActividad.hora}
                onChange={(e) => setFormActividad({ ...formActividad, hora: e.target.value })}
                className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Lugar de Reunión</label>
            <input
              type="text"
              placeholder="Salón o espacio de reunión"
              value={formActividad.lugar}
              onChange={(e) => setFormActividad({ ...formActividad, lugar: e.target.value })}
              className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
            />
          </div>

          <div>
            <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Notas y Objetivos</label>
            <textarea
              rows={2}
              placeholder="Puntos a tratar..."
              value={formActividad.descripcion}
              onChange={(e) => setFormActividad({ ...formActividad, descripcion: e.target.value })}
              className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
            />
          </div>

          <div className="flex justify-end space-x-3 pt-4 border-t-2 border-[#7a4e2a]">
            <button
              type="button"
              onClick={() => setModalActividadAbierto(false)}
              className="px-5 py-2.5 border-2 border-[#7a4e2a] rounded-xl text-sm text-[#7a4e2a] hover:bg-[#faf4ea] font-bold"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={guardando}
              className="px-6 py-2.5 bg-[#fef9c3] hover:bg-[#ebd8c3] text-[#7a4e2a] border-2 border-[#7a4e2a] rounded-xl text-sm font-bold transition-all disabled:opacity-50"
            >
              {guardando ? 'Guardando...' : 'Programar Actividad'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
