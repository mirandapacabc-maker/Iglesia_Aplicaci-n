/**
 * Componente Reutilizable: Ventana Modal Eclesiástica
 * Paleta: Predominante #fffdf5, Contorno #7a4e2a, Blanco, Beige (#faf4ea, #f5ede1) y Amarillo Pálido #fef9c3.
 * Tipografía: Day Roman Regular (letras más grandes).
 */
import React, { useEffect } from 'react';

export default function Modal({ isOpen, onClose, titulo, children, maxWidth = 'max-w-xl' }) {
  useEffect(() => {
    function handleKeyDown(e) {
      if (e.key === 'Escape' && isOpen) onClose();
    }
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-[#2b190a]/50 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 animate-fadeIn font-serif">
      <div
        className={`bg-[#fffdf5] rounded-2xl shadow-2xl border-2 border-[#7a4e2a] w-full ${maxWidth} transform transition-all duration-200 overflow-hidden max-h-[90vh] flex flex-col`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Cabecera del modal */}
        <div className="flex items-center justify-between px-6 py-4.5 border-b-2 border-[#7a4e2a] bg-[#faf4ea]">
          <h3 className="text-lg font-bold text-[#7a4e2a]">{titulo}</h3>
          <button
            onClick={onClose}
            className="text-sm text-[#7a4e2a] hover:text-[#2b190a] bg-[#fffdf5] hover:bg-[#fef9c3] rounded-md px-3.5 py-1.5 transition-colors border-2 border-[#7a4e2a] font-bold"
          >
            Cerrar
          </button>
        </div>

        {/* Contenido scrolleable */}
        <div className="p-6 overflow-y-auto flex-1 text-[#2b190a] bg-[#fffdf5] text-base">
          {children}
        </div>
      </div>
    </div>
  );
}
