/**
 * Rutas de la API para la generación de reportes eclesiásticos y financieros (RF-09).
 */
const { Router } = require('express');
const {
  reporteGeneralMiembros,
  reporteAsistenciaPorEvento,
  reporteParticipacionMinisterios,
  reporteIngresosPeriodo
} = require('../controllers/reportesController');
const { autenticarToken } = require('../middleware/authMiddleware');

const router = Router();

router.use(autenticarToken);

router.get('/miembros', reporteGeneralMiembros);
router.get('/asistencia', reporteAsistenciaPorEvento);
router.get('/ministerios', reporteParticipacionMinisterios);
router.get('/ingresos', reporteIngresosPeriodo); // El controlador valida internamente los roles financieros

module.exports = router;
