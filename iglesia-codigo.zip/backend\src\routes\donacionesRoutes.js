/**
 * Rutas de la API para gestión financiera y donaciones (RF-06).
 * Protección estricta: Solo los roles 'Administrador', 'Pastor' y 'Tesorero' pueden acceder.
 */
const { Router } = require('express');
const {
  listarDonaciones,
  registrarDonacion,
  resumenMensualIngresos,
  eliminarDonacion
} = require('../controllers/donacionesController');
const { autenticarToken, autorizarRoles } = require('../middleware/authMiddleware');

const router = Router();

// Aplicar autenticación y restricción por roles financieros a todas las rutas de este módulo
router.use(autenticarToken);
router.use(autorizarRoles('Administrador', 'Pastor', 'Tesorero'));

router.get('/', listarDonaciones);
router.get('/resumen-mensual', resumenMensualIngresos);
router.post('/', registrarDonacion);
router.delete('/:id', autorizarRoles('Administrador', 'Tesorero'), eliminarDonacion);

module.exports = router;
