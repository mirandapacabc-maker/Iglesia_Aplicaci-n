import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Configuración de Vite con proxy hacia el backend Express
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    host: true, // Permite acceso desde dispositivos móviles en la misma red local
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:4000',
        changeOrigin: true,
        secure: false,
      }
    }
  }
});
