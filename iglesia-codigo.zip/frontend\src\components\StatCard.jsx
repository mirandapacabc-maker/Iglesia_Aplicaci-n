/**
 * Componente Reutilizable: Tarjeta Métrica Eclesiástica.
 * Fondo predominante #fffdf5, borde de contorno #7a4e2a, detalles en beige y amarillo pálido #fef9c3.
 * Tipografía: Day Roman Regular (letras más grandes).
 */
import React from 'react';

export default function StatCard({ titulo, valor, subtitulo, extra }) {
  return (
    <div className="bg-[#fffdf5] rounded-2xl p-6 border-2 border-[#7a4e2a] shadow-sm hover:shadow-md transition-all">
      <div className="space-y-1.5">
        <p className="text-xs uppercase tracking-wider text-[#7a4e2a] font-bold">{titulo}</p>
        <p className="text-3xl sm:text-4xl font-bold text-[#2b190a] tracking-tight">{valor}</p>
        {subtitulo && <p className="text-sm text-[#58351a]">{subtitulo}</p>}
      </div>
      {extra && <div className="mt-3.5 pt-3.5 border-t border-[#7a4e2a]/30">{extra}</div>}
    </div>
  );
}
