/**
 * Definición de rutas del módulo de autenticación y gestión de usuarios (RF-01).
 */
const { Router } = require('express');
const {
  registrar,
  login,
  perfilActual,
  solicitarRecuperacion,
  restablecerPassword,
  listarUsuarios,
  cambiarEstadoUsuario
} = require('../controllers/authController');
const { autenticarToken, autorizarRoles } = require('../middleware/authMiddleware');

const router = Router();

// Rutas públicas
router.post('/login', login);
router.post('/registro', registrar);
router.post('/recuperar-password', solicitarRecuperacion);
router.post('/restablecer-password', restablecerPassword);

// Rutas protegidas
router.get('/me', autenticarToken, perfilActual);
router.get('/usuarios', autenticarToken, autorizarRoles('Administrador'), listarUsuarios);
router.patch('/usuarios/:id/estado', autenticarToken, autorizarRoles('Administrador'), cambiarEstadoUsuario);

module.exports = router;
