/**
 * Controlador de Gestión de Miembros de la Iglesia (RF-02).
 * Gestiona altas, modificaciones, consulta paginada, filtros por estado y borrado lógico (soft-delete).
 */
const db = require('../config/database');

/**
 * Listado de miembros con soporte de búsqueda por nombre, filtro de estado (activo/inactivo/todos)
 * y paginación limpia.
 */
function listarMiembros(req, res, next) {
  try {
    const { busqueda = '', estado = 'activos', pagina = 1, limite = 10 } = req.query;

    const limitNum = Math.max(1, parseInt(limite, 10));
    const offset = (Math.max(1, parseInt(pagina, 10)) - 1) * limitNum;

    let condiciones = [];
    let parametros = [];

    // Filtro por término de búsqueda (nombre, teléfono o email)
    if (busqueda && busqueda.trim()) {
      condiciones.push('(nombre LIKE ? OR telefono LIKE ? OR email LIKE ?)');
      const termino = `%${busqueda.trim()}%`;
      parametros.push(termino, termino, termino);
    }

    // Filtro por estado activo / inactivo / todos
    if (estado === 'activos') {
      condiciones.push('activo = 1');
    } else if (estado === 'inactivos') {
      condiciones.push('activo = 0');
    }

    const whereClause = condiciones.length > 0 ? `WHERE ${condiciones.join(' AND ')}` : '';

    // Consulta total para metadatos de paginación
    const totalQuery = `SELECT COUNT(*) as total FROM miembros ${whereClause}`;
    const totalRegistros = db.prepare(totalQuery).get(...parametros).total;

    // Consulta paginada
    const dataQuery = `
      SELECT id, nombre, telefono, email, direccion, fecha_ingreso, fecha_nacimiento, activo, notas, creado_en
      FROM miembros
      ${whereClause}
      ORDER BY nombre ASC
      LIMIT ? OFFSET ?
    `;
    const miembros = db.prepare(dataQuery).all(...parametros, limitNum, offset);

    return res.json({
      miembros,
      paginacion: {
        total: totalRegistros,
        pagina: parseInt(pagina, 10),
        limite: limitNum,
        totalPaginas: Math.ceil(totalRegistros / limitNum)
      }
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Obtener detalle de un miembro específico por ID.
 */
function obtenerMiembroPorId(req, res, next) {
  try {
    const { id } = req.params;
    const miembro = db.prepare(`
      SELECT id, nombre, telefono, email, direccion, fecha_ingreso, fecha_nacimiento, activo, notas, creado_en
      FROM miembros 
      WHERE id = ?
    `).get(id);

    if (!miembro) {
      return res.status(404).json({ mensaje: 'Miembro no encontrado en el directorio.' });
    }

    // Obtener ministerios a los que pertenece
    const ministerios = db.prepare(`
      SELECT m.id, m.nombre, mm.rol_ministerio, mm.fecha_ingreso
      FROM ministerio_miembros mm
      JOIN ministerios m ON mm.ministerio_id = m.id
      WHERE mm.miembro_id = ?
    `).all(id);

    return res.json({
      miembro,
      ministerios
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Registro de un nuevo miembro con validaciones requeridas.
 */
function crearMiembro(req, res, next) {
  try {
    const { nombre, telefono, email, direccion, fecha_ingreso, fecha_nacimiento, notas } = req.body;

    if (!nombre || !nombre.trim()) {
      return res.status(400).json({ mensaje: 'El nombre del miembro es un campo obligatorio.' });
    }

    if (!fecha_ingreso) {
      return res.status(400).json({ mensaje: 'La fecha de ingreso a la congregación es obligatoria.' });
    }

    const resultado = db.prepare(`
      INSERT INTO miembros (nombre, telefono, email, direccion, fecha_ingreso, fecha_nacimiento, activo, notas)
      VALUES (?, ?, ?, ?, ?, ?, 1, ?)
    `).run(
      nombre.trim(),
      telefono ? telefono.trim() : null,
      email ? email.toLowerCase().trim() : null,
      direccion ? direccion.trim() : null,
      fecha_ingreso,
      fecha_nacimiento || null,
      notas ? notas.trim() : null
    );

    const nuevoMiembro = db.prepare('SELECT * FROM miembros WHERE id = ?').get(resultado.lastInsertRowid);

    return res.status(201).json({
      mensaje: 'Miembro registrado exitosamente.',
      miembro: nuevoMiembro
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Actualización de datos personales de un miembro.
 */
function actualizarMiembro(req, res, next) {
  try {
    const { id } = req.params;
    const { nombre, telefono, email, direccion, fecha_ingreso, fecha_nacimiento, notas, activo } = req.body;

    if (!nombre || !nombre.trim()) {
      return res.status(400).json({ mensaje: 'El nombre es obligatorio.' });
    }

    const miembroExistente = db.prepare('SELECT id FROM miembros WHERE id = ?').get(id);
    if (!miembroExistente) {
      return res.status(404).json({ mensaje: 'El miembro que intentas actualizar no existe.' });
    }

    db.prepare(`
      UPDATE miembros
      SET nombre = ?, telefono = ?, email = ?, direccion = ?, fecha_ingreso = ?, fecha_nacimiento = ?, notas = ?, activo = ?
      WHERE id = ?
    `).run(
      nombre.trim(),
      telefono ? telefono.trim() : null,
      email ? email.toLowerCase().trim() : null,
      direccion ? direccion.trim() : null,
      fecha_ingreso,
      fecha_nacimiento || null,
      notas ? notas.trim() : null,
      activo !== undefined ? (activo ? 1 : 0) : 1,
      id
    );

    const miembroActualizado = db.prepare('SELECT * FROM miembros WHERE id = ?').get(id);

    return res.json({
      mensaje: 'Datos del miembro actualizados correctamente.',
      miembro: miembroActualizado
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Desactivación lógica (soft-delete) o reactivación de un miembro sin eliminar registros físicos.
 */
function alternarEstadoMiembro(req, res, next) {
  try {
    const { id } = req.params;
    const { activo } = req.body;

    const miembro = db.prepare('SELECT id, nombre, activo FROM miembros WHERE id = ?').get(id);
    if (!miembro) {
      return res.status(404).json({ mensaje: 'Miembro no encontrado.' });
    }

    const nuevoEstado = activo !== undefined ? (activo ? 1 : 0) : (miembro.activo ? 0 : 1);
    db.prepare('UPDATE miembros SET activo = ? WHERE id = ?').run(nuevoEstado, id);

    return res.json({
      mensaje: `Miembro ${nuevoEstado ? 'reactivado' : 'desactivado lógicamente'} con éxito.`,
      activo: nuevoEstado
    });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  listarMiembros,
  obtenerMiembroPorId,
  crearMiembro,
  actualizarMiembro,
  alternarEstadoMiembro
};
