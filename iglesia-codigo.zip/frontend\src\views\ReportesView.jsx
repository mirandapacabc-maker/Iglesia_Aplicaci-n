/**
 * Vista de Generación y Exportación de Reportes de la Iglesia (RF-09).
 * Predominante: #fffdf5, Contorno: #7a4e2a, Blanco, Beige (#faf4ea, #f5ede1) y Amarillo Pálido #fef9c3.
 * Tipografía: Day Roman Regular (sin iconos, letras más grandes y legibles).
 */
import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { reportesService } from '../services/api';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';

export default function ReportesView({ configIglesia }) {
  const { puedeVerFinanzas } = useAuth();

  const [tipoReporte, setTipoReporte] = useState('miembros');
  const [fechaInicio, setFechaInicio] = useState('');
  const [fechaFin, setFechaFin] = useState('');
  const [estadoMiembro, setEstadoMiembro] = useState('todos');

  const [cargando, setCargando] = useState(false);
  const [datosReporte, setDatosReporte] = useState(null);
  const [error, setError] = useState('');
  const [mensaje, setMensaje] = useState('');

  const nombreIglesia = configIglesia?.nombre || 'Comunidad Cristiana';

  async function generarVistaPrevia() {
    setCargando(true);
    setError('');
    setMensaje('');
    setDatosReporte(null);

    try {
      let res;
      if (tipoReporte === 'miembros') {
        res = await reportesService.miembros({ estado: estadoMiembro });
      } else if (tipoReporte === 'asistencia') {
        res = await reportesService.asistencia({ fecha_inicio: fechaInicio, fecha_fin: fechaFin });
      } else if (tipoReporte === 'ministerios') {
        res = await reportesService.ministerios();
      } else if (tipoReporte === 'ingresos') {
        if (!puedeVerFinanzas) {
          setError('No cuenta con privilegios para consultar reportes contables.');
          return;
        }
        res = await reportesService.ingresos({ fecha_inicio: fechaInicio, fecha_fin: fechaFin });
      }

      setDatosReporte(res);
      setMensaje('Vista previa generada con éxito.');
    } catch (err) {
      setError(err.message || 'Error al generar el reporte.');
    } finally {
      setCargando(false);
    }
  }

  function exportarPDF() {
    if (!datosReporte) return;

    const doc = new jsPDF();

    doc.setFontSize(16);
    doc.setTextColor(122, 78, 42);
    doc.text(nombreIglesia, 14, 18);

    doc.setFontSize(10);
    doc.setTextColor(88, 53, 26);
    doc.text(`Fecha de emisión: ${new Date().toLocaleDateString('es-MX')}`, 14, 25);

    let columnas = [];
    let filas = [];
    let tituloSeccion = '';

    if (tipoReporte === 'miembros') {
      tituloSeccion = 'Reporte General de Miembros';
      columnas = ['Nombre Completo', 'Teléfono', 'Correo', 'Fecha Ingreso', 'Estado', 'Ministerios'];
      filas = (datosReporte.miembros || []).map((m) => [
        m.nombre,
        m.telefono || '—',
        m.email || '—',
        m.fecha_ingreso,
        m.activo ? 'Activo' : 'Inactivo',
        m.ministerios_nombres || 'Ninguno',
      ]);
    } else if (tipoReporte === 'asistencia') {
      tituloSeccion = 'Reporte de Asistencia por Evento';
      columnas = ['Fecha', 'Evento / Culto', 'Tipo', 'Miembro', 'Estado'];
      filas = (datosReporte.asistencias || []).map((a) => [
        a.fecha,
        a.evento_titulo,
        a.evento_tipo,
        a.miembro_nombre,
        a.estado,
      ]);
    } else if (tipoReporte === 'ministerios') {
      tituloSeccion = 'Reporte de Participación por Ministerio';
      columnas = ['Ministerio', 'Coordinador', 'Integrante', 'Función / Rol', 'Fecha Ingreso'];
      filas = (datosReporte.filasPlanificadas || []).map((f) => [
        f.ministerio_nombre,
        f.coordinador_nombre || '—',
        f.miembro_nombre,
        f.rol_ministerio || 'Miembro',
        f.fecha_ingreso_ministerio || '—',
      ]);
    } else if (tipoReporte === 'ingresos') {
      tituloSeccion = 'Reporte de Ingresos por Periodo';
      columnas = ['Fecha', 'Concepto', 'Método', 'Aportante', 'Monto ($ MXN)'];
      filas = (datosReporte.donaciones || []).map((d) => [
        d.fecha,
        d.concepto,
        d.metodo_pago,
        d.aportante,
        `$${Number(d.monto).toLocaleString('es-MX', { minimumFractionDigits: 2 })}`,
      ]);
    }

    doc.setFontSize(12);
    doc.setTextColor(122, 78, 42);
    doc.text(tituloSeccion, 14, 34);

    autoTable(doc, {
      startY: 40,
      head: [columnas],
      body: filas,
      styles: { fontSize: 8.5, cellPadding: 3.5, textColor: [43, 25, 10] },
      headStyles: { fillColor: [122, 78, 42], textColor: [255, 253, 245] },
      alternateRowStyles: { fillColor: [245, 237, 225] },
    });

    doc.save(`Reporte_${tipoReporte}_${new Date().toISOString().split('T')[0]}.pdf`);
  }

  function exportarExcel() {
    if (!datosReporte) return;

    let dataExcel = [];

    if (tipoReporte === 'miembros') {
      dataExcel = (datosReporte.miembros || []).map((m) => ({
        'Nombre Completo': m.nombre,
        'Teléfono': m.telefono || '',
        'Correo': m.email || '',
        'Dirección': m.direccion || '',
        'Fecha Ingreso': m.fecha_ingreso,
        'Estado': m.activo ? 'Activo' : 'Inactivo',
        'Ministerios': m.ministerios_nombres || 'Ninguno',
      }));
    } else if (tipoReporte === 'asistencia') {
      dataExcel = (datosReporte.asistencias || []).map((a) => ({
        'Fecha': a.fecha,
        'Evento': a.evento_titulo,
        'Tipo': a.evento_tipo,
        'Miembro': a.miembro_nombre,
        'Teléfono': a.miembro_telefono || '',
        'Estado': a.estado,
      }));
    } else if (tipoReporte === 'ministerios') {
      dataExcel = (datosReporte.filasPlanificadas || []).map((f) => ({
        'Ministerio': f.ministerio_nombre,
        'Coordinador': f.coordinador_nombre || 'N/A',
        'Integrante': f.miembro_nombre,
        'Teléfono': f.miembro_telefono || '',
        'Función': f.rol_ministerio || 'Miembro',
        'Fecha Vinculación': f.fecha_ingreso_ministerio || '',
      }));
    } else if (tipoReporte === 'ingresos') {
      dataExcel = (datosReporte.donaciones || []).map((d) => ({
        'Fecha': d.fecha,
        'Concepto': d.concepto,
        'Método Pago': d.metodo_pago,
        'Aportante': d.aportante,
        'Monto MXN': d.monto,
        'Notas': d.notas || '',
      }));
    }

    const hoja = XLSX.utils.json_to_sheet(dataExcel);
    const libro = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(libro, hoja, 'Reporte');
    XLSX.writeFile(libro, `Reporte_${tipoReporte}_${new Date().toISOString().split('T')[0]}.xlsx`);
  }

  return (
    <div className="space-y-7 text-[#2b190a] font-serif">
      {/* Cabecera */}
      <div>
        <h2 className="text-3xl sm:text-4xl font-normal text-[#7a4e2a]">
          Reportes Institucionales
        </h2>
        <p className="text-sm text-[#58351a] mt-1 font-medium">
          Reportes de miembros, asistencia, participación por ministerio e ingresos con exportación a PDF y Excel (RF-09)
        </p>
      </div>

      {/* Alertas */}
      {mensaje && (
        <div className="p-4 bg-[#faf4ea] border-2 border-[#7a4e2a] rounded-xl text-[#7a4e2a] text-sm font-bold">
          {mensaje}
        </div>
      )}

      {error && (
        <div className="p-4 bg-[#fff2f0] border-2 border-[#7a4e2a] rounded-xl text-[#783636] text-sm">
          {error}
        </div>
      )}

      {/* Selector de los 4 Reportes (RF-09) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <button
          onClick={() => { setTipoReporte('miembros'); setDatosReporte(null); }}
          className={`p-5 rounded-2xl border-2 text-left transition-all ${
            tipoReporte === 'miembros'
              ? 'bg-[#fef9c3] border-[#7a4e2a] shadow-xs'
              : 'bg-[#fffdf5] border-[#7a4e2a]/40 hover:border-[#7a4e2a]'
          }`}
        >
          <span className="text-xs uppercase tracking-wider text-[#7a4e2a] font-bold block mb-1">Padrón</span>
          <h4 className="text-base font-bold text-[#7a4e2a]">1. Reporte de Miembros</h4>
          <p className="text-xs text-[#58351a] mt-1">Directorio general y estado</p>
        </button>

        <button
          onClick={() => { setTipoReporte('asistencia'); setDatosReporte(null); }}
          className={`p-5 rounded-2xl border-2 text-left transition-all ${
            tipoReporte === 'asistencia'
              ? 'bg-[#fef9c3] border-[#7a4e2a] shadow-xs'
              : 'bg-[#fffdf5] border-[#7a4e2a]/40 hover:border-[#7a4e2a]'
          }`}
        >
          <span className="text-xs uppercase tracking-wider text-[#7a4e2a] font-bold block mb-1">Cultos</span>
          <h4 className="text-base font-bold text-[#7a4e2a]">2. Asistencia por Evento</h4>
          <p className="text-xs text-[#58351a] mt-1">Asistencias y ausencias registradas</p>
        </button>

        <button
          onClick={() => { setTipoReporte('ministerios'); setDatosReporte(null); }}
          className={`p-5 rounded-2xl border-2 text-left transition-all ${
            tipoReporte === 'ministerios'
              ? 'bg-[#fef9c3] border-[#7a4e2a] shadow-xs'
              : 'bg-[#fffdf5] border-[#7a4e2a]/40 hover:border-[#7a4e2a]'
          }`}
        >
          <span className="text-xs uppercase tracking-wider text-[#7a4e2a] font-bold block mb-1">Servicio</span>
          <h4 className="text-base font-bold text-[#7a4e2a]">3. Por Ministerio</h4>
          <p className="text-xs text-[#58351a] mt-1">Participación e integrantes vinculados</p>
        </button>

        {puedeVerFinanzas ? (
          <button
            onClick={() => { setTipoReporte('ingresos'); setDatosReporte(null); }}
            className={`p-5 rounded-2xl border-2 text-left transition-all ${
              tipoReporte === 'ingresos'
                ? 'bg-[#fef9c3] border-[#7a4e2a] shadow-xs'
                : 'bg-[#fffdf5] border-[#7a4e2a]/40 hover:border-[#7a4e2a]'
            }`}
          >
            <span className="text-xs uppercase tracking-wider text-[#7a4e2a] font-bold block mb-1">Finanzas</span>
            <h4 className="text-base font-bold text-[#7a4e2a]">4. Ingresos por Periodo</h4>
            <p className="text-xs text-[#58351a] mt-1">Diezmos, ofrendas y donaciones</p>
          </button>
        ) : (
          <div className="p-5 rounded-2xl border-2 border-[#7a4e2a]/30 bg-[#faf4ea] opacity-60">
            <h4 className="text-sm font-bold text-[#7a4e2a]/70">4. Ingresos</h4>
            <p className="text-xs text-[#7a4e2a]/60 mt-1">Reservado para roles autorizados</p>
          </div>
        )}
      </div>

      {/* Filtros específicos según tipo de reporte */}
      <div className="bg-[#fffdf5] p-6 rounded-2xl border-2 border-[#7a4e2a] shadow-xs space-y-4">
        <h3 className="text-xs font-bold text-[#7a4e2a] uppercase tracking-wider pb-2 border-b-2 border-[#7a4e2a]/30">
          Criterios de Consulta
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4.5">
          {tipoReporte === 'miembros' && (
            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Filtrar por Estado</label>
              <select
                value={estadoMiembro}
                onChange={(e) => setEstadoMiembro(e.target.value)}
                className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
              >
                <option value="todos">Todos los miembros</option>
                <option value="activos">Miembros Activos</option>
                <option value="inactivos">Miembros Inactivos</option>
              </select>
            </div>
          )}

          {(tipoReporte === 'asistencia' || tipoReporte === 'ingresos') && (
            <>
              <div>
                <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Fecha Inicial</label>
                <input
                  type="date"
                  value={fechaInicio}
                  onChange={(e) => setFechaInicio(e.target.value)}
                  className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Fecha Final</label>
                <input
                  type="date"
                  value={fechaFin}
                  onChange={(e) => setFechaFin(e.target.value)}
                  className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
                />
              </div>
            </>
          )}

          {tipoReporte === 'ministerios' && (
            <div className="sm:col-span-2 text-sm text-[#58351a] flex items-center">
              Este reporte consolida todos los ministerios activos con sus coordinadores, integrantes y roles.
            </div>
          )}

          <div className="flex items-end">
            <button
              onClick={generarVistaPrevia}
              disabled={cargando}
              className="w-full py-3 bg-[#fef9c3] hover:bg-[#ebd8c3] text-[#7a4e2a] border-2 border-[#7a4e2a] rounded-xl text-sm font-bold transition-all disabled:opacity-50"
            >
              {cargando ? 'Generando...' : 'Consultar y Generar Reporte'}
            </button>
          </div>
        </div>
      </div>

      {/* Vista Previa y Botones de Exportación (PDF / Excel) */}
      {datosReporte && (
        <div className="bg-[#fffdf5] rounded-3xl border-2 border-[#7a4e2a] shadow-xs p-7 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-3 border-b-2 border-[#7a4e2a]/30">
            <div>
              <h3 className="text-xl font-bold text-[#7a4e2a]">Reporte Generado</h3>
              <p className="text-sm text-[#58351a]">
                Puede exportar el informe directamente en formato PDF o libro Excel (RF-09).
              </p>
            </div>

            <div className="flex space-x-3">
              <button
                onClick={exportarPDF}
                className="px-5 py-2.5 bg-[#7a4e2a] hover:bg-[#684122] text-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-sm font-bold transition-all"
              >
                Exportar a PDF
              </button>
              <button
                onClick={exportarExcel}
                className="px-5 py-2.5 bg-[#fef9c3] hover:bg-[#ebd8c3] text-[#7a4e2a] border-2 border-[#7a4e2a] rounded-xl text-sm font-bold transition-all"
              >
                Exportar a Excel
              </button>
            </div>
          </div>

          {/* Resumen del reporte */}
          <div className="p-4 bg-[#faf4ea] border-2 border-[#7a4e2a] rounded-2xl text-sm text-[#7a4e2a]">
            {tipoReporte === 'miembros' && (
              <span>Total de miembros incluidos en el reporte: <strong>{datosReporte.total}</strong></span>
            )}
            {tipoReporte === 'asistencia' && (
              <span>Total de registros de asistencia analizados: <strong>{datosReporte.totalRegistros}</strong></span>
            )}
            {tipoReporte === 'ministerios' && (
              <span>Total de ministerios: <strong>{datosReporte.totalMinisterios}</strong> • Total de miembros vinculados: <strong>{datosReporte.totalVinculos}</strong></span>
            )}
            {tipoReporte === 'ingresos' && (
              <span>Aportaciones computadas: <strong>{datosReporte.totalDonaciones}</strong> • Monto total recaudado: <strong>${Number(datosReporte.totalMonto).toLocaleString('es-MX', { minimumFractionDigits: 2 })}</strong></span>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
