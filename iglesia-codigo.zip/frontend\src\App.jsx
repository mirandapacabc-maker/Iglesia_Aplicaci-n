/**
 * Componente Raíz de la Aplicación (Frontend Eclesiástico).
 * Gestiona el enrutamiento de vistas internas, control de autenticación global (RF-01 a RF-10)
 * y carga de la configuración institucional.
 */
import React, { useState, useEffect } from 'react';
import { useAuth } from './context/AuthContext';
import { configuracionService } from './services/api';

import Layout from './components/Layout';
import LoginView from './views/LoginView';
import RecuperarPasswordView from './views/RecuperarPasswordView';
import DashboardView from './views/DashboardView';
import MiembrosView from './views/MiembrosView';
import AsistenciaView from './views/AsistenciaView';
import EventosView from './views/EventosView';
import MinisteriosView from './views/MinisteriosView';
import DonacionesView from './views/DonacionesView';
import AnunciosView from './views/AnunciosView';
import ReportesView from './views/ReportesView';
import ConfiguracionView from './views/ConfiguracionView';

export default function App() {
  const { estaAutenticado, cargando } = useAuth();

  // Control de vista activa y flujo de autenticación
  const [vistaActual, setVistaActual] = useState('dashboard');
  const [mostrarRecuperar, setMostrarRecuperar] = useState(false);
  const [configIglesia, setConfigIglesia] = useState(null);

  // Cargar datos de la iglesia al montar
  useEffect(() => {
    async function obtenerDatosIglesia() {
      try {
        const res = await configuracionService.obtener();
        if (res.configuracion) {
          setConfigIglesia(res.configuracion);
        }
      } catch (err) {
        console.error('Error al obtener datos institucionales:', err);
      }
    }
    obtenerDatosIglesia();
  }, []);

  // Pantalla de carga inicial
  if (cargando) {
    return (
      <div className="min-h-screen bg-[#fffdf5] flex flex-col items-center justify-center space-y-4 font-serif">
        <div className="animate-spin rounded-full h-11 w-11 border-3 border-[#7a4e2a] border-t-[#fef9c3]"></div>
        <p className="text-3xl font-normal text-[#7a4e2a]">
          Comunidad de Fe
        </p>
        <p className="text-sm italic text-[#58351a] tracking-wider">
          Cargando sistema eclesiástico...
        </p>
      </div>
    );
  }

  // Flujo público de autenticación y recuperación de contraseñas (RF-01)
  if (!estaAutenticado) {
    if (mostrarRecuperar) {
      return <RecuperarPasswordView onVolverLogin={() => setMostrarRecuperar(false)} />;
    }
    return <LoginView onIrRecuperarPassword={() => setMostrarRecuperar(true)} />;
  }

  // Renderizado dinámico de vistas según navegación interna
  return (
    <Layout
      vistaActual={vistaActual}
      setVistaActual={setVistaActual}
      configIglesia={configIglesia}
    >
      {vistaActual === 'dashboard' && <DashboardView onNavegar={setVistaActual} />}
      {vistaActual === 'miembros' && <MiembrosView />}
      {vistaActual === 'asistencia' && <AsistenciaView />}
      {vistaActual === 'eventos' && <EventosView />}
      {vistaActual === 'ministerios' && <MinisteriosView />}
      {vistaActual === 'donaciones' && <DonacionesView />}
      {vistaActual === 'anuncios' && <AnunciosView />}
      {vistaActual === 'reportes' && <ReportesView configIglesia={configIglesia} />}
      {vistaActual === 'configuracion' && (
        <ConfiguracionView onConfiguracionActualizada={(nuevaConfig) => setConfigIglesia(nuevaConfig)} />
      )}
    </Layout>
  );
}
