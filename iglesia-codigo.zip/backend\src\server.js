/**
 * Servidor Principal de la API REST - Sistema de Gestión Integral para Iglesias.
 * Conexión de middlewares, enrutadores modulares y manejador global de errores.
 */
require('dotenv').config();
const express = require('express');
const cors = require('cors');

// Importar rutas de cada módulo
const authRoutes = require('./routes/authRoutes');
const miembrosRoutes = require('./routes/miembrosRoutes');
const eventosRoutes = require('./routes/eventosRoutes');
const asistenciaRoutes = require('./routes/asistenciaRoutes');
const ministeriosRoutes = require('./routes/ministeriosRoutes');
const donacionesRoutes = require('./routes/donacionesRoutes');
const anunciosRoutes = require('./routes/anunciosRoutes');
const dashboardRoutes = require('./routes/dashboardRoutes');
const reportesRoutes = require('./routes/reportesRoutes');
const configuracionRoutes = require('./routes/configuracionRoutes');

const { manejadorErrores } = require('./middleware/errorHandler');
const path = require('node:path');
const fs = require('node:fs');

const app = express();
const PORT = process.env.PORT || 4000;

// Configuración de middlewares globales
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Ruta de estado de la API
app.get('/api/health', (req, res) => {
  res.json({
    estado: 'online',
    sistema: 'Sistema de Gestión Integral para Iglesias',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

// Registro de rutas por módulo funcional (RF-01 a RF-10)
app.use('/api/auth', authRoutes);
app.use('/api/miembros', miembrosRoutes);
app.use('/api/eventos', eventosRoutes);
app.use('/api/asistencia', asistenciaRoutes);
app.use('/api/ministerios', ministeriosRoutes);
app.use('/api/donaciones', donacionesRoutes);
app.use('/api/anuncios', anunciosRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/reportes', reportesRoutes);
app.use('/api/configuracion', configuracionRoutes);

// Servir frontend compilado en producción o modo unificado
const frontendDistPath = path.resolve(__dirname, '../../frontend/dist');
if (fs.existsSync(frontendDistPath)) {
  app.use(express.static(frontendDistPath));
  app.get('*', (req, res, next) => {
    // Si la solicitud no es a la API, servir el index.html del frontend
    if (req.path.startsWith('/api')) {
      return next();
    }
    res.sendFile(path.join(frontendDistPath, 'index.html'));
  });
}

// Manejo centralizado de errores
app.use(manejadorErrores);

app.listen(PORT, '0.0.0.0', () => {
  console.log(`[Servidor Iglesia Activo] Corriendo en http://localhost:${PORT} y en http://127.0.0.1:${PORT}`);
});

module.exports = app;
