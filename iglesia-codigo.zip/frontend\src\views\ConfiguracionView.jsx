/**
 * Vista de Configuración Institucional de la Iglesia (RF-10).
 * Predominante: #fffdf5, Contorno: #7a4e2a, Blanco, Beige (#faf4ea, #f5ede1) y Amarillo Pálido #fef9c3.
 * Tipografía: Day Roman Regular (sin iconos, letras más grandes y legibles).
 */
import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { configuracionService } from '../services/api';

export default function ConfiguracionView({ onConfiguracionActualizada }) {
  const { puedeGestionarConfiguracion } = useAuth();

  const [formConfig, setFormConfig] = useState({
    nombre: '',
    lema: '',
    direccion: '',
    telefono: '',
    email: '',
    pastor_principal: '',
    logo_url: '',
    horarios: [],
  });

  const [cargando, setCargando] = useState(false);
  const [guardando, setGuardando] = useState(false);
  const [mensaje, setMensaje] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    cargarConfiguracion();
  }, []);

  async function cargarConfiguracion() {
    setCargando(true);
    setError('');
    try {
      const res = await configuracionService.obtener();
      if (res.configuracion) {
        setFormConfig({
          nombre: res.configuracion.nombre || '',
          lema: res.configuracion.lema || '',
          direccion: res.configuracion.direccion || '',
          telefono: res.configuracion.telefono || '',
          email: res.configuracion.email || '',
          pastor_principal: res.configuracion.pastor_principal || '',
          logo_url: res.configuracion.logo_url || '',
          horarios: res.configuracion.horarios || [],
        });
      }
    } catch (err) {
      setError(err.message || 'Error al cargar los datos institucionales.');
    } finally {
      setCargando(false);
    }
  }

  function handleAgregarHorario() {
    setFormConfig({
      ...formConfig,
      horarios: [
        ...formConfig.horarios,
        { dia: 'Domingo', hora: '10:00', nombre: 'Culto de Adoración y Enseñanza' },
      ],
    });
  }

  function handleActualizarHorario(index, campo, valor) {
    const nuevosHorarios = [...formConfig.horarios];
    nuevosHorarios[index][campo] = valor;
    setFormConfig({ ...formConfig, horarios: nuevosHorarios });
  }

  function handleEliminarHorario(index) {
    const nuevosHorarios = formConfig.horarios.filter((_, i) => i !== index);
    setFormConfig({ ...formConfig, horarios: nuevosHorarios });
  }

  async function handleSubmit(e) {
    if (e) e.preventDefault();
    if (!puedeGestionarConfiguracion) return;

    setGuardando(true);
    setError('');
    setMensaje('');

    try {
      const res = await configuracionService.guardar(formConfig);
      setMensaje('Información institucional y horarios actualizados con éxito.');
      if (onConfiguracionActualizada) {
        onConfiguracionActualizada(res.configuracion);
      }
    } catch (err) {
      setError(err.message || 'Error al actualizar la configuración.');
    } finally {
      setGuardando(false);
    }
  }

  if (cargando) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] space-y-3 font-serif">
        <div className="animate-spin rounded-full h-9 w-9 border-3 border-[#7a4e2a] border-t-[#fef9c3]"></div>
        <p className="text-sm text-[#7a4e2a]">Cargando configuración institucional...</p>
      </div>
    );
  }

  return (
    <div className="space-y-7 max-w-4xl mx-auto text-[#2b190a] font-serif">
      {/* Cabecera */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-3xl sm:text-4xl font-normal text-[#7a4e2a]">
            Configuración de la Iglesia
          </h2>
          <p className="text-sm text-[#58351a] mt-1 font-medium">
            Nombre institucional, logotipo, datos de contacto y horarios habituales de reuniones (RF-10)
          </p>
        </div>

        {puedeGestionarConfiguracion && (
          <button
            type="button"
            onClick={handleSubmit}
            disabled={guardando}
            className="px-5 py-3 bg-[#fef9c3] hover:bg-[#ebd8c3] text-[#7a4e2a] border-2 border-[#7a4e2a] rounded-xl text-sm font-bold shadow-xs transition-all disabled:opacity-50 self-start sm:self-auto"
          >
            {guardando ? 'Guardando...' : 'Guardar Información'}
          </button>
        )}
      </div>

      {/* Alertas */}
      {mensaje && (
        <div className="p-4 bg-[#faf4ea] border-2 border-[#7a4e2a] rounded-xl text-[#7a4e2a] text-sm font-bold">
          {mensaje}
        </div>
      )}

      {error && (
        <div className="p-4 bg-[#fff2f0] border-2 border-[#7a4e2a] rounded-xl text-[#783636] text-sm">
          {error}
        </div>
      )}

      {!puedeGestionarConfiguracion && (
        <div className="p-4 bg-[#faf4ea] border-2 border-[#7a4e2a] rounded-xl text-[#7a4e2a] text-sm font-medium">
          Modo de consulta. Los datos institucionales solo pueden ser modificados por usuarios con rol de Pastor o Administrador.
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-7">
        {/* Identidad Institucional y Emblema */}
        <div className="bg-[#fffdf5] p-7 rounded-3xl border-2 border-[#7a4e2a] shadow-xs space-y-5">
          <h3 className="text-xl font-bold text-[#7a4e2a] pb-3 border-b-2 border-[#7a4e2a]/30">
            Identidad Institucional y Emblema
          </h3>

          {/* Vista previa del emblema sobrio (inspirado en estética eclesiástica digna) */}
          <div className="p-5 bg-[#faf4ea] border-2 border-[#7a4e2a] rounded-2xl flex flex-col sm:flex-row items-center gap-5">
            <div className="w-24 h-24 rounded-2xl bg-[#fffdf5] border-2 border-[#7a4e2a] flex flex-col items-center justify-center p-2 text-center shadow-xs shrink-0">
              {formConfig.logo_url ? (
                <img src={formConfig.logo_url} alt="Logotipo de la iglesia" className="w-full h-full object-contain rounded-xl" />
              ) : (
                <div className="flex flex-col items-center justify-center">
                  <div className="w-10 h-10 rounded-full border-2 border-[#7a4e2a] flex items-center justify-center text-[#7a4e2a] font-bold text-lg mb-1">
                    {formConfig.nombre ? formConfig.nombre.charAt(0) : 'I'}
                  </div>
                  <span className="text-[9px] uppercase tracking-wider text-[#7a4e2a] font-bold">Emblema</span>
                </div>
              )}
            </div>

            <div className="space-y-1 text-center sm:text-left">
              <h4 className="text-lg font-bold text-[#7a4e2a]">
                {formConfig.nombre || 'Nombre de la Iglesia'}
              </h4>
              <p className="text-xs text-[#58351a]">
                {formConfig.lema || 'Lema o misión congregacional'}
              </p>
              <p className="text-xs text-[#7a4e2a] pt-1">
                Logotipo institucional: sobrio, digno y respetuoso. Puedes ingresar una URL de imagen o conservar el emblema distintivo oficial.
              </p>
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-[#7a4e2a] mb-1">
              Nombre Oficial de la Iglesia *
            </label>
            <input
              type="text"
              required
              disabled={!puedeGestionarConfiguracion}
              value={formConfig.nombre}
              onChange={(e) => setFormConfig({ ...formConfig, nombre: e.target.value })}
              className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30 disabled:opacity-70"
            />
          </div>

          <div>
            <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Lema o Propósito Congregacional</label>
            <input
              type="text"
              disabled={!puedeGestionarConfiguracion}
              placeholder="Una comunidad de amor, fe y servicio..."
              value={formConfig.lema}
              onChange={(e) => setFormConfig({ ...formConfig, lema: e.target.value })}
              className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30 disabled:opacity-70"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4.5">
            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Pastores Principales / Liderazgo</label>
              <input
                type="text"
                disabled={!puedeGestionarConfiguracion}
                placeholder="Pastor David Morales"
                value={formConfig.pastor_principal}
                onChange={(e) => setFormConfig({ ...formConfig, pastor_principal: e.target.value })}
                className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30 disabled:opacity-70"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Enlace del Logotipo (URL)</label>
              <input
                type="url"
                disabled={!puedeGestionarConfiguracion}
                placeholder="https://servidor.com/logotipo.png"
                value={formConfig.logo_url}
                onChange={(e) => setFormConfig({ ...formConfig, logo_url: e.target.value })}
                className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30 disabled:opacity-70"
              />
            </div>
          </div>
        </div>

        {/* Contacto y Ubicación */}
        <div className="bg-[#fffdf5] p-7 rounded-3xl border-2 border-[#7a4e2a] shadow-xs space-y-5">
          <h3 className="text-xl font-bold text-[#7a4e2a] pb-3 border-b-2 border-[#7a4e2a]/30">
            Dirección y Datos de Contacto
          </h3>

          <div>
            <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Dirección de la Sede</label>
            <input
              type="text"
              disabled={!puedeGestionarConfiguracion}
              placeholder="Calle, número, colonia, ciudad..."
              value={formConfig.direccion}
              onChange={(e) => setFormConfig({ ...formConfig, direccion: e.target.value })}
              className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30 disabled:opacity-70"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4.5">
            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Teléfono Institucional</label>
              <input
                type="tel"
                disabled={!puedeGestionarConfiguracion}
                placeholder="Número telefónico de contacto"
                value={formConfig.telefono}
                onChange={(e) => setFormConfig({ ...formConfig, telefono: e.target.value })}
                className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30 disabled:opacity-70"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Correo Electrónico Oficial</label>
              <input
                type="email"
                disabled={!puedeGestionarConfiguracion}
                placeholder="contacto@iglesia.org"
                value={formConfig.email}
                onChange={(e) => setFormConfig({ ...formConfig, email: e.target.value })}
                className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30 disabled:opacity-70"
              />
            </div>
          </div>
        </div>

        {/* Horarios Habituales de Reuniones */}
        <div className="bg-[#fffdf5] p-7 rounded-3xl border-2 border-[#7a4e2a] shadow-xs space-y-5">
          <div className="flex items-center justify-between pb-3 border-b-2 border-[#7a4e2a]/30">
            <div>
              <h3 className="text-xl font-bold text-[#7a4e2a]">Horarios Habituales de Reuniones</h3>
              <p className="text-sm text-[#58351a]">
                Cultos y actividades fijas durante la semana congregacional (RF-10)
              </p>
            </div>

            {puedeGestionarConfiguracion && (
              <button
                type="button"
                onClick={handleAgregarHorario}
                className="px-4 py-2 bg-[#fef9c3] hover:bg-[#ebd8c3] text-[#7a4e2a] border-2 border-[#7a4e2a] rounded-xl text-sm font-bold transition-colors"
              >
                Añadir Horario
              </button>
            )}
          </div>

          <div className="space-y-3.5">
            {formConfig.horarios && formConfig.horarios.length > 0 ? (
              formConfig.horarios.map((h, idx) => (
                <div
                  key={idx}
                  className="p-4 bg-[#faf4ea] rounded-2xl border-2 border-[#7a4e2a] flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5"
                >
                  <div className="w-full sm:w-1/4">
                    <label className="block text-xs uppercase font-bold text-[#7a4e2a] mb-1">Día</label>
                    <select
                      disabled={!puedeGestionarConfiguracion}
                      value={h.dia}
                      onChange={(e) => handleActualizarHorario(idx, 'dia', e.target.value)}
                      className="w-full px-3 py-2 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-lg text-sm"
                    >
                      <option value="Domingo">Domingo</option>
                      <option value="Lunes">Lunes</option>
                      <option value="Martes">Martes</option>
                      <option value="Miércoles">Miércoles</option>
                      <option value="Jueves">Jueves</option>
                      <option value="Viernes">Viernes</option>
                      <option value="Sábado">Sábado</option>
                    </select>
                  </div>

                  <div className="w-full sm:w-1/4">
                    <label className="block text-xs uppercase font-bold text-[#7a4e2a] mb-1">Hora</label>
                    <input
                      type="time"
                      disabled={!puedeGestionarConfiguracion}
                      value={h.hora}
                      onChange={(e) => handleActualizarHorario(idx, 'hora', e.target.value)}
                      className="w-full px-3 py-2 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-lg text-sm"
                    />
                  </div>

                  <div className="flex-1">
                    <label className="block text-xs uppercase font-bold text-[#7a4e2a] mb-1">Nombre de la Reunión</label>
                    <input
                      type="text"
                      disabled={!puedeGestionarConfiguracion}
                      placeholder="Culto de Adoración y Enseñanza"
                      value={h.nombre}
                      onChange={(e) => handleActualizarHorario(idx, 'nombre', e.target.value)}
                      className="w-full px-3 py-2 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-lg text-sm"
                    />
                  </div>

                  {puedeGestionarConfiguracion && (
                    <button
                      type="button"
                      onClick={() => handleEliminarHorario(idx)}
                      className="self-end sm:self-center text-sm text-[#7a4e2a] hover:text-[#783636] underline pt-3 sm:pt-4 font-bold"
                    >
                      Eliminar
                    </button>
                  )}
                </div>
              ))
            ) : (
              <p className="text-center py-6 text-sm text-[#7a4e2a]">
                No hay horarios habituales registrados.
              </p>
            )}
          </div>
        </div>

        {puedeGestionarConfiguracion && (
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={guardando}
              className="px-7 py-3 bg-[#fef9c3] hover:bg-[#ebd8c3] text-[#7a4e2a] border-2 border-[#7a4e2a] rounded-xl text-base font-bold transition-all disabled:opacity-50"
            >
              {guardando ? 'Guardando...' : 'Guardar Información'}
            </button>
          </div>
        )}
      </form>
    </div>
  );
}
