const { execSync } = require('child_process');
const path = require('path');

// En npm v11+, npm run propaga npm_config_allow_scripts al entorno de los subprocesos,
// lo que causa el error EALLOWSCRIPTS al invocar 'npm install' dentro de un script de npm.
// Al eliminarla antes de llamar a npm, la instalación se ejecuta sin restricciones indebidas.
delete process.env.npm_config_allow_scripts;

const rootDir = path.resolve(__dirname, '..');

function run(cmd, cwd) {
  console.log(`\n> ${cmd} (en ${path.relative(rootDir, cwd || rootDir) || 'raíz'})`);
  execSync(cmd, { cwd: cwd || rootDir, stdio: 'inherit', env: process.env });
}

try {
  console.log('📦 [1/3] Instalando dependencias raíz (concurrently)...');
  run('npm install');

  console.log('📦 [2/3] Instalando dependencias del Backend (express, sqlite, etc.)...');
  run('npm install', path.join(rootDir, 'backend'));

  console.log('📦 [3/3] Instalando dependencias del Frontend (react, vite, tailwind, etc.)...');
  run('npm install', path.join(rootDir, 'frontend'));

  console.log('\n✅ ¡Todas las dependencias instaladas correctamente!');
} catch (error) {
  console.error('\n❌ Error durante la instalación:', error.message);
  process.exit(1);
}
