/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Day Roman"', '"Day Roman Regular"', 'Georgia', 'serif'],
        serif: ['"Day Roman"', '"Day Roman Regular"', 'Georgia', 'serif'],
        roman: ['"Day Roman"', '"Day Roman Regular"', 'Georgia', 'serif'],
      },
      colors: {
        // Color predominante
        predominant: '#fffdf5',
        // Color de contorno café noble
        contour: '#7a4e2a',
        // Amarillo pálido sutil
        paleYellow: {
          50: '#fefce8',
          100: '#fef9c3',
          200: '#fef08a',
          DEFAULT: '#fef9c3',
        },
        // Tonos beige suaves
        beige: {
          50: '#faf7f2',
          100: '#f5ede1',
          200: '#ebd8c3',
          300: '#dcc1a3',
          DEFAULT: '#f5ede1',
        },
        // Tonos café eclesiásticos
        coffee: {
          400: '#8c5d35',
          500: '#7a4e2a',
          600: '#684122',
          700: '#56351b',
          800: '#422813',
          900: '#2b190a',
          DEFAULT: '#7a4e2a',
        },
        // Escala compatible brand
        brand: {
          50: '#fffdf5',
          100: '#faf4ea',
          200: '#ebd8c3',
          300: '#d6b38f',
          400: '#ad7e54',
          500: '#7a4e2a',
          600: '#684122',
          700: '#56351b',
          800: '#422813',
          900: '#2b190a',
        },
        church: {
          50: '#fffdf5',
          100: '#faf4ea',
          200: '#ebd8c3',
          500: '#7a4e2a',
          pale: '#fef9c3',
        }
      }
    },
  },
  plugins: [],
}
