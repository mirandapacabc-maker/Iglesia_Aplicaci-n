/**
 * Controlador de Publicación de Anuncios y Comunicados Institucionales (RF-07).
 * Permite publicar, editar, destacar y eliminar avisos dirigidos a la congregación.
 */
const db = require('../config/database');

/**
 * Listado de anuncios vigentes con soporte de filtro por destacados y categoría.
 */
function listarAnuncios(req, res, next) {
  try {
    const { soloDestacados, categoria } = req.query;

    let condiciones = [];
    let parametros = [];

    if (soloDestacados === 'true' || soloDestacados === '1') {
      condiciones.push('a.destacado = 1');
    }
    if (categoria) {
      condiciones.push('a.categoria = ?');
      parametros.push(categoria);
    }

    const whereClause = condiciones.length > 0 ? `WHERE ${condiciones.join(' AND ')}` : '';

    const query = `
      SELECT 
        a.id, a.titulo, a.contenido, a.categoria, a.destacado, a.fecha_publicacion, a.creado_en,
        u.nombre AS autor_nombre,
        u.rol AS autor_rol
      FROM anuncios a
      LEFT JOIN usuarios u ON a.autor_id = u.id
      ${whereClause}
      ORDER BY a.destacado DESC, a.fecha_publicacion DESC
    `;

    const anuncios = db.prepare(query).all(...parametros);
    return res.json({ anuncios });
  } catch (error) {
    next(error);
  }
}

/**
 * Crear un nuevo comunicado institucional.
 */
function crearAnuncio(req, res, next) {
  try {
    const { titulo, contenido, categoria, destacado } = req.body;

    if (!titulo || !contenido) {
      return res.status(400).json({ mensaje: 'Título y contenido del anuncio son obligatorios.' });
    }

    const resultado = db.prepare(`
      INSERT INTO anuncios (titulo, contenido, categoria, destacado, autor_id, fecha_publicacion)
      VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    `).run(
      titulo.trim(),
      contenido.trim(),
      categoria ? categoria.trim() : 'General',
      destacado ? 1 : 0,
      req.usuario.id
    );

    const nuevoAnuncio = db.prepare(`
      SELECT a.*, u.nombre AS autor_nombre
      FROM anuncios a
      LEFT JOIN usuarios u ON a.autor_id = u.id
      WHERE a.id = ?
    `).get(resultado.lastInsertRowid);

    return res.status(201).json({
      mensaje: 'Anuncio publicado exitosamente.',
      anuncio: nuevoAnuncio
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Editar un anuncio existente.
 */
function actualizarAnuncio(req, res, next) {
  try {
    const { id } = req.params;
    const { titulo, contenido, categoria, destacado } = req.body;

    const anuncio = db.prepare('SELECT id FROM anuncios WHERE id = ?').get(id);
    if (!anuncio) {
      return res.status(404).json({ mensaje: 'Anuncio no encontrado.' });
    }

    db.prepare(`
      UPDATE anuncios
      SET titulo = ?, contenido = ?, categoria = ?, destacado = ?
      WHERE id = ?
    `).run(
      titulo.trim(),
      contenido.trim(),
      categoria ? categoria.trim() : 'General',
      destacado ? 1 : 0,
      id
    );

    const anuncioActualizado = db.prepare('SELECT * FROM anuncios WHERE id = ?').get(id);

    return res.json({
      mensaje: 'Anuncio modificado correctamente.',
      anuncio: anuncioActualizado
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Eliminar un comunicado institucional.
 */
function eliminarAnuncio(req, res, next) {
  try {
    const { id } = req.params;

    const anuncio = db.prepare('SELECT id FROM anuncios WHERE id = ?').get(id);
    if (!anuncio) {
      return res.status(404).json({ mensaje: 'Anuncio no encontrado.' });
    }

    db.prepare('DELETE FROM anuncios WHERE id = ?').run(id);

    return res.json({ mensaje: 'Anuncio eliminado correctamente.' });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  listarAnuncios,
  crearAnuncio,
  actualizarAnuncio,
  eliminarAnuncio
};
