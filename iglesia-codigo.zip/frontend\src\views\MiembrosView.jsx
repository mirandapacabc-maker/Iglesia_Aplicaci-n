/**
 * Vista de Gestión de Miembros de la Iglesia (RF-02).
 * Predominante: #fffdf5, Contorno: #7a4e2a, Blanco, Beige (#faf4ea, #f5ede1) y Amarillo Pálido #fef9c3.
 * Tipografía: Day Roman Regular (sin iconos, letras más grandes y legibles).
 */
import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { miembrosService } from '../services/api';
import Modal from '../components/Modal';

export default function MiembrosView() {
  const { puedeGestionarMiembros } = useAuth();

  const [miembros, setMiembros] = useState([]);
  const [paginacion, setPaginacion] = useState({ pagina: 1, totalPaginas: 1, total: 0 });
  const [busqueda, setBusqueda] = useState('');
  const [filtroEstado, setFiltroEstado] = useState('activos');
  const [cargando, setCargando] = useState(false);
  const [mensaje, setMensaje] = useState('');
  const [error, setError] = useState('');

  // Estados del modal
  const [modalAbierto, setModalAbierto] = useState(false);
  const [miembroEnEdicion, setMiembroEnEdicion] = useState(null);
  const [guardando, setGuardando] = useState(false);

  // Formulario (RF-02: nombre, teléfono, correo, fecha de ingreso)
  const [formMiembro, setFormMiembro] = useState({
    nombre: '',
    telefono: '',
    email: '',
    direccion: '',
    fecha_ingreso: new Date().toISOString().split('T')[0],
    fecha_nacimiento: '',
    notas: '',
  });

  useEffect(() => {
    cargarMiembros(1);
  }, [filtroEstado]);

  useEffect(() => {
    const timer = setTimeout(() => {
      cargarMiembros(1);
    }, 300);
    return () => clearTimeout(timer);
  }, [busqueda]);

  async function cargarMiembros(pagina = 1) {
    setCargando(true);
    setError('');
    try {
      const res = await miembrosService.listar({
        pagina,
        limite: 10,
        busqueda,
        estado: filtroEstado,
      });
      setMiembros(res.miembros);
      setPaginacion({
        pagina: res.pagina,
        totalPaginas: res.totalPaginas,
        total: res.total,
      });
    } catch (err) {
      setError(err.message || 'Error al consultar el directorio de miembros.');
    } finally {
      setCargando(false);
    }
  }

  function abrirModalNuevo() {
    setMiembroEnEdicion(null);
    setFormMiembro({
      nombre: '',
      telefono: '',
      email: '',
      direccion: '',
      fecha_ingreso: new Date().toISOString().split('T')[0],
      fecha_nacimiento: '',
      notas: '',
    });
    setModalAbierto(true);
  }

  function abrirModalEditar(miembro) {
    setMiembroEnEdicion(miembro);
    setFormMiembro({
      nombre: miembro.nombre,
      telefono: miembro.telefono || '',
      email: miembro.email || '',
      direccion: miembro.direccion || '',
      fecha_ingreso: miembro.fecha_ingreso || new Date().toISOString().split('T')[0],
      fecha_nacimiento: miembro.fecha_nacimiento || '',
      notas: miembro.notas || '',
    });
    setModalAbierto(true);
  }

  async function handleGuardarMiembro(e) {
    e.preventDefault();
    setGuardando(true);
    setError('');
    setMensaje('');

    try {
      if (miembroEnEdicion) {
        await miembrosService.actualizar(miembroEnEdicion.id, formMiembro);
        setMensaje('Información del miembro actualizada correctamente.');
      } else {
        await miembrosService.crear(formMiembro);
        setMensaje('Nuevo miembro registrado con éxito.');
      }
      setModalAbierto(false);
      cargarMiembros(paginacion.pagina);
    } catch (err) {
      setError(err.message || 'Error al guardar el registro.');
    } finally {
      setGuardando(false);
    }
  }

  async function handleAlternarEstado(miembro) {
    const accion = miembro.activo ? 'desactivar del registro activo' : 'reactivar en el registro';
    if (!window.confirm(`¿Desea ${accion} a ${miembro.nombre}?`)) return;

    try {
      await miembrosService.alternarEstado(miembro.id, !miembro.activo);
      setMensaje(`Estado de ${miembro.nombre} actualizado correctamente.`);
      cargarMiembros(paginacion.pagina);
    } catch (err) {
      setError(err.message || 'Error al actualizar estado del miembro.');
    }
  }

  return (
    <div className="space-y-7 text-[#2b190a] font-serif">
      {/* Cabecera con título y botón nuevo */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-3xl sm:text-4xl font-normal text-[#7a4e2a]">
            Directorio de Miembros
          </h2>
          <p className="text-sm text-[#58351a] mt-1 font-medium">
            Registro, consulta y administración de los miembros de la iglesia
          </p>
        </div>

        {puedeGestionarMiembros && (
          <button
            onClick={abrirModalNuevo}
            className="px-5 py-3 bg-[#fef9c3] hover:bg-[#ebd8c3] text-[#7a4e2a] border-2 border-[#7a4e2a] rounded-xl text-sm font-bold shadow-xs transition-all self-start sm:self-auto"
          >
            Registrar Nuevo Miembro
          </button>
        )}
      </div>

      {/* Alertas */}
      {mensaje && (
        <div className="p-4 bg-[#faf4ea] border-2 border-[#7a4e2a] rounded-xl text-[#7a4e2a] text-sm font-bold">
          {mensaje}
        </div>
      )}

      {error && (
        <div className="p-4 bg-[#fff2f0] border-2 border-[#7a4e2a] rounded-xl text-[#783636] text-sm">
          {error}
        </div>
      )}

      {/* Barra de filtros y buscador (RF-02) */}
      <div className="bg-[#fffdf5] p-5 rounded-2xl border-2 border-[#7a4e2a] shadow-xs flex flex-col md:flex-row gap-4 items-stretch md:items-center justify-between">
        {/* Buscador */}
        <div className="flex-1">
          <input
            type="text"
            placeholder="Buscar por nombre, teléfono o correo..."
            value={busqueda}
            onChange={(e) => setBusqueda(e.target.value)}
            className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base text-[#2b190a] focus:outline-none focus:bg-[#fef9c3]/30"
          />
        </div>

        {/* Filtro de estado activo/inactivo */}
        <div className="flex bg-[#faf4ea] p-1.5 rounded-xl text-sm border-2 border-[#7a4e2a] shrink-0">
          <button
            onClick={() => setFiltroEstado('activos')}
            className={`px-4 py-2 rounded-lg transition-all font-semibold ${
              filtroEstado === 'activos' ? 'bg-[#fef9c3] text-[#7a4e2a] border border-[#7a4e2a] shadow-xs' : 'text-[#58351a] hover:text-[#7a4e2a]'
            }`}
          >
            Activos
          </button>
          <button
            onClick={() => setFiltroEstado('inactivos')}
            className={`px-4 py-2 rounded-lg transition-all font-semibold ${
              filtroEstado === 'inactivos' ? 'bg-[#fef9c3] text-[#7a4e2a] border border-[#7a4e2a] shadow-xs' : 'text-[#58351a] hover:text-[#7a4e2a]'
            }`}
          >
            Inactivos
          </button>
          <button
            onClick={() => setFiltroEstado('todos')}
            className={`px-4 py-2 rounded-lg transition-all font-semibold ${
              filtroEstado === 'todos' ? 'bg-[#fef9c3] text-[#7a4e2a] border border-[#7a4e2a] shadow-xs' : 'text-[#58351a] hover:text-[#7a4e2a]'
            }`}
          >
            Todos
          </button>
        </div>
      </div>

      {/* Lista / Tabla de Miembros */}
      <div className="bg-[#fffdf5] rounded-3xl border-2 border-[#7a4e2a] shadow-xs overflow-hidden">
        {cargando ? (
          <div className="p-12 text-center text-sm text-[#7a4e2a] flex flex-col items-center justify-center space-y-3">
            <div className="animate-spin rounded-full h-8 w-8 border-3 border-[#7a4e2a] border-t-[#fef9c3]"></div>
            <span>Consultando el directorio de miembros...</span>
          </div>
        ) : miembros.length === 0 ? (
          <div className="p-12 text-center text-sm text-[#7a4e2a]">
            No se encontraron miembros con los criterios seleccionados.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[#faf4ea] border-b-2 border-[#7a4e2a] text-xs font-bold text-[#7a4e2a] uppercase tracking-wider">
                  <th className="py-4 px-4 sm:px-6">Miembro</th>
                  <th className="py-4 px-4">Contacto</th>
                  <th className="py-4 px-4">Fecha de Ingreso</th>
                  <th className="py-4 px-4">Estado</th>
                  <th className="py-4 px-4 sm:px-6 text-right">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y border-t border-[#7a4e2a]/30 text-sm">
                {miembros.map((m) => (
                  <tr key={m.id} className="hover:bg-[#faf4ea]/60 transition-colors">
                    <td className="py-4 px-4 sm:px-6">
                      <div className="flex items-center space-x-3.5">
                        <div className="w-9 h-9 rounded-full bg-[#fef9c3] border-2 border-[#7a4e2a] text-[#7a4e2a] font-bold flex items-center justify-center shrink-0 text-sm">
                          {m.nombre.substring(0, 2).toUpperCase()}
                        </div>
                        <div>
                          <p className="font-bold text-base text-[#7a4e2a]">{m.nombre}</p>
                          {m.direccion && <p className="text-xs text-[#58351a]">{m.direccion}</p>}
                        </div>
                      </div>
                    </td>

                    <td className="py-4 px-4">
                      <div className="space-y-0.5 text-xs text-[#58351a]">
                        {m.telefono && <div>Tel: <span className="font-semibold">{m.telefono}</span></div>}
                        {m.email && <div>{m.email}</div>}
                        {!m.telefono && !m.email && <span className="text-[#7a4e2a]/60">Sin datos de contacto</span>}
                      </div>
                    </td>

                    <td className="py-4 px-4 text-sm text-[#58351a]">
                      {m.fecha_ingreso}
                    </td>

                    <td className="py-4 px-4">
                      <span
                        className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-bold border-2 ${
                          m.activo
                            ? 'bg-[#fef9c3] text-[#7a4e2a] border-[#7a4e2a]'
                            : 'bg-[#faf4ea] text-[#7a4e2a]/70 border-[#7a4e2a]/40'
                        }`}
                      >
                        {m.activo ? 'Activo' : 'Inactivo'}
                      </span>
                    </td>

                    <td className="py-4 px-4 sm:px-6 text-right">
                      {puedeGestionarMiembros ? (
                        <div className="flex items-center justify-end space-x-4 text-sm">
                          <button
                            onClick={() => abrirModalEditar(m)}
                            className="text-[#7a4e2a] hover:text-[#2b190a] font-bold underline"
                          >
                            Editar
                          </button>

                          <button
                            onClick={() => handleAlternarEstado(m)}
                            className="text-[#7a4e2a] hover:text-[#783636] font-medium"
                          >
                            {m.activo ? 'Desactivar' : 'Activar'}
                          </button>
                        </div>
                      ) : (
                        <span className="text-xs text-[#7a4e2a]/60">Solo lectura</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Paginación */}
        {paginacion.totalPaginas > 1 && (
          <div className="p-4 border-t-2 border-[#7a4e2a] flex items-center justify-between text-sm text-[#58351a] bg-[#faf4ea]">
            <span>
              Página {paginacion.pagina} de {paginacion.totalPaginas} ({paginacion.total} miembros registrados)
            </span>
            <div className="flex space-x-2.5">
              <button
                disabled={paginacion.pagina <= 1}
                onClick={() => cargarMiembros(paginacion.pagina - 1)}
                className="px-4 py-1.5 rounded-lg border-2 border-[#7a4e2a] bg-[#fffdf5] hover:bg-[#fef9c3] disabled:opacity-40 font-bold text-[#7a4e2a]"
              >
                « Anterior
              </button>
              <button
                disabled={paginacion.pagina >= paginacion.totalPaginas}
                onClick={() => cargarMiembros(paginacion.pagina + 1)}
                className="px-4 py-1.5 rounded-lg border-2 border-[#7a4e2a] bg-[#fffdf5] hover:bg-[#fef9c3] disabled:opacity-40 font-bold text-[#7a4e2a]"
              >
                Siguiente »
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Modal de Registro y Edición (RF-02) */}
      <Modal
        isOpen={modalAbierto}
        onClose={() => setModalAbierto(false)}
        titulo={miembroEnEdicion ? 'Editar Información del Miembro' : 'Registrar Nuevo Miembro'}
      >
        <form onSubmit={handleGuardarMiembro} className="space-y-4 text-[#2b190a]">
          <div>
            <label className="block text-sm font-bold text-[#7a4e2a] mb-1">
              Nombre Completo *
            </label>
            <input
              type="text"
              required
              placeholder="Nombre y apellido"
              value={formMiembro.nombre}
              onChange={(e) => setFormMiembro({ ...formMiembro, nombre: e.target.value })}
              className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Teléfono</label>
              <input
                type="tel"
                placeholder="Número de teléfono"
                value={formMiembro.telefono}
                onChange={(e) => setFormMiembro({ ...formMiembro, telefono: e.target.value })}
                className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Correo Electrónico</label>
              <input
                type="email"
                placeholder="correo@ejemplo.com"
                value={formMiembro.email}
                onChange={(e) => setFormMiembro({ ...formMiembro, email: e.target.value })}
                className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Fecha de Ingreso *</label>
              <input
                type="date"
                required
                value={formMiembro.fecha_ingreso}
                onChange={(e) => setFormMiembro({ ...formMiembro, fecha_ingreso: e.target.value })}
                className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Fecha de Nacimiento</label>
              <input
                type="date"
                value={formMiembro.fecha_nacimiento}
                onChange={(e) => setFormMiembro({ ...formMiembro, fecha_nacimiento: e.target.value })}
                className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Dirección</label>
            <input
              type="text"
              placeholder="Calle, número, colonia"
              value={formMiembro.direccion}
              onChange={(e) => setFormMiembro({ ...formMiembro, direccion: e.target.value })}
              className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
            />
          </div>

          <div>
            <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Notas y Observaciones</label>
            <textarea
              rows={3}
              placeholder="Anotaciones de seguimiento o bautismo..."
              value={formMiembro.notas}
              onChange={(e) => setFormMiembro({ ...formMiembro, notas: e.target.value })}
              className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
            ></textarea>
          </div>

          <div className="flex justify-end space-x-3 pt-4 border-t-2 border-[#7a4e2a]">
            <button
              type="button"
              onClick={() => setModalAbierto(false)}
              className="px-5 py-2.5 border-2 border-[#7a4e2a] rounded-xl text-sm text-[#7a4e2a] hover:bg-[#faf4ea] font-bold"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={guardando}
              className="px-6 py-2.5 bg-[#fef9c3] hover:bg-[#ebd8c3] text-[#7a4e2a] border-2 border-[#7a4e2a] rounded-xl text-sm font-bold transition-all disabled:opacity-50"
            >
              {guardando ? 'Guardando...' : 'Guardar Información'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
