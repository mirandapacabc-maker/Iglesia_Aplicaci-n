/**
 * Componente de Disposición General (Layout) Eclesiástico.
 * Colores: Predominante #fffdf5, Contorno #7a4e2a, Blanco, Beige y Amarillo Pálido #fef9c3.
 * Tipografía: Day Roman Regular (letras más grandes y legibles, sin iconos).
 */
import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';

export default function Layout({ vistaActual, setVistaActual, configIglesia, children }) {
  const { usuario, logout, puedeVerFinanzas } = useAuth();
  const [menuMovilAbierto, setMenuMovilAbierto] = useState(false);

  // Lista de secciones del sistema (RF-01 a RF-10)
  const modulos = [
    { id: 'dashboard', label: 'Inicio y Métricas' },
    { id: 'miembros', label: 'Gestión de Miembros' },
    { id: 'asistencia', label: 'Control de Asistencia' },
    { id: 'eventos', label: 'Agenda y Eventos' },
    { id: 'ministerios', label: 'Ministerios y Grupos' },
    ...(puedeVerFinanzas ? [{ id: 'donaciones', label: 'Aportaciones y Donaciones' }] : []),
    { id: 'anuncios', label: 'Avisos y Comunicados' },
    { id: 'reportes', label: 'Libros y Reportes' },
    { id: 'configuracion', label: 'Configuración Institucional' },
  ];

  // Distintivo eclesiástico en beige cálido con borde café
  const badgeRol = 'bg-[#f5ede1] text-[#7a4e2a] font-semibold border border-[#7a4e2a]/50';

  function navegarA(id) {
    setVistaActual(id);
    setMenuMovilAbierto(false);
  }

  const nombreIglesia = configIglesia?.nombre || 'Comunidad Cristiana';

  return (
    <div className="min-h-screen bg-[#fffdf5] text-[#2b190a] font-serif flex flex-col md:flex-row">
      {/* 1. BARRA LATERAL PARA ESCRITORIO */}
      <aside className="hidden md:flex flex-col w-72 bg-[#fffdf5] border-r-2 border-[#7a4e2a] shrink-0 shadow-sm">
        {/* Identidad institucional */}
        <div className="p-6 border-b-2 border-[#7a4e2a] bg-[#faf4ea]">
          <div className="flex items-center space-x-3.5">
            <div className="w-12 h-12 rounded-full bg-[#fef9c3] border-2 border-[#7a4e2a] flex items-center justify-center text-[#7a4e2a] font-bold text-xl shrink-0 shadow-xs">
              {configIglesia?.logo_url ? (
                <img src={configIglesia.logo_url} alt="Logo" className="w-full h-full object-cover rounded-full" />
              ) : (
                <span>{nombreIglesia.charAt(0)}</span>
              )}
            </div>
            <div className="truncate">
              <h1 className="font-bold text-lg text-[#7a4e2a] leading-tight truncate" title={nombreIglesia}>
                {nombreIglesia}
              </h1>
              <p className="text-sm text-[#7a4e2a] tracking-wide mt-0.5 font-medium">
                Gestión Eclesiástica
              </p>
            </div>
          </div>
        </div>

        {/* Menú de navegación */}
        <nav className="flex-1 px-4 py-6 space-y-2 overflow-y-auto">
          <p className="px-3 pb-2 text-xs uppercase tracking-wider text-[#7a4e2a] font-bold">
            Módulos del Sistema
          </p>
          {modulos.map((m) => {
            const activo = vistaActual === m.id;
            return (
              <button
                key={m.id}
                onClick={() => navegarA(m.id)}
                className={`w-full text-left px-4 py-3 rounded-xl text-base transition-all duration-150 flex items-center justify-between border ${
                  activo
                    ? 'bg-[#fef9c3] text-[#7a4e2a] font-bold border-[#7a4e2a] shadow-xs'
                    : 'text-[#58351a] border-transparent hover:text-[#7a4e2a] hover:bg-[#f5ede1] hover:border-[#7a4e2a]/40'
                }`}
              >
                <span>{m.label}</span>
                {activo && (
                  <span className="w-2.5 h-2.5 rounded-full bg-[#7a4e2a]"></span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Perfil del servidor y salida */}
        <div className="p-5 border-t-2 border-[#7a4e2a] bg-[#faf4ea] space-y-3.5">
          <div className="flex items-center space-x-3.5">
            <div className="w-10 h-10 rounded-full bg-[#7a4e2a] text-[#fffdf5] border border-[#7a4e2a] flex items-center justify-center font-bold text-sm uppercase shadow-xs">
              {usuario?.nombre?.substring(0, 2) || 'US'}
            </div>
            <div className="flex-1 truncate">
              <p className="text-sm font-bold text-[#7a4e2a] truncate">{usuario?.nombre}</p>
              <span className={`inline-block text-xs px-2.5 py-0.5 rounded-full ${badgeRol}`}>
                {usuario?.rol}
              </span>
            </div>
          </div>

          <button
            onClick={logout}
            className="w-full text-center py-2.5 text-sm font-semibold text-[#7a4e2a] hover:text-[#2b190a] hover:bg-[#ebd8c3] rounded-lg transition-colors border-2 border-[#7a4e2a] bg-[#fffdf5]"
          >
            Cerrar Sesión
          </button>
        </div>
      </aside>

      {/* 2. BARRA SUPERIOR PARA DISPOSITIVOS MÓVILES */}
      <header className="md:hidden bg-[#fffdf5] border-b-2 border-[#7a4e2a] px-4 py-3.5 flex items-center justify-between sticky top-0 z-30 shadow-xs">
        <div className="truncate">
          <h2 className="font-bold text-base text-[#7a4e2a] truncate">{nombreIglesia}</h2>
          <span className="text-sm text-[#7a4e2a]">{usuario?.nombre} • {usuario?.rol}</span>
        </div>

        <button
          onClick={() => setMenuMovilAbierto(!menuMovilAbierto)}
          className="px-3.5 py-1.5 text-sm font-bold border-2 border-[#7a4e2a] bg-[#fef9c3] text-[#7a4e2a] rounded-md shadow-xs"
        >
          {menuMovilAbierto ? 'Cerrar' : 'Menú'}
        </button>
      </header>

      {/* Menú desplegable móvil */}
      {menuMovilAbierto && (
        <div className="md:hidden fixed inset-0 z-40 bg-[#2b190a]/40 backdrop-blur-xs flex flex-col">
          <div className="bg-[#fffdf5] p-6 rounded-b-2xl shadow-xl space-y-3.5 border-b-2 border-[#7a4e2a]">
            <div className="flex items-center justify-between pb-3 border-b-2 border-[#7a4e2a]">
              <div>
                <p className="font-bold text-base text-[#7a4e2a]">{usuario?.nombre}</p>
                <p className="text-sm text-[#58351a]">{usuario?.rol}</p>
              </div>
              <button
                onClick={() => setMenuMovilAbierto(false)}
                className="px-3 py-1 text-sm text-[#7a4e2a] border-2 border-[#7a4e2a] rounded-md bg-[#faf4ea]"
              >
                Cerrar
              </button>
            </div>

            <div className="grid grid-cols-1 gap-2 max-h-[60vh] overflow-y-auto py-2">
              {modulos.map((m) => {
                const activo = vistaActual === m.id;
                return (
                  <button
                    key={m.id}
                    onClick={() => navegarA(m.id)}
                    className={`w-full text-left p-3 rounded-lg text-sm font-medium border ${
                      activo
                        ? 'bg-[#fef9c3] text-[#7a4e2a] font-bold border-[#7a4e2a]'
                        : 'text-[#58351a] border-transparent hover:bg-[#f5ede1]'
                    }`}
                  >
                    {m.label}
                  </button>
                );
              })}
            </div>

            <button
              onClick={logout}
              className="w-full mt-3 py-2.5 text-sm font-semibold text-[#7a4e2a] bg-[#f5ede1] hover:bg-[#ebd8c3] border-2 border-[#7a4e2a] rounded-lg"
            >
              Cerrar sesión
            </button>
          </div>
          <div className="flex-1" onClick={() => setMenuMovilAbierto(false)}></div>
        </div>
      )}

      {/* 3. CONTENEDOR PRINCIPAL */}
      <main className="flex-1 flex flex-col min-w-0 pb-20 md:pb-8 bg-[#fffdf5]">
        <div className="p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {children}
        </div>
      </main>

      {/* 4. BARRA DE NAVEGACIÓN INFERIOR PARA MÓVIL */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-[#fffdf5] border-t-2 border-[#7a4e2a] px-2 py-2.5 flex justify-around items-center z-30 shadow-lg">
        {modulos.slice(0, 5).map((m) => {
          const activo = vistaActual === m.id;
          return (
            <button
              key={m.id}
              onClick={() => navegarA(m.id)}
              className={`flex flex-col items-center py-1.5 px-2 text-center transition-colors ${
                activo
                  ? 'text-[#7a4e2a] font-bold border-b-2 border-[#7a4e2a] bg-[#fef9c3] rounded-t-md'
                  : 'text-[#7a4e2a]/80 hover:text-[#7a4e2a]'
              }`}
            >
              <span className="text-xs font-semibold tracking-tight">{m.label.split(' ')[0]}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}
