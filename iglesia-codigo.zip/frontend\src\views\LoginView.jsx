/**
 * Vista de Inicio de Sesión y Registro Institucional (RF-01).
 * Predominante: #fffdf5, Contorno: #7a4e2a, Blanco, Beige (#faf4ea, #f5ede1) y Amarillo Pálido #fef9c3.
 * Tipografía: Day Roman Regular (sin iconos, letras más grandes y legibles).
 */
import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';

export default function LoginView({ onIrRecuperarPassword }) {
  const { login, registro } = useAuth();

  const [esRegistro, setEsRegistro] = useState(false);
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState('');
  const [exito, setExito] = useState('');

  // Formulario de login
  const [credenciales, setCredenciales] = useState({
    email: '',
    password: '',
  });

  // Formulario de registro
  const [datosRegistro, setDatosRegistro] = useState({
    nombre: '',
    email: '',
    password: '',
    telefono: '',
    rol: 'Coordinador',
  });

  async function handleSubmitLogin(e) {
    e.preventDefault();
    setError('');
    setCargando(true);

    try {
      await login(credenciales.email, credenciales.password);
    } catch (err) {
      setError(err.message || 'Error al iniciar sesión. Verifique sus credenciales.');
    } finally {
      setCargando(false);
    }
  }

  async function handleSubmitRegistro(e) {
    e.preventDefault();
    setError('');
    setExito('');
    setCargando(true);

    try {
      await registro(datosRegistro);
      setExito(`Registro completado con éxito para ${datosRegistro.email}.`);
      setCredenciales({ email: datosRegistro.email, password: datosRegistro.password });
      
      setTimeout(async () => {
        try {
          await login(datosRegistro.email, datosRegistro.password);
        } catch {
          setEsRegistro(false);
          setExito(`Usuario registrado. Ya puede ingresar con ${datosRegistro.email}.`);
        }
      }, 700);
    } catch (err) {
      setError(err.message || 'No fue posible registrar al usuario.');
      setCargando(false);
    }
  }

  function atajoLogin(email, pass = 'Iglesia2026*') {
    setCredenciales({ email, password: pass });
  }

  return (
    <div className="min-h-screen bg-[#fffdf5] flex items-center justify-center p-4 sm:p-6 text-[#2b190a] font-serif">
      <div className="w-full max-w-lg bg-[#fffdf5] rounded-3xl shadow-xl p-6 sm:p-9 border-2 border-[#7a4e2a]">
        {/* Cabecera institucional sobria y digna */}
        <div className="text-center space-y-1.5 mb-8">
          <div className="w-14 h-14 mx-auto rounded-full bg-[#fef9c3] border-2 border-[#7a4e2a] flex items-center justify-center text-[#7a4e2a] font-bold text-2xl mb-3 shadow-xs">
            C
          </div>
          <h1 className="text-3xl sm:text-4xl text-[#7a4e2a] tracking-wide font-normal">
            Comunidad de Fe
          </h1>
          <p className="text-sm text-[#58351a] font-medium">
            Sistema de Gestión y Administración Eclesiástica
          </p>
        </div>

        {/* Mensajes de retroalimentación */}
        {error && (
          <div className="mb-5 p-4 rounded-xl bg-[#fff2f0] border-2 border-[#7a4e2a] text-[#783636] text-sm">
            {error}
          </div>
        )}

        {exito && (
          <div className="mb-5 p-4 rounded-xl bg-[#f5ede1] border-2 border-[#7a4e2a] text-[#7a4e2a] text-sm font-bold">
            {exito}
          </div>
        )}

        {/* Pestañas Iniciar Sesión / Registrarse */}
        <div className="flex bg-[#faf4ea] p-1.5 rounded-xl mb-6 text-sm border-2 border-[#7a4e2a]">
          <button
            type="button"
            onClick={() => { setEsRegistro(false); setError(''); }}
            className={`flex-1 py-2.5 rounded-lg transition-all font-semibold ${
              !esRegistro ? 'bg-[#fef9c3] text-[#7a4e2a] border border-[#7a4e2a] shadow-xs' : 'text-[#58351a] hover:text-[#7a4e2a]'
            }`}
          >
            Iniciar Sesión
          </button>
          <button
            type="button"
            onClick={() => { setEsRegistro(true); setError(''); }}
            className={`flex-1 py-2.5 rounded-lg transition-all font-semibold ${
              esRegistro ? 'bg-[#fef9c3] text-[#7a4e2a] border border-[#7a4e2a] shadow-xs' : 'text-[#58351a] hover:text-[#7a4e2a]'
            }`}
          >
            Nuevo Registro
          </button>
        </div>

        {!esRegistro ? (
          /* FORMULARIO LOGIN */
          <form onSubmit={handleSubmitLogin} className="space-y-5">
            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1.5">
                Correo Electrónico
              </label>
              <input
                type="email"
                required
                placeholder="usuario@iglesia.org"
                value={credenciales.email}
                onChange={(e) => setCredenciales({ ...credenciales, email: e.target.value })}
                className="w-full px-4 py-3 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base text-[#2b190a] focus:outline-none focus:bg-[#fef9c3]/30 transition-colors"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-sm font-bold text-[#7a4e2a]">
                  Contraseña
                </label>
                <button
                  type="button"
                  onClick={onIrRecuperarPassword}
                  className="text-sm text-[#7a4e2a] hover:underline font-medium"
                >
                  ¿Olvidó su contraseña?
                </button>
              </div>
              <input
                type="password"
                required
                placeholder="••••••••"
                value={credenciales.password}
                onChange={(e) => setCredenciales({ ...credenciales, password: e.target.value })}
                className="w-full px-4 py-3 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base text-[#2b190a] focus:outline-none focus:bg-[#fef9c3]/30 transition-colors"
              />
            </div>

            <button
              type="submit"
              disabled={cargando}
              className="w-full py-3.5 bg-[#7a4e2a] hover:bg-[#684122] text-[#fffdf5] rounded-xl font-bold text-base shadow-sm border-2 border-[#7a4e2a] transition-all disabled:opacity-50"
            >
              {cargando ? 'Accediendo al sistema...' : 'Ingresar a la Plataforma'}
            </button>
          </form>
        ) : (
          /* FORMULARIO REGISTRO */
          <form onSubmit={handleSubmitRegistro} className="space-y-4">
            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1">
                Nombre Completo
              </label>
              <input
                type="text"
                required
                placeholder="Nombre y apellido"
                value={datosRegistro.nombre}
                onChange={(e) => setDatosRegistro({ ...datosRegistro, nombre: e.target.value })}
                className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1">
                Correo Electrónico
              </label>
              <input
                type="email"
                required
                placeholder="correo@iglesia.org"
                value={datosRegistro.email}
                onChange={(e) => setDatosRegistro({ ...datosRegistro, email: e.target.value })}
                className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="block text-sm font-bold text-[#7a4e2a] mb-1">
                  Contraseña
                </label>
                <input
                  type="password"
                  required
                  minLength={6}
                  placeholder="Mínimo 6 caracteres"
                  value={datosRegistro.password}
                  onChange={(e) => setDatosRegistro({ ...datosRegistro, password: e.target.value })}
                  className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-[#7a4e2a] mb-1">
                  Teléfono de Contacto
                </label>
                <input
                  type="tel"
                  placeholder="Número de teléfono"
                  value={datosRegistro.telefono}
                  onChange={(e) => setDatosRegistro({ ...datosRegistro, telefono: e.target.value })}
                  className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1">
                Rol o Responsabilidad Asignada
              </label>
              <select
                value={datosRegistro.rol}
                onChange={(e) => setDatosRegistro({ ...datosRegistro, rol: e.target.value })}
                className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
              >
                <option value="Administrador">Administrador</option>
                <option value="Pastor">Pastor</option>
                <option value="Secretario">Secretario</option>
                <option value="Tesorero">Tesorero</option>
                <option value="Coordinador">Coordinador</option>
              </select>
            </div>

            <button
              type="submit"
              disabled={cargando}
              className="w-full py-3 bg-[#7a4e2a] hover:bg-[#684122] text-[#fffdf5] rounded-xl font-bold text-base shadow-sm border-2 border-[#7a4e2a] transition-all disabled:opacity-50"
            >
              {cargando ? 'Guardando registro...' : 'Registrar Usuario'}
            </button>
          </form>
        )}

        {/* ACCESOS DEMOSTRATIVOS POR ROL */}
        <div className="mt-8 pt-6 border-t-2 border-[#7a4e2a]">
          <p className="text-xs uppercase tracking-wider text-[#7a4e2a] font-bold text-center mb-3">
            Acceso Rápido por Rol
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-sm">
            <button
              type="button"
              onClick={() => atajoLogin('admin@iglesia.org')}
              className="p-2.5 rounded-lg border-2 border-[#7a4e2a] bg-[#f5ede1] hover:bg-[#fef9c3] text-[#7a4e2a] font-bold text-center"
            >
              Administrador
            </button>
            <button
              type="button"
              onClick={() => atajoLogin('pastor@iglesia.org')}
              className="p-2.5 rounded-lg border-2 border-[#7a4e2a] bg-[#f5ede1] hover:bg-[#fef9c3] text-[#7a4e2a] font-bold text-center"
            >
              Pastor
            </button>
            <button
              type="button"
              onClick={() => atajoLogin('secretario@iglesia.org')}
              className="p-2.5 rounded-lg border-2 border-[#7a4e2a] bg-[#f5ede1] hover:bg-[#fef9c3] text-[#7a4e2a] font-bold text-center"
            >
              Secretario
            </button>
            <button
              type="button"
              onClick={() => atajoLogin('tesorero@iglesia.org')}
              className="p-2.5 rounded-lg border-2 border-[#7a4e2a] bg-[#f5ede1] hover:bg-[#fef9c3] text-[#7a4e2a] font-bold text-center"
            >
              Tesorero
            </button>
            <button
              type="button"
              onClick={() => atajoLogin('coordinador@iglesia.org')}
              className="p-2.5 rounded-lg border-2 border-[#7a4e2a] bg-[#f5ede1] hover:bg-[#fef9c3] text-[#7a4e2a] font-bold text-center col-span-2 sm:col-span-1"
            >
              Coordinador
            </button>
          </div>
          <p className="text-xs text-[#58351a] text-center mt-3.5">
            Clave predeterminada: <span className="font-mono text-[#7a4e2a] font-bold">Iglesia2026*</span>
          </p>
        </div>
      </div>
    </div>
  );
}
