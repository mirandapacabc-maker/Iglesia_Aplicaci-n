/**
 * Configuración y conexión a la base de datos SQLite integrada (node:sqlite).
 * Inicializa las tablas del sistema relacional y carga datos semilla iniciales si la BD está vacía.
 */
const { DatabaseSync } = require('node:sqlite');
const path = require('node:path');
const fs = require('node:fs');
const bcrypt = require('bcryptjs');

const dbPath = path.resolve(__dirname, '../../iglesia.db');
const db = new DatabaseSync(dbPath);

// Configuración de rendimiento e integridad referencial
db.exec('PRAGMA foreign_keys = ON;');
db.exec('PRAGMA journal_mode = WAL;');

/**
 * Inicialización de esquemas relacionales del sistema eclesiástico
 */
function initDatabase() {
  db.exec(`
    -- RF-01: Usuarios del sistema con roles y autenticación
    CREATE TABLE IF NOT EXISTS usuarios (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nombre TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      rol TEXT NOT NULL CHECK(rol IN ('Administrador', 'Pastor', 'Secretario', 'Tesorero', 'Coordinador')),
      telefono TEXT,
      activo INTEGER NOT NULL DEFAULT 1,
      reset_token TEXT,
      reset_token_expira TEXT,
      creado_en DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- RF-02: Directorio de miembros de la congregación con borrado lógico (soft-delete)
    CREATE TABLE IF NOT EXISTS miembros (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nombre TEXT NOT NULL,
      telefono TEXT,
      email TEXT,
      direccion TEXT,
      fecha_ingreso TEXT NOT NULL,
      fecha_nacimiento TEXT,
      activo INTEGER NOT NULL DEFAULT 1,
      notas TEXT,
      creado_en DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- RF-04: Calendario de eventos y cultos
    CREATE TABLE IF NOT EXISTS eventos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      titulo TEXT NOT NULL,
      tipo TEXT NOT NULL DEFAULT 'Culto' CHECK(tipo IN ('Culto', 'Reunión', 'Vigilia', 'Estudio Bíblico', 'Actividad Especial', 'Administrativo')),
      fecha TEXT NOT NULL,
      hora TEXT NOT NULL,
      lugar TEXT NOT NULL,
      descripcion TEXT,
      responsable_id INTEGER,
      estado TEXT NOT NULL DEFAULT 'Programado' CHECK(estado IN ('Programado', 'Realizado', 'Cancelado')),
      creado_en DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (responsable_id) REFERENCES miembros(id) ON DELETE SET NULL
    );

    -- RF-03: Control de asistencia por culto/evento y por miembro
    CREATE TABLE IF NOT EXISTS asistencias (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      evento_id INTEGER NOT NULL,
      miembro_id INTEGER NOT NULL,
      fecha TEXT NOT NULL,
      estado TEXT NOT NULL CHECK(estado IN ('Presente', 'Ausente', 'Justificado')),
      observaciones TEXT,
      registrado_en DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (evento_id) REFERENCES eventos(id) ON DELETE CASCADE,
      FOREIGN KEY (miembro_id) REFERENCES miembros(id) ON DELETE CASCADE,
      UNIQUE(evento_id, miembro_id, fecha)
    );

    -- RF-05: Ministerios y departamentos de la iglesia
    CREATE TABLE IF NOT EXISTS ministerios (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nombre TEXT UNIQUE NOT NULL,
      descripcion TEXT,
      coordinador_id INTEGER,
      activo INTEGER NOT NULL DEFAULT 1,
      creado_en DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (coordinador_id) REFERENCES miembros(id) ON DELETE SET NULL
    );

    -- Vinculación de miembros a ministerios
    CREATE TABLE IF NOT EXISTS ministerio_miembros (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ministerio_id INTEGER NOT NULL,
      miembro_id INTEGER NOT NULL,
      rol_ministerio TEXT DEFAULT 'Miembro',
      fecha_ingreso TEXT DEFAULT CURRENT_DATE,
      FOREIGN KEY (ministerio_id) REFERENCES ministerios(id) ON DELETE CASCADE,
      FOREIGN KEY (miembro_id) REFERENCES miembros(id) ON DELETE CASCADE,
      UNIQUE(ministerio_id, miembro_id)
    );

    -- Actividades programadas por ministerio
    CREATE TABLE IF NOT EXISTS ministerio_actividades (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ministerio_id INTEGER NOT NULL,
      titulo TEXT NOT NULL,
      descripcion TEXT,
      fecha TEXT NOT NULL,
      hora TEXT NOT NULL,
      lugar TEXT,
      creado_en DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (ministerio_id) REFERENCES ministerios(id) ON DELETE CASCADE
    );

    -- RF-06: Gestión financiera y registro de aportaciones
    CREATE TABLE IF NOT EXISTS donaciones (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      fecha TEXT NOT NULL,
      monto REAL NOT NULL CHECK(monto > 0),
      concepto TEXT NOT NULL,
      metodo_pago TEXT NOT NULL CHECK(metodo_pago IN ('Efectivo', 'Transferencia', 'Tarjeta', 'Cheque', 'Otro')),
      miembro_id INTEGER,
      es_anonimo INTEGER NOT NULL DEFAULT 0,
      notas TEXT,
      registrado_por INTEGER,
      creado_en DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (miembro_id) REFERENCES miembros(id) ON DELETE SET NULL,
      FOREIGN KEY (registrado_por) REFERENCES usuarios(id) ON DELETE SET NULL
    );

    -- RF-07: Publicación de anuncios y comunicados
    CREATE TABLE IF NOT EXISTS anuncios (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      titulo TEXT NOT NULL,
      contenido TEXT NOT NULL,
      categoria TEXT DEFAULT 'General',
      destacado INTEGER NOT NULL DEFAULT 0,
      autor_id INTEGER,
      fecha_publicacion DATETIME DEFAULT CURRENT_TIMESTAMP,
      creado_en DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (autor_id) REFERENCES usuarios(id) ON DELETE SET NULL
    );

    -- RF-10: Configuración institucional de la iglesia
    CREATE TABLE IF NOT EXISTS configuracion_iglesia (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      nombre TEXT NOT NULL,
      lema TEXT,
      direccion TEXT,
      telefono TEXT,
      email TEXT,
      pastor_principal TEXT,
      logo_url TEXT,
      horarios_cultos TEXT,
      actualizado_en DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  seedInitialData();
}

/**
 * Carga de datos iniciales demostrativos y cuentas maestras de cada rol
 */
function seedInitialData() {
  const userCount = db.prepare('SELECT COUNT(*) as total FROM usuarios').get().total;
  if (userCount > 0) return;

  const defaultPassword = bcrypt.hashSync('Iglesia2026*', 10);

  // RF-01: Creación de usuarios por cada uno de los 5 roles obligatorios
  const insertUser = db.prepare(`
    INSERT INTO usuarios (nombre, email, password_hash, rol, telefono, activo)
    VALUES (?, ?, ?, ?, ?, 1)
  `);

  insertUser.run('Carlos Mendoza (Admin)', 'admin@iglesia.org', defaultPassword, 'Administrador', '+52 55 1122 3344');
  insertUser.run('David Morales (Pastor)', 'pastor@iglesia.org', defaultPassword, 'Pastor', '+52 55 2233 4455');
  insertUser.run('Elena Restrepo (Secretaria)', 'secretario@iglesia.org', defaultPassword, 'Secretario', '+52 55 3344 5566');
  insertUser.run('Roberto Silva (Tesorero)', 'tesorero@iglesia.org', defaultPassword, 'Tesorero', '+52 55 4455 6677');
  insertUser.run('Valeria Cruz (Coordinadora)', 'coordinador@iglesia.org', defaultPassword, 'Coordinador', '+52 55 5566 7788');

  // RF-02: Inserción de miembros de prueba
  const insertMiembro = db.prepare(`
    INSERT INTO miembros (nombre, telefono, email, direccion, fecha_ingreso, fecha_nacimiento, activo, notas)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);

  insertMiembro.run('David Morales', '+52 55 2233 4455', 'david.morales@gmail.com', 'Calle Betania 101, Col. Fe', '2018-01-15', '1975-06-12', 1, 'Pastor General');
  insertMiembro.run('Ruth de Morales', '+52 55 2233 4456', 'ruth.morales@gmail.com', 'Calle Betania 101, Col. Fe', '2018-01-15', '1978-09-20', 1, 'Líder Ministerio de Damas');
  insertMiembro.run('Carlos Mendoza', '+52 55 1122 3344', 'carlos.mendoza@gmail.com', 'Av. Esperanza 404, Col. Centro', '2019-03-10', '1985-04-18', 1, 'Administrador del sistema');
  insertMiembro.run('Elena Restrepo', '+52 55 3344 5566', 'elena.restrepo@gmail.com', 'Calle Olivos 23, Col. Palmas', '2020-05-20', '1990-11-05', 1, 'Secretaría de actas y correspondencia');
  insertMiembro.run('Roberto Silva', '+52 55 4455 6677', 'roberto.silva@gmail.com', 'Privada Sinaí 12, Col. Granjas', '2019-08-14', '1982-01-30', 1, 'Contador y tesorero');
  insertMiembro.run('Valeria Cruz', '+52 55 5566 7788', 'valeria.cruz@gmail.com', 'Av. Reforma 890, Int 4', '2021-02-01', '1995-07-22', 1, 'Directora del grupo de alabanza');
  insertMiembro.run('Marcos Sandoval', '+52 55 6677 8899', 'marcos.sandoval@gmail.com', 'Calle Jordán 56, Col. Jardines', '2021-06-18', '1998-12-03', 1, 'Líder del grupo de jóvenes');
  insertMiembro.run('Ana Lucía Gómez', '+52 55 7788 9900', 'ana.gomez@gmail.com', 'Calle Nazareth 77, Col. Mirador', '2022-01-10', '1992-03-14', 1, 'Maestra de escuela dominical infantil');
  insertMiembro.run('Jorge Arturo Peña', '+52 55 8899 0011', 'jorge.pena@gmail.com', 'Calle Galillea 34, Col. Colinas', '2022-07-25', '1987-10-09', 1, 'Ujier y coordinador de logística');
  insertMiembro.run('Gabriela Flores', '+52 55 9900 1122', 'gabriela.flores@gmail.com', 'Av. Cedros 302, Col. Álamos', '2023-03-12', '2001-08-17', 1, 'Miembro del ministerio de alabanza (baterista)');
  insertMiembro.run('Héctor Villalobos', '+52 55 0011 2233', 'hector.v@gmail.com', 'Calle Ciprés 15, Col. Bosques', '2023-09-01', '1970-02-28', 1, 'Miembro activo');
  insertMiembro.run('Carmen Salgado', '+52 55 1234 5679', 'carmen.salgado@gmail.com', 'Calle Jerusalén 90, Col. Centro', '2019-11-10', '1965-05-15', 0, 'Inactiva temporal por cambio de residencia');

  // RF-05: Ministerios predeterminados
  const insertMinisterio = db.prepare(`
    INSERT INTO ministerios (nombre, descripcion, coordinador_id, activo)
    VALUES (?, ?, ?, 1)
  `);

  insertMinisterio.run('Alabanza y Adoración', 'Encargados de la dirección musical y técnica en cada servicio.', 6);
  insertMinisterio.run('Jóvenes con Visión', 'Actividades de discipulado, integración y servicio para adolescentes y universitarios.', 7);
  insertMinisterio.run('Escuela Infantil (Semillitas de Fe)', 'Educación bíblica y formación de valores para niños de 3 a 11 años.', 8);
  insertMinisterio.run('Ujieres y Hospitalidad', 'Recepción de miembros, protocolo de bienvenida y apoyo de orden en los cultos.', 9);
  insertMinisterio.run('Ministerio de Damas', 'Reuniones de oración, consejería y apoyo comunitario entre mujeres de la congregación.', 2);

  // Vincular miembros a ministerios
  const insertMinMiembro = db.prepare(`
    INSERT INTO ministerio_miembros (ministerio_id, miembro_id, rol_ministerio)
    VALUES (?, ?, ?)
  `);
  insertMinMiembro.run(1, 6, 'Directora de Alabanza');
  insertMinMiembro.run(1, 10, 'Instrumentista');
  insertMinMiembro.run(2, 7, 'Presidente Juvenil');
  insertMinMiembro.run(2, 10, 'Subcoordinadora');
  insertMinMiembro.run(3, 8, 'Coordinadora Pedagógica');
  insertMinMiembro.run(4, 9, 'Jefe de Ujieres');
  insertMinMiembro.run(5, 2, 'Líder Femenil');

  // RF-04: Eventos del mes
  const insertEvento = db.prepare(`
    INSERT INTO eventos (titulo, tipo, fecha, hora, lugar, descripcion, responsable_id, estado)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const hoy = new Date();
  const fechaRelativa = (diasOffset) => {
    const d = new Date(hoy);
    d.setDate(d.getDate() + diasOffset);
    return d.toISOString().split('T')[0];
  };

  insertEvento.run('Culto Dominical de Celebración', 'Culto', fechaRelativa(-7), '10:00', 'Templo Principal', 'Servicio general con alabanza y predicación de la palabra.', 1, 'Realizado');
  insertEvento.run('Estudio Bíblico y Oración', 'Estudio Bíblico', fechaRelativa(-4), '19:30', 'Salón de Usos Múltiples', 'Serie sobre el libro de Romanos.', 1, 'Realizado');
  insertEvento.run('Culto Dominical Familiar', 'Culto', fechaRelativa(0), '10:00', 'Templo Principal', 'Culto dominical con Santa Cena.', 1, 'Programado');
  insertEvento.run('Noche de Jóvenes: Conectados', 'Actividad Especial', fechaRelativa(2), '18:00', 'Auditorio Juvenil', 'Dinámicas, refrigerio y mensaje para jóvenes.', 7, 'Programado');
  insertEvento.run('Reunión de Consejo Administrativo', 'Administrativo', fechaRelativa(5), '19:00', 'Sala de Juntas', 'Revisión presupuestaria y proyectos del trimestre.', 3, 'Programado');
  insertEvento.run('Vigilia Unida de Oración', 'Vigilia', fechaRelativa(9), '21:00', 'Templo Principal', 'Clamor por las familias y la comunidad.', 1, 'Programado');

  // RF-03: Asistencia de eventos pasados
  const insertAsistencia = db.prepare(`
    INSERT INTO asistencias (evento_id, miembro_id, fecha, estado, observaciones)
    VALUES (?, ?, ?, ?, ?)
  `);
  // Asistencia al evento de hace 7 días (ID 1)
  const evento1Fecha = fechaRelativa(-7);
  [1, 2, 3, 4, 5, 6, 7, 8, 9, 10].forEach((mid) => {
    insertAsistencia.run(1, mid, evento1Fecha, 'Presente', 'Puntual');
  });
  insertAsistencia.run(1, 11, evento1Fecha, 'Ausente', 'Motivos de salud');

  // RF-06: Aportaciones y donaciones de prueba
  const insertDonacion = db.prepare(`
    INSERT INTO donaciones (fecha, monto, concepto, metodo_pago, miembro_id, es_anonimo, notas, registrado_por)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);

  insertDonacion.run(fechaRelativa(-12), 2500.00, 'Diezmo', 'Transferencia', 3, 0, 'Diezmo primera quincena', 4);
  insertDonacion.run(fechaRelativa(-10), 850.00, 'Ofrenda General', 'Efectivo', null, 1, 'Colecta de culto dominical anónima', 4);
  insertDonacion.run(fechaRelativa(-7), 1800.00, 'Diezmo', 'Transferencia', 5, 0, 'Diezmo mensual', 4);
  insertDonacion.run(fechaRelativa(-5), 5000.00, 'Pro-Templo', 'Transferencia', 1, 0, 'Aporte fondo nuevo sonido', 4);
  insertDonacion.run(fechaRelativa(-2), 620.00, 'Ofrenda Misionera', 'Efectivo', null, 1, 'Ofrenda misionera anónima', 4);
  insertDonacion.run(fechaRelativa(0), 1200.00, 'Diezmo', 'Efectivo', 6, 0, 'Diezmo personal', 4);

  // RF-07: Anuncios institucionales
  const insertAnuncio = db.prepare(`
    INSERT INTO anuncios (titulo, contenido, categoria, destacado, autor_id)
    VALUES (?, ?, ?, ?, 1)
  `);

  insertAnuncio.run(
    'Gran Campamento Juvenil de Verano 2026',
    'Las inscripciones para nuestro campamento anual ya están abiertas. Cupos limitados. Contactar al hermano Marcos Sandoval para apartar lugar.',
    'Jóvenes',
    1
  );
  insertAnuncio.run(
    'Inicio de Talleres de Discipulado Nivel 1',
    'Todos los martes a las 19:30 hrs en el aula B. Abierto para nuevos creyentes y quienes deseen reafirmar sus fundamentos doctrinales.',
    'Formación',
    1
  );
  insertAnuncio.run(
    'Jornada de Limpieza y Ornato del Templo',
    'Este próximo sábado a partir de las 09:00 hrs. Agradecemos su apoyo trayendo herramientas de aseo y pintura.',
    'Servicio',
    0
  );

  // RF-10: Configuración institucional
  const insertConfig = db.prepare(`
    INSERT INTO configuracion_iglesia (id, nombre, lema, direccion, telefono, email, pastor_principal, logo_url, horarios_cultos)
    VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const horariosDefault = JSON.stringify([
    { dia: 'Domingo', hora: '10:00 AM', nombre: 'Culto de Celebración Principal' },
    { dia: 'Miércoles', hora: '07:30 PM', nombre: 'Estudio Bíblico y Escuela de Vida' },
    { dia: 'Viernes', hora: '07:00 PM', nombre: 'Reunión General de Jóvenes' },
    { dia: 'Sábado', hora: '07:00 AM', nombre: 'Círculo de Oración e Intercesión' }
  ]);

  insertConfig.run(
    'Iglesia Comunidad Cristiana La Fe',
    'Una familia que ama a Dios, edifica vidas y transforma la comunidad',
    'Av. De las Américas #450, Colonia del Valle',
    '+52 (55) 7890-1234',
    'contacto@comunidadlafe.org',
    'David Morales & Ruth de Morales',
    'https://images.unsplash.com/photo-1548625361-195fe61a55c3?auto=format&fit=crop&w=300&q=80',
    horariosDefault
  );
}

// Inicializar base de datos al requerir el módulo
initDatabase();

module.exports = db;
