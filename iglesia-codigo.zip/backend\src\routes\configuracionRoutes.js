/**
 * Rutas para la configuración institucional de la iglesia (RF-10).
 */
const { Router } = require('express');
const {
  obtenerConfiguracion,
  actualizarConfiguracion
} = require('../controllers/configuracionController');
const { autenticarToken, autorizarRoles } = require('../middleware/authMiddleware');

const router = Router();

// Consulta pública o autenticada para mostrar logotipo y nombre en toda la app
router.get('/', obtenerConfiguracion);

// Modificación permitida solo a Administrador o Pastor
router.put('/', autenticarToken, autorizarRoles('Administrador', 'Pastor'), actualizarConfiguracion);

module.exports = router;
