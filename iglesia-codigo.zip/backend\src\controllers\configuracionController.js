/**
 * Controlador de Configuración Institucional de la Iglesia (RF-10).
 * Maneja datos generales de la congregación, imagen de logotipo y horarios de reuniones.
 */
const db = require('../config/database');

/**
 * Obtener la configuración actual de la iglesia.
 */
function obtenerConfiguracion(req, res, next) {
  try {
    const config = db.prepare('SELECT * FROM configuracion_iglesia WHERE id = 1').get();

    if (!config) {
      return res.status(404).json({ mensaje: 'Configuración no encontrada.' });
    }

    let horarios = [];
    try {
      horarios = config.horarios_cultos ? JSON.parse(config.horarios_cultos) : [];
    } catch {
      horarios = [];
    }

    return res.json({
      configuracion: {
        ...config,
        horarios
      }
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Actualizar los datos institucionales de la iglesia y horarios habituales.
 */
function actualizarConfiguracion(req, res, next) {
  try {
    const { nombre, lema, direccion, telefono, email, pastor_principal, logo_url, horarios } = req.body;

    if (!nombre || !nombre.trim()) {
      return res.status(400).json({ mensaje: 'El nombre de la iglesia es obligatorio.' });
    }

    const horariosJson = Array.isArray(horarios) ? JSON.stringify(horarios) : null;

    db.prepare(`
      UPDATE configuracion_iglesia
      SET nombre = ?, lema = ?, direccion = ?, telefono = ?, email = ?, pastor_principal = ?, logo_url = ?, horarios_cultos = ?, actualizado_en = CURRENT_TIMESTAMP
      WHERE id = 1
    `).run(
      nombre.trim(),
      lema ? lema.trim() : null,
      direccion ? direccion.trim() : null,
      telefono ? telefono.trim() : null,
      email ? email.trim() : null,
      pastor_principal ? pastor_principal.trim() : null,
      logo_url ? logo_url.trim() : null,
      horariosJson
    );

    const configActualizada = db.prepare('SELECT * FROM configuracion_iglesia WHERE id = 1').get();

    return res.json({
      mensaje: 'Configuración de la iglesia actualizada con éxito.',
      configuracion: {
        ...configActualizada,
        horarios: configActualizada.horarios_cultos ? JSON.parse(configActualizada.horarios_cultos) : []
      }
    });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  obtenerConfiguracion,
  actualizarConfiguracion
};
