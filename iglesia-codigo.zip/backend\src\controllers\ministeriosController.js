/**
 * Controlador de Administración de Ministerios y Grupos de Trabajo (RF-05).
 * Maneja creación de ministerios, asignación de coordinadores, vinculación/desvinculación de miembros y actividades.
 */
const db = require('../config/database');

/**
 * Listado de ministerios con su coordinador y total de miembros activos.
 */
function listarMinisterios(req, res, next) {
  try {
    const query = `
      SELECT 
        m.id, m.nombre, m.descripcion, m.activo, m.creado_en,
        m.coordinador_id,
        c.nombre AS coordinador_nombre,
        c.telefono AS coordinador_telefono,
        (SELECT COUNT(*) FROM ministerio_miembros mm WHERE mm.ministerio_id = m.id) AS total_integrantes
      FROM ministerios m
      LEFT JOIN miembros c ON m.coordinador_id = c.id
      ORDER BY m.nombre ASC
    `;

    const ministerios = db.prepare(query).all();
    return res.json({ ministerios });
  } catch (error) {
    next(error);
  }
}

/**
 * Detalle completo de un ministerio: información general, miembros vinculados y actividades programadas.
 */
function obtenerMinisterioPorId(req, res, next) {
  try {
    const { id } = req.params;

    const ministerio = db.prepare(`
      SELECT 
        m.id, m.nombre, m.descripcion, m.activo, m.creado_en,
        m.coordinador_id,
        c.nombre AS coordinador_nombre,
        c.telefono AS coordinador_telefono
      FROM ministerios m
      LEFT JOIN miembros c ON m.coordinador_id = c.id
      WHERE m.id = ?
    `).get(id);

    if (!ministerio) {
      return res.status(404).json({ mensaje: 'Ministerio no encontrado.' });
    }

    // Miembros integrantes del ministerio
    const miembros = db.prepare(`
      SELECT 
        mm.id AS vinculo_id,
        mm.rol_ministerio,
        mm.fecha_ingreso,
        mb.id AS miembro_id,
        mb.nombre,
        mb.telefono,
        mb.email,
        mb.activo
      FROM ministerio_miembros mm
      JOIN miembros mb ON mm.miembro_id = mb.id
      WHERE mm.ministerio_id = ?
      ORDER BY mb.nombre ASC
    `).all(id);

    // Actividades programadas
    const actividades = db.prepare(`
      SELECT id, titulo, descripcion, fecha, hora, lugar, creado_en
      FROM ministerio_actividades
      WHERE ministerio_id = ?
      ORDER BY fecha DESC, hora DESC
    `).all(id);

    return res.json({
      ministerio,
      miembros,
      actividades
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Creación de un nuevo ministerio.
 */
function crearMinisterio(req, res, next) {
  try {
    const { nombre, descripcion, coordinador_id } = req.body;

    if (!nombre || !nombre.trim()) {
      return res.status(400).json({ mensaje: 'El nombre del ministerio es obligatorio.' });
    }

    const existe = db.prepare('SELECT id FROM ministerios WHERE LOWER(nombre) = LOWER(?)').get(nombre.trim());
    if (existe) {
      return res.status(409).json({ mensaje: 'Ya existe un ministerio con ese nombre.' });
    }

    const resultado = db.prepare(`
      INSERT INTO ministerios (nombre, descripcion, coordinador_id, activo)
      VALUES (?, ?, ?, 1)
    `).run(nombre.trim(), descripcion ? descripcion.trim() : null, coordinador_id || null);

    const nuevoMinisterio = db.prepare('SELECT * FROM ministerios WHERE id = ?').get(resultado.lastInsertRowid);

    return res.status(201).json({
      mensaje: 'Ministerio creado exitosamente.',
      ministerio: nuevoMinisterio
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Actualización de un ministerio existente y su coordinador.
 */
function actualizarMinisterio(req, res, next) {
  try {
    const { id } = req.params;
    const { nombre, descripcion, coordinador_id, activo } = req.body;

    if (!nombre || !nombre.trim()) {
      return res.status(400).json({ mensaje: 'El nombre del ministerio es requerido.' });
    }

    db.prepare(`
      UPDATE ministerios
      SET nombre = ?, descripcion = ?, coordinador_id = ?, activo = ?
      WHERE id = ?
    `).run(
      nombre.trim(),
      descripcion ? descripcion.trim() : null,
      coordinador_id || null,
      activo !== undefined ? (activo ? 1 : 0) : 1,
      id
    );

    const ministerioActualizado = db.prepare('SELECT * FROM ministerios WHERE id = ?').get(id);

    return res.json({
      mensaje: 'Ministerio actualizado con éxito.',
      ministerio: ministerioActualizado
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Vincular un miembro de la iglesia al ministerio.
 */
function vincularMiembro(req, res, next) {
  try {
    const { id } = req.params; // ministerio_id
    const { miembro_id, rol_ministerio } = req.body;

    if (!miembro_id) {
      return res.status(400).json({ mensaje: 'Debes seleccionar un miembro para vincular.' });
    }

    // Verificar si ya está vinculado
    const yaVinculado = db.prepare('SELECT id FROM ministerio_miembros WHERE ministerio_id = ? AND miembro_id = ?').get(id, miembro_id);
    if (yaVinculado) {
      return res.status(409).json({ mensaje: 'El miembro ya forma parte de este ministerio.' });
    }

    db.prepare(`
      INSERT INTO ministerio_miembros (ministerio_id, miembro_id, rol_ministerio)
      VALUES (?, ?, ?)
    `).run(id, miembro_id, rol_ministerio || 'Miembro');

    return res.status(201).json({ mensaje: 'Miembro integrado al ministerio correctamente.' });
  } catch (error) {
    next(error);
  }
}

/**
 * Desvincular un miembro del ministerio.
 */
function desvincularMiembro(req, res, next) {
  try {
    const { id, miembroId } = req.params;

    db.prepare('DELETE FROM ministerio_miembros WHERE ministerio_id = ? AND miembro_id = ?').run(id, miembroId);

    return res.json({ mensaje: 'Miembro retirado del ministerio exitosamente.' });
  } catch (error) {
    next(error);
  }
}

/**
 * Crear una actividad específica de un ministerio.
 */
function crearActividad(req, res, next) {
  try {
    const { id } = req.params; // ministerio_id
    const { titulo, descripcion, fecha, hora, lugar } = req.body;

    if (!titulo || !fecha || !hora) {
      return res.status(400).json({ mensaje: 'Título, fecha y hora de la actividad son requeridos.' });
    }

    db.prepare(`
      INSERT INTO ministerio_actividades (ministerio_id, titulo, descripcion, fecha, hora, lugar)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(id, titulo.trim(), descripcion ? descripcion.trim() : null, fecha, hora, lugar ? lugar.trim() : null);

    return res.status(201).json({ mensaje: 'Actividad del ministerio programada con éxito.' });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  listarMinisterios,
  obtenerMinisterioPorId,
  crearMinisterio,
  actualizarMinisterio,
  vincularMiembro,
  desvincularMiembro,
  crearActividad
};
