/**
 * Controlador del Módulo de Reportes Eclesiásticos (RF-09).
 * Provee datos estructurados para los 4 reportes obligatorios:
 * 1. Reporte general de miembros
 * 2. Reporte de asistencia por evento
 * 3. Reporte de participación por ministerio
 * 4. Reporte de ingresos por periodo (con restricción estricta de roles financieros)
 */
const db = require('../config/database');

const ROLES_FINANCIEROS = ['Administrador', 'Pastor', 'Tesorero'];

/**
 * 1. Reporte general de miembros (filtrable por estado y rango de fechas de ingreso).
 */
function reporteGeneralMiembros(req, res, next) {
  try {
    const { estado = 'todos', fechaInicio, fechaFin } = req.query;

    let condiciones = [];
    let parametros = [];

    if (estado === 'activos') {
      condiciones.push('m.activo = 1');
    } else if (estado === 'inactivos') {
      condiciones.push('m.activo = 0');
    }

    if (fechaInicio) {
      condiciones.push('m.fecha_ingreso >= ?');
      parametros.push(fechaInicio);
    }
    if (fechaFin) {
      condiciones.push('m.fecha_ingreso <= ?');
      parametros.push(fechaFin);
    }

    const whereClause = condiciones.length > 0 ? `WHERE ${condiciones.join(' AND ')}` : '';

    const query = `
      SELECT 
        m.id, m.nombre, m.telefono, m.email, m.direccion, m.fecha_ingreso, m.fecha_nacimiento, m.activo, m.notas,
        (SELECT GROUP_CONCAT(min.nombre, ', ') 
         FROM ministerio_miembros mm 
         JOIN ministerios min ON mm.ministerio_id = min.id 
         WHERE mm.miembro_id = m.id) AS ministerios_nombres
      FROM miembros m
      ${whereClause}
      ORDER BY m.nombre ASC
    `;

    const miembros = db.prepare(query).all(...parametros);

    const totalActivos = miembros.filter((m) => m.activo === 1).length;
    const totalInactivos = miembros.length - totalActivos;

    return res.json({
      resumen: {
        total: miembros.length,
        activos: totalActivos,
        inactivos: totalInactivos
      },
      miembros
    });
  } catch (error) {
    next(error);
  }
}

/**
 * 2. Reporte de asistencia por evento o periodo.
 */
function reporteAsistenciaPorEvento(req, res, next) {
  try {
    const { eventoId, fechaInicio, fechaFin } = req.query;

    let condiciones = [];
    let parametros = [];

    if (eventoId) {
      condiciones.push('e.id = ?');
      parametros.push(eventoId);
    }
    if (fechaInicio) {
      condiciones.push('a.fecha >= ?');
      parametros.push(fechaInicio);
    }
    if (fechaFin) {
      condiciones.push('a.fecha <= ?');
      parametros.push(fechaFin);
    }

    const whereClause = condiciones.length > 0 ? `WHERE ${condiciones.join(' AND ')}` : '';

    const query = `
      SELECT 
        a.id AS asistencia_id,
        a.fecha,
        a.estado,
        a.observaciones,
        e.id AS evento_id,
        e.titulo AS evento_titulo,
        e.tipo AS evento_tipo,
        m.id AS miembro_id,
        m.nombre AS miembro_nombre,
        m.telefono AS miembro_telefono
      FROM asistencias a
      JOIN eventos e ON a.evento_id = e.id
      JOIN miembros m ON a.miembro_id = m.id
      ${whereClause}
      ORDER BY a.fecha DESC, m.nombre ASC
    `;

    const asistencias = db.prepare(query).all(...parametros);

    const presentes = asistencias.filter((a) => a.estado === 'Presente').length;
    const ausentes = asistencias.filter((a) => a.estado === 'Ausente').length;
    const justificados = asistencias.filter((a) => a.estado === 'Justificado').length;

    return res.json({
      resumen: {
        totalRegistros: asistencias.length,
        presentes,
        ausentes,
        justificados,
        tasaAsistencia: asistencias.length > 0 ? `${Math.round((presentes / asistencias.length) * 100)}%` : '0%'
      },
      asistencias
    });
  } catch (error) {
    next(error);
  }
}

/**
 * 3. Reporte de participación por ministerio.
 */
function reporteParticipacionMinisterios(req, res, next) {
  try {
    const { ministerioId } = req.query;

    let condicion = '';
    let parametros = [];

    if (ministerioId) {
      condicion = 'WHERE min.id = ?';
      parametros.push(ministerioId);
    }

    const query = `
      SELECT 
        min.id AS ministerio_id,
        min.nombre AS ministerio_nombre,
        min.descripcion,
        c.nombre AS coordinador_nombre,
        m.id AS miembro_id,
        m.nombre AS miembro_nombre,
        m.telefono AS miembro_telefono,
        m.email AS miembro_email,
        mm.rol_ministerio,
        mm.fecha_ingreso AS fecha_ingreso_ministerio
      FROM ministerios min
      LEFT JOIN miembros c ON min.coordinador_id = c.id
      LEFT JOIN ministerio_miembros mm ON min.id = mm.ministerio_id
      LEFT JOIN miembros m ON mm.miembro_id = m.id
      ${condicion}
      ORDER BY min.nombre ASC, m.nombre ASC
    `;

    const filas = db.prepare(query).all(...parametros);

    // Agrupar por ministerio para visualización clara y exportación
    const ministeriosMap = {};
    for (const fila of filas) {
      if (!ministeriosMap[fila.ministerio_id]) {
        ministeriosMap[fila.ministerio_id] = {
          id: fila.ministerio_id,
          nombre: fila.ministerio_nombre,
          descripcion: fila.descripcion,
          coordinador: fila.coordinador_nombre || 'No asignado',
          integrantes: []
        };
      }
      if (fila.miembro_id) {
        ministeriosMap[fila.ministerio_id].integrantes.push({
          id: fila.miembro_id,
          nombre: fila.miembro_nombre,
          telefono: fila.miembro_telefono,
          email: fila.miembro_email,
          rol: fila.rol_ministerio,
          fechaIngreso: fila.fecha_ingreso_ministerio
        });
      }
    }

    const ministerios = Object.values(ministeriosMap);

    return res.json({
      resumen: {
        totalMinisterios: ministerios.length,
        totalParticipaciones: filas.filter((f) => f.miembro_id !== null).length
      },
      ministerios,
      filasPlanificadas: filas.filter((f) => f.miembro_id !== null)
    });
  } catch (error) {
    next(error);
  }
}

/**
 * 4. Reporte de ingresos por periodo (seguridad financiera: Administrador, Pastor, Tesorero).
 */
function reporteIngresosPeriodo(req, res, next) {
  try {
    if (!ROLES_FINANCIEROS.includes(req.usuario.rol)) {
      return res.status(403).json({
        mensaje: `Acceso denegado: El rol '${req.usuario.rol}' no tiene permisos para generar reportes financieros.`
      });
    }

    const { fechaInicio, fechaFin, concepto, metodoPago } = req.query;

    let condiciones = [];
    let parametros = [];

    if (fechaInicio) {
      condiciones.push('d.fecha >= ?');
      parametros.push(fechaInicio);
    }
    if (fechaFin) {
      condiciones.push('d.fecha <= ?');
      parametros.push(fechaFin);
    }
    if (concepto) {
      condiciones.push('d.concepto = ?');
      parametros.push(concepto);
    }
    if (metodoPago) {
      condiciones.push('d.metodo_pago = ?');
      parametros.push(metodoPago);
    }

    const whereClause = condiciones.length > 0 ? `WHERE ${condiciones.join(' AND ')}` : '';

    const query = `
      SELECT 
        d.id, d.fecha, d.monto, d.concepto, d.metodo_pago, d.es_anonimo, d.notas,
        CASE WHEN d.es_anonimo = 1 THEN 'Anónimo' ELSE m.nombre END AS aportante,
        u.nombre AS registrado_por
      FROM donaciones d
      LEFT JOIN miembros m ON d.miembro_id = m.id
      LEFT JOIN usuarios u ON d.registrado_por = u.id
      ${whereClause}
      ORDER BY d.fecha DESC, d.id DESC
    `;

    const donaciones = db.prepare(query).all(...parametros);

    const totalRecaudado = donaciones.reduce((sum, d) => sum + d.monto, 0);

    // Desglose por concepto
    const porConcepto = {};
    for (const d of donaciones) {
      porConcepto[d.concepto] = (porConcepto[d.concepto] || 0) + d.monto;
    }

    // Desglose por método de pago
    const porMetodo = {};
    for (const d of donaciones) {
      porMetodo[d.metodo_pago] = (porMetodo[d.metodo_pago] || 0) + d.monto;
    }

    return res.json({
      resumen: {
        totalTransacciones: donaciones.length,
        totalRecaudado,
        porConcepto,
        porMetodo
      },
      donaciones
    });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  reporteGeneralMiembros,
  reporteAsistenciaPorEvento,
  reporteParticipacionMinisterios,
  reporteIngresosPeriodo
};
