/**
 * Vista de Publicación de Anuncios y Comunicados de la Iglesia (RF-07).
 * Predominante: #fffdf5, Contorno: #7a4e2a, Blanco, Beige (#faf4ea, #f5ede1) y Amarillo Pálido #fef9c3.
 * Tipografía: Day Roman Regular (sin iconos, letras más grandes y legibles).
 */
import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { anunciosService } from '../services/api';
import Modal from '../components/Modal';

export default function AnunciosView() {
  const { puedeGestionarEventos } = useAuth();

  const [anuncios, setAnuncios] = useState([]);
  const [filtroCategoria, setFiltroCategoria] = useState('');
  const [soloDestacados, setSoloDestacados] = useState(false);

  const [cargando, setCargando] = useState(false);
  const [mensaje, setMensaje] = useState('');
  const [error, setError] = useState('');

  const [modalAbierto, setModalAbierto] = useState(false);
  const [anuncioEnEdicion, setAnuncioEnEdicion] = useState(null);
  const [guardando, setGuardando] = useState(false);

  // Formulario (RF-07: título, contenido, categoría, destacado)
  const [formAnuncio, setFormAnuncio] = useState({
    titulo: '',
    contenido: '',
    categoria: 'General',
    destacado: false,
  });

  useEffect(() => {
    cargarAnuncios();
  }, [filtroCategoria, soloDestacados]);

  async function cargarAnuncios() {
    setCargando(true);
    setError('');
    try {
      const res = await anunciosService.listar({
        categoria: filtroCategoria,
        destacados: soloDestacados,
      });
      setAnuncios(res.anuncios);
    } catch (err) {
      setError(err.message || 'Error al consultar avisos.');
    } finally {
      setCargando(false);
    }
  }

  function abrirModalNuevo() {
    setAnuncioEnEdicion(null);
    setFormAnuncio({
      titulo: '',
      contenido: '',
      categoria: 'General',
      destacado: false,
    });
    setModalAbierto(true);
  }

  function abrirModalEditar(an) {
    setAnuncioEnEdicion(an);
    setFormAnuncio({
      titulo: an.titulo,
      contenido: an.contenido,
      categoria: an.categoria,
      destacado: Boolean(an.destacado),
    });
    setModalAbierto(true);
  }

  async function handleGuardarAnuncio(e) {
    e.preventDefault();
    setGuardando(true);
    setError('');
    setMensaje('');

    try {
      if (anuncioEnEdicion) {
        await anunciosService.actualizar(anuncioEnEdicion.id, formAnuncio);
        setMensaje('Anuncio actualizado con éxito.');
      } else {
        await anunciosService.crear(formAnuncio);
        setMensaje('Anuncio publicado correctamente en la comunidad.');
      }
      setModalAbierto(false);
      cargarAnuncios();
    } catch (err) {
      setError(err.message || 'Error al guardar el anuncio.');
    } finally {
      setGuardando(false);
    }
  }

  async function handleEliminarAnuncio(id) {
    if (!window.confirm('¿Desea eliminar esta publicación de la comunidad?')) return;
    try {
      await anunciosService.eliminar(id);
      setMensaje('Publicación eliminada correctamente.');
      cargarAnuncios();
    } catch (err) {
      setError(err.message || 'Error al eliminar el anuncio.');
    }
  }

  return (
    <div className="space-y-7 text-[#2b190a] font-serif">
      {/* Cabecera */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-3xl sm:text-4xl font-normal text-[#7a4e2a]">
            Comunicados y Anuncios
          </h2>
          <p className="text-sm text-[#58351a] mt-1 font-medium">
            Publicación, edición y difusión de avisos importantes de la iglesia (RF-07)
          </p>
        </div>

        {puedeGestionarEventos && (
          <button
            onClick={abrirModalNuevo}
            className="px-5 py-3 bg-[#fef9c3] hover:bg-[#ebd8c3] text-[#7a4e2a] border-2 border-[#7a4e2a] rounded-xl text-sm font-bold shadow-xs transition-all self-start sm:self-auto"
          >
            Publicar Anuncio
          </button>
        )}
      </div>

      {/* Alertas */}
      {mensaje && (
        <div className="p-4 bg-[#faf4ea] border-2 border-[#7a4e2a] rounded-xl text-[#7a4e2a] text-sm font-bold">
          {mensaje}
        </div>
      )}

      {error && (
        <div className="p-4 bg-[#fff2f0] border-2 border-[#7a4e2a] rounded-xl text-[#783636] text-sm">
          {error}
        </div>
      )}

      {/* Filtros */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#fffdf5] p-5 rounded-2xl border-2 border-[#7a4e2a] shadow-xs text-sm">
        <div className="flex items-center space-x-3">
          <span className="text-[#7a4e2a] font-bold">Categoría:</span>
          <select
            value={filtroCategoria}
            onChange={(e) => setFiltroCategoria(e.target.value)}
            className="px-4 py-2 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-sm focus:outline-none focus:bg-[#fef9c3]/30"
          >
            <option value="">Todas las categorías</option>
            <option value="General">General</option>
            <option value="Jóvenes">Jóvenes</option>
            <option value="Niños">Niños</option>
            <option value="Damas">Damas</option>
            <option value="Formación">Formación / Enseñanza</option>
            <option value="Servicio">Servicio</option>
          </select>
        </div>

        <label className="flex items-center space-x-2.5 cursor-pointer text-[#58351a] font-bold">
          <input
            type="checkbox"
            checked={soloDestacados}
            onChange={(e) => setSoloDestacados(e.target.checked)}
            className="w-4 h-4 rounded border-[#7a4e2a] text-[#7a4e2a] focus:ring-0"
          />
          <span>Mostrar solo avisos prioritarios</span>
        </label>
      </div>

      {/* Lista de Anuncios */}
      {cargando ? (
        <div className="bg-[#fffdf5] p-12 rounded-3xl border-2 border-[#7a4e2a] text-center text-sm text-[#7a4e2a] flex flex-col items-center justify-center space-y-3">
          <div className="animate-spin rounded-full h-8 w-8 border-3 border-[#7a4e2a] border-t-[#fef9c3]"></div>
          <span>Consultando publicaciones de la comunidad...</span>
        </div>
      ) : anuncios.length === 0 ? (
        <div className="bg-[#fffdf5] p-12 rounded-3xl border-2 border-[#7a4e2a] text-center text-sm text-[#7a4e2a]">
          No hay comunicados para mostrar en este momento.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {anuncios.map((an) => (
            <div
              key={an.id}
              className={`p-6 rounded-3xl border-2 transition-all flex flex-col justify-between space-y-3.5 ${
                an.destacado
                  ? 'bg-[#fef9c3]/40 border-[#7a4e2a] shadow-xs'
                  : 'bg-[#fffdf5] border-[#7a4e2a] shadow-xs'
              }`}
            >
              <div className="space-y-2.5">
                <div className="flex items-start justify-between gap-2.5">
                  <div className="flex items-center space-x-2">
                    {an.destacado && (
                      <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-[#7a4e2a] text-[#fffdf5]">
                        Prioritario
                      </span>
                    )}
                    <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-[#faf4ea] text-[#7a4e2a] border border-[#7a4e2a]">
                      {an.categoria}
                    </span>
                  </div>

                  {puedeGestionarEventos && (
                    <div className="flex items-center space-x-3.5 text-sm shrink-0">
                      <button
                        onClick={() => abrirModalEditar(an)}
                        className="text-[#7a4e2a] hover:text-[#2b190a] font-bold underline"
                      >
                        Editar
                      </button>
                      <button
                        onClick={() => handleEliminarAnuncio(an.id)}
                        className="text-[#7a4e2a] hover:text-[#783636] font-medium"
                      >
                        Eliminar
                      </button>
                    </div>
                  )}
                </div>

                <h3 className="text-xl font-bold text-[#7a4e2a] leading-snug">{an.titulo}</h3>
                <p className="text-sm text-[#58351a] leading-relaxed whitespace-pre-line">{an.contenido}</p>
              </div>

              <div className="pt-3 border-t-2 border-[#7a4e2a]/30 flex items-center justify-between text-xs text-[#7a4e2a]">
                <span>Fecha de Publicación: {an.fecha_publicacion?.substring(0, 10)}</span>
                {an.autor_nombre && (
                  <span>Por: <strong className="text-[#2b190a] font-semibold">{an.autor_nombre}</strong></span>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal Crear / Editar Anuncio */}
      <Modal
        isOpen={modalAbierto}
        onClose={() => setModalAbierto(false)}
        titulo={anuncioEnEdicion ? 'Editar Comunicado' : 'Publicar Nuevo Anuncio'}
      >
        <form onSubmit={handleGuardarAnuncio} className="space-y-4 text-[#2b190a]">
          <div>
            <label className="block text-sm font-bold text-[#7a4e2a] mb-1">
              Título del Aviso *
            </label>
            <input
              type="text"
              required
              placeholder="Ej. Convocatoria a la Asamblea General"
              value={formAnuncio.titulo}
              onChange={(e) => setFormAnuncio({ ...formAnuncio, titulo: e.target.value })}
              className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
            />
          </div>

          <div>
            <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Categoría</label>
            <select
              value={formAnuncio.categoria}
              onChange={(e) => setFormAnuncio({ ...formAnuncio, categoria: e.target.value })}
              className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
            >
              <option value="General">General</option>
              <option value="Jóvenes">Jóvenes</option>
              <option value="Niños">Niños / Escuela Dominical</option>
              <option value="Damas">Damas</option>
              <option value="Formación">Formación / Enseñanza</option>
              <option value="Servicio">Servicio</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-bold text-[#7a4e2a] mb-1">
              Contenido del Mensaje *
            </label>
            <textarea
              rows={4}
              required
              placeholder="Redacte el mensaje o anuncio para los miembros..."
              value={formAnuncio.contenido}
              onChange={(e) => setFormAnuncio({ ...formAnuncio, contenido: e.target.value })}
              className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
            />
          </div>

          <label className="flex items-center space-x-2.5 cursor-pointer text-sm font-bold text-[#7a4e2a]">
            <input
              type="checkbox"
              checked={formAnuncio.destacado}
              onChange={(e) => setFormAnuncio({ ...formAnuncio, destacado: e.target.checked })}
              className="w-4 h-4 rounded border-[#7a4e2a] text-[#7a4e2a] focus:ring-0"
            />
            <span>Fijar en el panel principal como anuncio prioritario</span>
          </label>

          <div className="flex justify-end space-x-3 pt-4 border-t-2 border-[#7a4e2a]">
            <button
              type="button"
              onClick={() => setModalAbierto(false)}
              className="px-5 py-2.5 border-2 border-[#7a4e2a] rounded-xl text-sm text-[#7a4e2a] hover:bg-[#faf4ea] font-bold"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={guardando}
              className="px-6 py-2.5 bg-[#fef9c3] hover:bg-[#ebd8c3] text-[#7a4e2a] border-2 border-[#7a4e2a] rounded-xl text-sm font-bold transition-all disabled:opacity-50"
            >
              {guardando ? 'Publicando...' : 'Publicar Anuncio'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
