/**
 * Vista de Gestión de Eventos y Calendario de la Iglesia (RF-04).
 * Predominante: #fffdf5, Contorno: #7a4e2a, Blanco, Beige (#faf4ea, #f5ede1) y Amarillo Pálido #fef9c3.
 * Tipografía: Day Roman Regular (sin iconos, letras más grandes y legibles).
 */
import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { eventosService, miembrosService } from '../services/api';
import Modal from '../components/Modal';

export default function EventosView() {
  const { puedeGestionarEventos } = useAuth();

  const [eventos, setEventos] = useState([]);
  const [miembros, setMiembros] = useState([]);
  const [cargando, setCargando] = useState(false);
  const [mensaje, setMensaje] = useState('');
  const [error, setError] = useState('');

  const [modoVista, setModoVista] = useState('calendario');
  const [fechaCalendario, setFechaCalendario] = useState(new Date());

  const [modalAbierto, setModalAbierto] = useState(false);
  const [eventoEnEdicion, setEventoEnEdicion] = useState(null);
  const [guardando, setGuardando] = useState(false);

  // Formulario (RF-04: título, fecha, hora, lugar, descripción, responsable)
  const [formEvento, setFormEvento] = useState({
    titulo: '',
    tipo: 'Culto',
    fecha: new Date().toISOString().split('T')[0],
    hora: '10:00',
    lugar: 'Templo Principal',
    descripcion: '',
    responsable_id: '',
  });

  const anio = fechaCalendario.getFullYear();
  const mes = fechaCalendario.getMonth();

  useEffect(() => {
    cargarEventos();
    cargarMiembros();
  }, [fechaCalendario]);

  async function cargarEventos() {
    setCargando(true);
    setError('');
    try {
      const res = await eventosService.listar();
      setEventos(res.eventos);
    } catch (err) {
      setError(err.message || 'Error al consultar la agenda de eventos.');
    } finally {
      setCargando(false);
    }
  }

  async function cargarMiembros() {
    try {
      const res = await miembrosService.listar({ estado: 'activos', limite: 500 });
      setMiembros(res.miembros);
    } catch (err) {
      console.error(err);
    }
  }

  function mesAnterior() {
    setFechaCalendario(new Date(anio, mes - 1, 1));
  }

  function mesSiguiente() {
    setFechaCalendario(new Date(anio, mes + 1, 1));
  }

  function abrirModalNuevo(fechaInicial = null) {
    setEventoEnEdicion(null);
    setFormEvento({
      titulo: '',
      tipo: 'Culto',
      fecha: fechaInicial || new Date().toISOString().split('T')[0],
      hora: '10:00',
      lugar: 'Templo Principal',
      descripcion: '',
      responsable_id: '',
    });
    setModalAbierto(true);
  }

  function abrirModalEditar(ev) {
    setEventoEnEdicion(ev);
    setFormEvento({
      titulo: ev.titulo,
      tipo: ev.tipo,
      fecha: ev.fecha,
      hora: ev.hora,
      lugar: ev.lugar,
      descripcion: ev.descripcion || '',
      responsable_id: ev.responsable_id || '',
    });
    setModalAbierto(true);
  }

  async function handleGuardarEvento(e) {
    e.preventDefault();
    setGuardando(true);
    setError('');
    setMensaje('');

    try {
      if (eventoEnEdicion) {
        await eventosService.actualizar(eventoEnEdicion.id, formEvento);
        setMensaje('Evento actualizado con éxito.');
      } else {
        await eventosService.crear(formEvento);
        setMensaje('Evento o culto programado exitosamente.');
      }
      setModalAbierto(false);
      cargarEventos();
    } catch (err) {
      setError(err.message || 'Error al guardar el evento.');
    } finally {
      setGuardando(false);
    }
  }

  async function handleCancelarEvento(ev) {
    const motivo = window.prompt(`Motivo de suspensión para "${ev.titulo}":`);
    if (motivo === null) return;

    try {
      await eventosService.cancelar(ev.id, motivo);
      setMensaje('El evento ha sido cancelado en el calendario.');
      cargarEventos();
    } catch (err) {
      setError(err.message || 'Error al cancelar el evento.');
    }
  }

  function generarDiasMes() {
    const primerDia = new Date(anio, mes, 1).getDay();
    const totalDias = new Date(anio, mes + 1, 0).getDate();

    const dias = [];
    for (let i = 0; i < primerDia; i++) {
      dias.push(null);
    }
    for (let d = 1; d <= totalDias; d++) {
      dias.push(d);
    }
    return dias;
  }

  const nombresMeses = [
    'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
    'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
  ];

  return (
    <div className="space-y-7 text-[#2b190a] font-serif">
      {/* Cabecera */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-3xl sm:text-4xl font-normal text-[#7a4e2a]">
            Gestión de Eventos y Calendario
          </h2>
          <p className="text-sm text-[#58351a] mt-1 font-medium">
            Programación de eventos religiosos y administrativos de la iglesia (RF-04)
          </p>
        </div>

        <div className="flex items-center space-x-3 self-start sm:self-auto">
          {/* Alternar vista Calendario / Lista */}
          <div className="flex bg-[#faf4ea] p-1.5 rounded-xl text-sm border-2 border-[#7a4e2a] shrink-0">
            <button
              onClick={() => setModoVista('calendario')}
              className={`px-4 py-1.5 rounded-lg transition-all font-semibold ${
                modoVista === 'calendario' ? 'bg-[#fef9c3] text-[#7a4e2a] border border-[#7a4e2a] shadow-xs' : 'text-[#58351a] hover:text-[#7a4e2a]'
              }`}
            >
              Calendario
            </button>
            <button
              onClick={() => setModoVista('lista')}
              className={`px-4 py-1.5 rounded-lg transition-all font-semibold ${
                modoVista === 'lista' ? 'bg-[#fef9c3] text-[#7a4e2a] border border-[#7a4e2a] shadow-xs' : 'text-[#58351a] hover:text-[#7a4e2a]'
              }`}
            >
              Listado
            </button>
          </div>

          {puedeGestionarEventos && (
            <button
              onClick={() => abrirModalNuevo()}
              className="px-5 py-2.5 bg-[#fef9c3] hover:bg-[#ebd8c3] text-[#7a4e2a] border-2 border-[#7a4e2a] rounded-xl text-sm font-bold shadow-xs transition-all"
            >
              Nuevo Evento
            </button>
          )}
        </div>
      </div>

      {/* Alertas */}
      {mensaje && (
        <div className="p-4 bg-[#faf4ea] border-2 border-[#7a4e2a] rounded-xl text-[#7a4e2a] text-sm font-bold">
          {mensaje}
        </div>
      )}

      {error && (
        <div className="p-4 bg-[#fff2f0] border-2 border-[#7a4e2a] rounded-xl text-[#783636] text-sm">
          {error}
        </div>
      )}

      {/* VISTA CALENDARIO INTERACTIVO */}
      {modoVista === 'calendario' && (
        <div className="bg-[#fffdf5] rounded-3xl border-2 border-[#7a4e2a] shadow-xs p-6 space-y-5">
          {/* Navegación del mes */}
          <div className="flex items-center justify-between pb-3 border-b-2 border-[#7a4e2a]/30">
            <h3 className="text-xl font-bold text-[#7a4e2a]">
              {nombresMeses[mes]} de {anio}
            </h3>
            <div className="flex items-center space-x-2 text-sm">
              <button
                onClick={mesAnterior}
                className="px-3.5 py-1.5 rounded-lg border-2 border-[#7a4e2a] bg-[#fffdf5] hover:bg-[#faf4ea] text-[#7a4e2a] font-bold"
              >
                « Mes anterior
              </button>
              <button
                onClick={() => setFechaCalendario(new Date())}
                className="px-3.5 py-1.5 text-sm font-bold text-[#7a4e2a] hover:bg-[#fef9c3] rounded-lg border-2 border-[#7a4e2a]"
              >
                Hoy
              </button>
              <button
                onClick={mesSiguiente}
                className="px-3.5 py-1.5 rounded-lg border-2 border-[#7a4e2a] bg-[#fffdf5] hover:bg-[#faf4ea] text-[#7a4e2a] font-bold"
              >
                Mes siguiente »
              </button>
            </div>
          </div>

          {/* Días de la semana */}
          <div className="grid grid-cols-7 gap-1 text-center text-xs font-bold text-[#7a4e2a] uppercase py-2 bg-[#faf4ea] rounded-xl border border-[#7a4e2a]">
            <span>Domingo</span>
            <span>Lunes</span>
            <span>Martes</span>
            <span>Miércoles</span>
            <span>Jueves</span>
            <span>Viernes</span>
            <span>Sábado</span>
          </div>

          {/* Cuadrícula de días */}
          <div className="grid grid-cols-7 gap-1.5 sm:gap-2.5">
            {generarDiasMes().map((dia, idx) => {
              if (dia === null) {
                return <div key={`vacio-${idx}`} className="h-24 sm:h-32 bg-[#faf4ea]/40 rounded-xl" />;
              }

              const diaString = `${anio}-${String(mes + 1).padStart(2, '0')}-${String(dia).padStart(2, '0')}`;
              const eventosDelDia = eventos.filter((e) => e.fecha === diaString);
              const esHoy = new Date().toISOString().split('T')[0] === diaString;

              return (
                <div
                  key={`dia-${dia}`}
                  onClick={() => puedeGestionarEventos && abrirModalNuevo(diaString)}
                  className={`h-24 sm:h-32 p-2 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between ${
                    esHoy
                      ? 'border-[#7a4e2a] bg-[#fef9c3]/50'
                      : 'border-[#7a4e2a]/40 hover:border-[#7a4e2a] bg-[#fffdf5]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-sm font-bold w-7 h-7 rounded-full flex items-center justify-center ${
                        esHoy ? 'bg-[#7a4e2a] text-[#fffdf5]' : 'text-[#7a4e2a]'
                      }`}
                    >
                      {dia}
                    </span>
                    {eventosDelDia.length > 0 && (
                      <span className="text-xs font-bold text-[#7a4e2a] bg-[#fef9c3] px-2 py-0.5 rounded-full border border-[#7a4e2a]">
                        {eventosDelDia.length}
                      </span>
                    )}
                  </div>

                  <div className="space-y-1 overflow-y-auto">
                    {eventosDelDia.slice(0, 2).map((ev) => (
                      <div
                        key={ev.id}
                        onClick={(e) => {
                          e.stopPropagation();
                          abrirModalEditar(ev);
                        }}
                        className={`px-2 py-0.5 rounded-md text-xs font-medium truncate border ${
                          ev.estado === 'Cancelado'
                            ? 'bg-[#fff2f0] text-[#783636] border-[#7a4e2a] line-through'
                            : 'bg-[#faf4ea] text-[#7a4e2a] border-[#7a4e2a]'
                        }`}
                        title={`${ev.titulo} (${ev.hora})`}
                      >
                        {ev.hora} {ev.titulo}
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* VISTA DE LISTA DE EVENTOS */}
      {(modoVista === 'lista' || eventos.length > 0) && (
        <div className="bg-[#fffdf5] rounded-3xl border-2 border-[#7a4e2a] shadow-xs overflow-hidden p-6 space-y-4">
          <h3 className="text-lg font-bold text-[#7a4e2a] pb-3 border-b-2 border-[#7a4e2a]/30">
            Lista Completa de Eventos y Cultos
          </h3>

          <div className="space-y-3.5">
            {eventos.map((ev) => (
              <div
                key={ev.id}
                className="p-5 rounded-2xl bg-[#faf4ea] border-2 border-[#7a4e2a] hover:bg-[#fef9c3]/40 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3.5"
              >
                <div className="space-y-1.5">
                  <div className="flex items-center space-x-2.5">
                    <span className="text-base font-bold text-[#7a4e2a]">{ev.titulo}</span>
                    <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-[#fef9c3] text-[#7a4e2a] border border-[#7a4e2a]">
                      {ev.tipo}
                    </span>
                    <span
                      className={`text-xs font-bold px-2.5 py-0.5 rounded-full border-2 ${
                        ev.estado === 'Realizado'
                          ? 'bg-[#faf4ea] text-[#7a4e2a] border-[#7a4e2a]'
                          : ev.estado === 'Cancelado'
                          ? 'bg-[#fff2f0] text-[#783636] border-[#7a4e2a]'
                          : 'bg-[#fffdf5] text-[#7a4e2a] border-[#7a4e2a]'
                      }`}
                    >
                      {ev.estado}
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-4 text-sm text-[#58351a]">
                    <span>Fecha: {ev.fecha} • {ev.hora} hrs</span>
                    <span>Lugar: {ev.lugar}</span>
                    {ev.responsable_nombre && (
                      <span>Responsable: <strong className="text-[#7a4e2a]">{ev.responsable_nombre}</strong></span>
                    )}
                  </div>

                  {ev.descripcion && (
                    <p className="text-sm text-[#58351a] pt-1">{ev.descripcion}</p>
                  )}
                </div>

                {puedeGestionarEventos && (
                  <div className="flex items-center space-x-4 self-end sm:self-center shrink-0 text-sm">
                    <button
                      onClick={() => abrirModalEditar(ev)}
                      className="text-[#7a4e2a] hover:text-[#2b190a] font-bold underline"
                    >
                      Editar
                    </button>
                    {ev.estado !== 'Cancelado' && (
                      <button
                        onClick={() => handleCancelarEvento(ev)}
                        className="text-[#7a4e2a] hover:text-[#783636] font-medium"
                      >
                        Suspender
                      </button>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modal de Creación / Edición */}
      <Modal
        isOpen={modalAbierto}
        onClose={() => setModalAbierto(false)}
        titulo={eventoEnEdicion ? 'Modificar Evento o Culto' : 'Programar Nuevo Evento o Culto'}
      >
        <form onSubmit={handleGuardarEvento} className="space-y-4 text-[#2b190a]">
          <div>
            <label className="block text-sm font-bold text-[#7a4e2a] mb-1">
              Título del Evento *
            </label>
            <input
              type="text"
              required
              placeholder="Ej. Culto Dominical de Adoración"
              value={formEvento.titulo}
              onChange={(e) => setFormEvento({ ...formEvento, titulo: e.target.value })}
              className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Tipo de Evento</label>
              <select
                value={formEvento.tipo}
                onChange={(e) => setFormEvento({ ...formEvento, tipo: e.target.value })}
                className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
              >
                <option value="Culto">Culto Principal (Religioso)</option>
                <option value="Reunión">Reunión de Oración (Religioso)</option>
                <option value="Vigilia">Vigilia (Religioso)</option>
                <option value="Estudio Bíblico">Estudio Bíblico (Religioso)</option>
                <option value="Actividad Especial">Actividad Especial (Religioso)</option>
                <option value="Administrativo">Reunión Administrativa (Administrativo)</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1">
                Lugar / Salón *
              </label>
              <input
                type="text"
                required
                placeholder="Templo Principal, Sala de Consejo, etc."
                value={formEvento.lugar}
                onChange={(e) => setFormEvento({ ...formEvento, lugar: e.target.value })}
                className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1">
                Fecha *
              </label>
              <input
                type="date"
                required
                value={formEvento.fecha}
                onChange={(e) => setFormEvento({ ...formEvento, fecha: e.target.value })}
                className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-[#7a4e2a] mb-1">
                Hora de Inicio *
              </label>
              <input
                type="time"
                required
                value={formEvento.hora}
                onChange={(e) => setFormEvento({ ...formEvento, hora: e.target.value })}
                className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Responsable / Encargado</label>
            <select
              value={formEvento.responsable_id}
              onChange={(e) => setFormEvento({ ...formEvento, responsable_id: e.target.value })}
              className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
            >
              <option value="">-- Sin responsable asignado --</option>
              {miembros.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.nombre}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-bold text-[#7a4e2a] mb-1">Descripción y Detalles</label>
            <textarea
              rows={2}
              placeholder="Detalles sobre el orden del servicio, programa o notas administrativas..."
              value={formEvento.descripcion}
              onChange={(e) => setFormEvento({ ...formEvento, descripcion: e.target.value })}
              className="w-full px-4 py-2.5 bg-[#fffdf5] border-2 border-[#7a4e2a] rounded-xl text-base focus:outline-none focus:bg-[#fef9c3]/30"
            />
          </div>

          <div className="flex justify-end space-x-3 pt-4 border-t-2 border-[#7a4e2a]">
            <button
              type="button"
              onClick={() => setModalAbierto(false)}
              className="px-5 py-2.5 border-2 border-[#7a4e2a] rounded-xl text-sm font-bold text-[#7a4e2a] hover:bg-[#faf4ea]"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={guardando}
              className="px-6 py-2.5 bg-[#fef9c3] hover:bg-[#ebd8c3] text-[#7a4e2a] border-2 border-[#7a4e2a] rounded-xl text-sm font-bold transition-all disabled:opacity-50"
            >
              {guardando ? 'Guardando...' : eventoEnEdicion ? 'Guardar Cambios' : 'Agendar Evento'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
